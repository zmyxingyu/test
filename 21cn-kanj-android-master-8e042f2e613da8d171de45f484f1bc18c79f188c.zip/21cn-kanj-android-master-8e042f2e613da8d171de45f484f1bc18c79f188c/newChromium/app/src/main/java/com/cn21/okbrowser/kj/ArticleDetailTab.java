package com.cn21.okbrowser.kj;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.TabState;
import org.chromium.chrome.browser.tab.TabUma;
import org.chromium.chrome.browser.tabmodel.TabModel;
import org.chromium.ui.base.WindowAndroid;

import retrofit2.Call;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.cn21.android.news.flowcon.FlowConManager;
import com.cn21.android.news.manage.KjJsInterface;
import com.cn21.android.news.manage.report.IArticleReport;
import com.cn21.android.news.manage.report.model.ArticleDetailReportEntity;
import com.cn21.android.news.material.events.BusProvider;
import com.cn21.android.news.model.ArticleDetailHtmlParse;
import com.cn21.android.news.model.ArticleDetailPicJsEntity;
import com.cn21.android.news.model.ArticleDetailPicStateEntity;
import com.cn21.android.news.model.ArticleMarkList;
import com.cn21.android.news.model.ArticleMarkRes;
import com.cn21.android.news.model.ArticlePicEntity;
import com.cn21.android.news.model.ArticleRelatedInfoRes;
import com.cn21.android.news.model.ArticleUserMarksEntity;
import com.cn21.android.news.model.BaseEntity;
import com.cn21.android.news.model.DeleteMarkDataEntity;
import com.cn21.android.news.model.ImageBean;
import com.cn21.android.news.model.VideoEntity;
import com.cn21.android.news.net.retrofit.BaseEntityCallback;
import com.cn21.android.news.ui.home.ArticleDetailActivity;
import com.cn21.android.news.ui.home.ArticleReportActivity;
import com.cn21.android.news.ui.home.GestureImageActivity;
import com.cn21.android.news.ui.main.CommonShareActivity;
import com.cn21.android.news.ui.main.LoginActivity;
import com.cn21.android.news.ui.main.WebActivity;
import com.cn21.android.news.ui.mine.PublishActivity;
import com.cn21.android.news.ui.video.ArticleVideoActivity;
import com.cn21.android.news.utils.ArticleUtil;
import com.cn21.android.news.utils.ClientUtil;
import com.cn21.android.news.utils.Config;
import com.cn21.android.news.utils.Constants;
import com.cn21.android.news.utils.DefaultShared;
import com.cn21.android.news.utils.GlideUtil;
import com.cn21.android.news.utils.HttpUtil;
import com.cn21.android.news.utils.JsonUtil;
import com.cn21.android.news.utils.Log;
import com.cn21.android.news.utils.LoginUtil;
import com.cn21.android.news.utils.NetUtil;
import com.cn21.android.news.utils.ResponseUtil;
import com.cn21.android.news.utils.ToastUtil;
import com.cn21.android.news.utils.UserInfoUtil;
import com.cn21.android.news.utils.WebViewUtils;
import com.cn21.onekit.lib.update.ResourcePackageManager;
import com.cn21.ued.apm.util.UEDAgent;
import com.google.gson.Gson;
import com.squareup.otto.Subscribe;

/**
 * Created by Administrator on 2018/2/11.
 */
public class ArticleDetailTab extends BaseArticleDetailTab implements IArticleReport {
    private Map<String, ArticleDetailPicStateEntity> mPicStateEntityMap;//图片加载状态Map
    private List<ArticlePicEntity> mArticlePicList;//解析Html之后图片列表
    private boolean isLazyLoadEnable = true;//4.4以上系统默认状态最终页懒加载打开
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private boolean mIsWifi = false;
    private boolean mIsLoadComplete = false;
    private boolean mIsVisibleToUser = false;
    private boolean isCanScroll = true;

    private TextView mArticleErrorReport1;//文章报错
    private TextView mArticleErrorReport2;//文章报错
    private String mMarkDataJson;//文章划线数据
    private String mTurnToPushContent;//划线转推数据
    private String mShareUrl;//划线分享数据
    private ArticleJsInterface articleJsInterface;

    public ArticleDetailTab(int id, boolean incognito, WindowAndroid window) {
        super(id, incognito, window);
    }

    public ArticleDetailTab(int id, int parentId, boolean incognito, Context context, WindowAndroid window, TabModel.TabLaunchType type, TabUma.TabCreationState creationState, TabState frozenState) {
        super(id, parentId, incognito, context, window, type, creationState, frozenState);
    }

    @Override
    protected View initRootView() {
        return View.inflate(getActivity(), R.layout.chrome_article_detail_fragment, null);
    }

    @Override
    protected void initView() {
        isLazyLoadEnable = ArticleUtil.isEnableLazyLoad();
        mReadOriginalView.setVisibility(View.VISIBLE);
        initArticleErrorReport();
        BusProvider.register(this);
    }

    public void getMarkDatas() {
        if (ArticleDetailActivity.markType == 2) {
            Log.i("msg", "------come----" + System.currentTimeMillis());
            loadUrl("javascript:bridge.getMarkData()");
        }
    }

    private void initArticleErrorReport() {
        mArticleErrorReport1 = (TextView) mRootView.findViewById(R.id.article_detail_article_error1);
        mArticleErrorReport2 = (TextView) mRootView.findViewById(R.id.article_detail_article_error2);
        mArticleErrorReport2.setOnClickListener(this);

        mArticleErrorReport1.setVisibility(View.VISIBLE);
        mArticleErrorReport2.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initContentView() {
        super.initContentView();
        //initDateView();
        mIsWifi = NetUtil.isWifi(mActivity);
        articleJsInterface = new ArticleJsInterface(mActivity);
        addJavascriptInterface(articleJsInterface, "jsInterface");
        setWebViewClient(new ArticleWebViewClient());
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int i = v.getId();
        if (i == R.id.article_detail_article_error2) {//文章报错页面
            if (mArticleContentEntity != null) {
                String markId = "";
                if (mArticleInfoEntity.mark != null && mArticleInfoEntity.mark.markId != null) {
                    markId = mArticleInfoEntity.mark.markId;
                }
                ArticleReportActivity.openActivity(mActivity, mArticleContentEntity.id, markId, ArticleReportActivity.REPORT_ARTICLE_ERROR);
                mActivity.postArticleDetailData();
            }

        } else {
        }

    }

    @Override
    protected void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (mIsLoadComplete) {
                mActivity.setArticleDetailData(ArticleDetailReportEntity.START_READ_TIME, System.currentTimeMillis());
            }
        } else {
            //只有当用户看见了页面之后再次变为不可见才记录阅读结束时间
            if (mIsLoadComplete && mIsVisibleToUser) {
                mActivity.setArticleDetailData(ArticleDetailReportEntity.END_READ_TIME, System.currentTimeMillis());
            }
        }
        mIsVisibleToUser = isVisibleToUser;
    }

    @Override
    protected void setContentView() {
        super.setContentView();
        mergeToTemplate();
    }

    //点击点亮条目的事件
    @Subscribe
    public void setMarkData(ArticleMarkList markData) {
        if (!isDetached())
            loadUrl("javascript:bridge.setMarkData('" + JsonUtil.toJsonElement(markData) + "')");
    }

    @Subscribe
    public void setAllMarkData(ArticleRelatedInfoRes markDataJsonArray) {
        if (!isDetached() && markDataJsonArray.mark != null) {
            Log.i("msg", "----markDataJsonArray--" + markDataJsonArray.mark);
            boolean flag = UserInfoUtil.getUserRoles().contains("rcmd_reason");
            String userInfo = "{\"isLogin\":" + LoginUtil.isLogin() + ",\"isCanTurnToPush\":" + flag + "}";
            loadUrl("javascript:bridge.initMark('" + userInfo + "')");
            loadUrl("javascript:bridge.setAllMarkData('" + JsonUtil.toJsonElement(markDataJsonArray.mark) + "')");
        }
    }

    /**
     * 解析Html数据替换模板
     */
    private void mergeToTemplate() {
        ArticleUtil.articleDetailMergeToTemplate(mActivity,
                mArticleContentEntity,
                mScreenWidth,
                new ArticleUtil.MergeToTemplateListener() {
                    @Override
                    public void onComplete(ArticleDetailHtmlParse articleDetailHtmlParse) {
                        if (isDetached()) {
                            return;
                        }
                        doOnComplete(articleDetailHtmlParse);
                    }
                });
    }

    //// TODO: 2018/2/6 zhangmy
    public void doOnComplete(ArticleDetailHtmlParse articleDetailHtmlParse) {
        if (articleDetailHtmlParse != null) {
            mArticlePicList = articleDetailHtmlParse.picList;
            mPicStateEntityMap = articleDetailHtmlParse.picStateEntityHashMap;
            String path = ResourcePackageManager.getH5UnzipPath();//ArticleUtil.getLocalPath();
            if (TextUtils.isEmpty(path))
                loadDataWithBaseURL(Constants.ASSETS_ANDROID_DIRECTORY, articleDetailHtmlParse.content + "", "text/html", "utf-8", null);
            else
                loadDataWithBaseURL("file:///" + path, articleDetailHtmlParse.content + "", "text/html", "utf-8", null);
        }
    }

    /**
     * 通过Js将图片文件加载在网页中
     *
     * @param file   图片文件
     * @param entity 前端交互Json实体
     */
    private void handleImageFile(File file, ArticlePicEntity entity) {
        if (isDetached()) {
            return;
        }

        if (mActivity.isFinishing()) {
            return;
        }
        if (entity == null) {
            return;
        }
        //判断本地文件是否保存成功
        if (file == null || file.length() <= 0) {
            showImgFailState(entity);
            entity.isFail = 1;
        } else {
            String src = file.getAbsolutePath();
            if (!TextUtils.isEmpty(src)) {
                showImgSuccess(file, entity);
            } else {
                showImgFailState(entity);
                entity.isFail = 1;
            }
        }

    }

    /**
     * 处理图片加载
     *
     * @param picEntity
     */
    private void downLoadImg(ArticlePicEntity picEntity) {
        if (picEntity != null) {
            if (picEntity.isKeyGif == 1 && !mIsWifi) {
                GlideUtil.downloadFile(mActivity, picEntity.keyGifPicUrl, new ArticleImgDownLoadListener(picEntity.id));
            } else {
                picEntity.isKeyGif = 0;//下载原图将第一帧gif标志置0
                GlideUtil.downloadFile(mActivity, picEntity.picUrl, new ArticleImgDownLoadListener(picEntity.id));
            }
        }
    }

    /**
     * Gif原图加载状态
     *
     * @param entity
     */
    public void showImgLoadingState(ArticlePicEntity entity) {
        ArticleDetailPicJsEntity articleDetailPicJsEntity = new ArticleDetailPicJsEntity();

        articleDetailPicJsEntity.isFail = 0;
        articleDetailPicJsEntity.isLoading = 1;
        articleDetailPicJsEntity.imageId = entity.id;
        if (mPicStateEntityMap == null) {
            return;
        }
        ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(entity.id);
        if (articleDetailPicStateEntity == null) {
            return;
        }

        articleDetailPicStateEntity.isLoading = true;

        if (!TextUtils.isEmpty(articleDetailPicStateEntity.src)) {
            articleDetailPicJsEntity.src = articleDetailPicStateEntity.src;
        } else {
            articleDetailPicJsEntity.src = "";
        }
        //前端暂时不需要加载状态，所以在加载状态暂时不需要与前端通信
    }

    /**
     * 处理图片加载失败状态
     *
     * @param entity
     */
    public void showImgFailState(ArticlePicEntity entity) {
        ArticleDetailPicJsEntity articleDetailPicJsEntity = new ArticleDetailPicJsEntity();

        articleDetailPicJsEntity.isFail = 1;
        articleDetailPicJsEntity.isLoading = 0;
        articleDetailPicJsEntity.imageId = entity.id;
        articleDetailPicJsEntity.isGif = entity.isGif;
        if (mPicStateEntityMap == null) {
            return;
        }
        ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(entity.id);
        if (articleDetailPicStateEntity == null) {
            return;
        }

        articleDetailPicStateEntity.isLoading = false;
        if (!TextUtils.isEmpty(articleDetailPicStateEntity.src)) {
            articleDetailPicJsEntity.src = articleDetailPicStateEntity.src;
        } else {
            articleDetailPicJsEntity.src = "";
        }

        mPicStateEntityMap.put(entity.id, articleDetailPicStateEntity);

        //调用js接口，显示图片
        if (!isDetached()) {
            String jsStr = JsonUtil.toJsonElement(articleDetailPicJsEntity);
            loadUrl("javascript:bridge.showImage('" + jsStr + "')");
        }

    }

    /**
     * 处理图片加载成功
     *
     * @param file
     * @param entity
     */
    public void showImgSuccess(File file, ArticlePicEntity entity) {
        ArticleDetailPicJsEntity articleDetailPicJsEntity = new ArticleDetailPicJsEntity();

        articleDetailPicJsEntity.imageId = entity.id;
        articleDetailPicJsEntity.isGif = entity.isGif;
        articleDetailPicJsEntity.isKeyGif = entity.isKeyGif;
        articleDetailPicJsEntity.isFail = 0;
        articleDetailPicJsEntity.isLoading = 0;
        articleDetailPicJsEntity.src = file.getAbsolutePath();

        if (mPicStateEntityMap == null) {
            return;
        }
        ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(entity.id);
        if (articleDetailPicStateEntity == null) {
            return;
        }

        articleDetailPicStateEntity.isLoading = false;
        articleDetailPicStateEntity.src = articleDetailPicJsEntity.src;
        mPicStateEntityMap.put(entity.id, articleDetailPicStateEntity);

        //调用js接口，显示图片
        if (!isDetached()) {
            String jsStr = JsonUtil.toJsonElement(articleDetailPicJsEntity);
            loadUrl("javascript:bridge.showImage('" + jsStr + "')");
        }
    }

    public void handleVideoClick(String json) {
        Log.i("json", json);
        VideoEntity videoEntity = JsonUtil.fromJsonString(json, VideoEntity.class);
        ArticleVideoActivity.openActivity(getActivity(), mArticleContentEntity.id, mArticleContentEntity.contentUrl, mArticleContentEntity.originalUrl, mArticleContentEntity.title, videoEntity.url, mArticleContentEntity.summary, ArticleVideoActivity.RELATIVE);
    }

    @Subscribe
    public void setChooseImageEvent(ImageBean bean) {
        if (bean != null && !isDetached()) {
            if (!TextUtils.isEmpty(bean.imgType))
                loadUrl("javascript:bridge.uploadFileFinished('" + bean.imgType + "','" + bean.picUrl + "')");
            else {
                loadUrl("javascript:bridge.setImageUrl('" + bean.picUrl + "')");
            }
        }
    }

    /**
     * 处理图片点击事件
     *
     * @param picId
     */
    public void handleImgClick(String picId) {
        if (mArticleContentEntity != null && !ResponseUtil.isEmptyList(mArticlePicList)) {
            ArticlePicEntity articlePicEntity = mArticlePicList.get(Integer.valueOf(picId));
            ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(picId);

            boolean picIsLoading = false;
            if (articleDetailPicStateEntity != null) {
                picIsLoading = articleDetailPicStateEntity.isLoading;//取出图片是否正在加载标志
            }

            if (articlePicEntity != null) {
                if (articlePicEntity.isFail == 1) {
                    if (!picIsLoading) {
                        //加载失败的情况，如果是gif第一帧则下载,不是则下载原图
                        showImgLoadingState(articlePicEntity);
                        if (articlePicEntity.isKeyGif == 1) {
                            GlideUtil.downloadFile(mActivity, articlePicEntity.keyGifPicUrl, new ArticleImgDownLoadListener(picId));
                        } else {
                            GlideUtil.downloadFile(mActivity, articlePicEntity.picUrl, new ArticleImgDownLoadListener(picId));
                        }
                    }
                } else if (articlePicEntity.isKeyGif == 1) {
                    if (!picIsLoading) {
                        //如果下载成功并且为gif第一帧的情况下则下载Gif原图
                        showImgLoadingState(articlePicEntity);
                        articlePicEntity.isKeyGif = 0;
                        GlideUtil.downloadFile(mActivity, articlePicEntity.picUrl, new ArticleImgDownLoadListener(picId));
                    }
                } else if (articlePicEntity.isPicLoad == 1) {
                    //如果下载成功并且是普通图片或者是gif非第一帧的情况下则点击进入图集
                    GestureImageActivity.openActivity(mActivity,
                            (ArrayList<ArticlePicEntity>) mArticlePicList,
                            Integer.valueOf(picId),
                            GestureImageActivity.FROM_ARTICLE_DETAIL);

                }
            }
        }
    }

    /**
     * 非懒加载下载文章内容的图片
     *
     * @param picList
     */
    public void loadImage(List<ArticlePicEntity> picList) {
        if (picList == null || picList.size() == 0) {
            return;
        }

        for (int i = 0; i < picList.size(); i++) {
            //解析html时赋给img标签的id为此数组的角标
            downLoadImg(picList.get(i));
        }
    }

    public void handleShareWords(String url) {
        if (LoginUtil.isLogin()) {
            CommonShareActivity.openActivity(mActivity, "分享", url, CommonShareActivity.TYPE_SHARE_MARK);
        } else {
            openLoginActivity(LoginActivity.TO_SHARE_LINE);
            mShareUrl = url;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i("resultCode", "-------resultCode---" + resultCode);
        if (resultCode == LoginActivity.RESULT_CODE) {
            int loginTo = data.getIntExtra(LoginActivity.LOGIN_TO, LoginActivity.TO_DEFAULT);
            int loginState = data.getIntExtra(LoginActivity.LOGIN_STATE, -1);
            //只有在登录成功之后再执行跳转
            if (loginState == LoginUtil.LOGIN) {
                if (loginTo == LoginActivity.TO_POSTMARKDATA) {
                    handlePostMarkData(mMarkDataJson);
                } else if (loginTo == LoginActivity.TO_SHARE_LINE) {
                    handleShareMarkData(mMarkDataJson);
                }
            }
        } else if (articleJsInterface != null && null != articleJsInterface.mPhotoManager) {
            articleJsInterface.mPhotoManager.onActivityResult(requestCode, resultCode, data);
        }

    }

    //上报文章划线数据
    public void handlePostMarkData(String markDataJson) {
        try {
            if (LoginUtil.isLogin()) {
                if (mArticleContentEntity == null)
                    return;
                ArticleMarkList entity = JsonUtil.fromJsonString(markDataJson, ArticleMarkList.class);
                if (entity.positions != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < entity.positions.size(); i++) {
                        if (TextUtils.isEmpty(entity.positions.get(i).content)) {
                            continue;
                        }
                        sb.append(Html.fromHtml(entity.positions.get(i).content).toString().trim());
                        if (i != entity.positions.size() - 1)
                            sb.append("\n");
                    }
                    PublishActivity.openActivity(mActivity, PublishActivity.FROM_MARK, mArticleContentEntity.id, sb.toString(), mArticleContentEntity.title, mArticleContentEntity.content, entity);
                }
            } else {
                openLoginActivity(LoginActivity.TO_POSTMARKDATA);
                mMarkDataJson = markDataJson;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openLoginActivity(int loginTo) {
        Intent intent = new Intent(mActivity, LoginActivity.class);
        intent.putExtra(LoginActivity.LOGIN_TO, loginTo);
        intent.putExtra(LoginActivity.IS_FINISH_AFTER_LOGIN, true);
        getActivity().startActivityForResult(intent, LoginActivity.RESULT_CODE);
        mActivity.overridePendingTransition(0, 0);
    }

    //删除文章划线数据
    public void handleDeleteMarkData(final String markId) {
        if (mArticleContentEntity == null)
            return;
        Map<String, String> params = new HashMap<>();
        params.put("articleId", mArticleContentEntity.id);
        params.put("openid", UserInfoUtil.getOpenId());
        params.put("markIds", markId);
        params = HttpUtil.getEncryptRequestParams(mActivity, params);

        Call<BaseEntity> mGetArticleRecommendersCall = mActivity.getmNewsApi().deleteMarkData(params);
        mGetArticleRecommendersCall.enqueue(new BaseEntityCallback<BaseEntity>() {
            @Override
            public void onResponse(BaseEntity baseEntity) {
                DeleteMarkDataEntity entity = new DeleteMarkDataEntity();
                entity.markId = markId;
                BusProvider.deleteMarkDataEntity(entity);
                loadUrl("javascript:bridge.deleteMarkData('" + JsonUtil.toJsonElement(baseEntity) + "')");
            }

            @Override
            public void onFailure() {

            }
        });
    }

    private void handSetIsCanScroll(boolean flag) {
        isCanScroll = flag;
        //mScrollView.setIsCanScroll(flag);
    }

    @Override
    protected void onScrollChange(int scrollY, int contentHeight) {
        mActivity.setArticleDetailData(ArticleDetailReportEntity.TOTAL_LEN, contentHeight);
        mActivity.setArticleDetailData(ArticleDetailReportEntity.READ_LEN, scrollY);
    }

    private void handCopyWords(String content) {
        ClipboardManager clipboardManager = (ClipboardManager) mActivity.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clipData = ClipData.newPlainText("newPlainTextLabel", content);
        clipboardManager.setPrimaryClip(clipData);
        ToastUtil.showShortToast(mActivity, "已复制到剪切板");
    }

    @Override
    protected void onWebViewProgressChange(int newProgress) {
        super.onWebViewProgressChange(newProgress);
    }

    public void handlePublishMarkData(String publishMarkJson) {
        Log.i("msg", "publishMarkJson==" + publishMarkJson);
        BusProvider.setMarkEvent(publishMarkJson);
    }

    //分享之前先上报文章划线数据
    public void handleShareMarkData(String markDataJson) {
        try {
            if (LoginUtil.isLogin()) {
                if (mArticleContentEntity == null)
                    return;
                ArticleUserMarksEntity entity = new Gson().fromJson(markDataJson, ArticleUserMarksEntity.class);
                showLoadingProgress();
                Map<String, String> params = new HashMap<>();
                params.put("objType", "0");
                params.put("objId", mArticleContentEntity.id);
                params.put("openid", UserInfoUtil.getOpenId());
                params.put("positions", new Gson().toJson(entity.positions));
                params = HttpUtil.getEncryptRequestParams(mActivity, params);

                Call<ArticleMarkRes> mGetArticleRecommendersCall = mActivity.getmNewsApi().postMarkData(params);
                mGetArticleRecommendersCall.enqueue(new BaseEntityCallback<ArticleMarkRes>() {
                    @Override
                    public void onResponse(ArticleMarkRes articleMarkListEntity) {
                        dismissLoadingProgress();
                        if (articleMarkListEntity != null && articleMarkListEntity.succeed() && articleMarkListEntity.markResult != null) {
                            String url = Constants.SHARE_MARK_URL + (articleMarkListEntity.markResult.markId != null ? articleMarkListEntity.markResult.markId : "");
                            handleShareWords(url);
                        } else if (articleMarkListEntity != null) {
                            ToastUtil.showShortToast(mActivity, articleMarkListEntity.msg);
                        }
                    }

                    @Override
                    public void onFailure() {
                        dismissLoadingProgress();
                    }
                });
            } else {
                openLoginActivity(LoginActivity.TO_SHARE_LINE);
                mMarkDataJson = markDataJson;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setBottomVisible(int visible) {
        try {
            ((FakeArticleDetailActivity) this.getActivity()).setBottomVisible(visible);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 最终页与前端JS通信接口
     */
    final class ArticleJsInterface extends KjJsInterface {

        public ArticleJsInterface(Activity activity) {
            super(activity);
        }

        // 划线分享传递信息给前端
        @android.webkit.JavascriptInterface
        public String getArticleInfo() {
            String json = "{\"url\":\"" + mArticleContentEntity.contentUrl + "\",\"nickName\":\"" + UserInfoUtil.getUserNickName() + "\"}";
            return json;
        }

        // 隐藏文章最终页底部按钮
        @android.webkit.JavascriptInterface
        public void setArticleBottomVisible(final int visible) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    setBottomVisible(visible);
                }
            });
        }

        // 设置模板类型  type=2用于发布划线  type=1用于普通文章划线
        @android.webkit.JavascriptInterface
        public int setMarkType() {
            return ArticleDetailActivity.markType;
        }

        // 发布时获取文章点亮数据
        @android.webkit.JavascriptInterface
        public void getMarkData(final String markDataJson) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handlePublishMarkData(markDataJson);
                }
            });
        }

        // 转推
        @android.webkit.JavascriptInterface
        public void turnToPush(final String content) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {

                }
            });
        }

        //长按埋点
        @android.webkit.JavascriptInterface
        public void longClick() {
            UEDAgent.trackCustomKVEvent(mActivity, "publisher_articleLight_longPress", null, null);
        }

        // 复制
        @android.webkit.JavascriptInterface
        public void copyWords(final String content) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handCopyWords(content);
                }
            });
        }

        // 是否禁止滚动
        @android.webkit.JavascriptInterface
        public void setIsCanScroll(final boolean flag) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handSetIsCanScroll(flag);
                }
            });
        }

        //分享文字
        @android.webkit.JavascriptInterface
        public void shareMarkData(final String markDataJson) {
            UEDAgent.trackCustomKVEvent(mActivity, "article_longPress_share_click", null, null);
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleShareMarkData(markDataJson);
                }
            });
        }

        //上传点亮数据接口 json字符串
        @android.webkit.JavascriptInterface
        public void postMarkData(final String markDataJson) {
            UEDAgent.trackCustomKVEvent(mActivity, "article_longPress_excerpt_click", null, null);
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handlePostMarkData(markDataJson);
                }
            });
        }

        //撤销点亮数据接口  markId划线id
        @android.webkit.JavascriptInterface
        public void deleteMarkData(final String markId) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleDeleteMarkData(markId);
                }
            });
        }

        //下载图片
        @android.webkit.JavascriptInterface
        public void downloadImage(final String picId) {
            //是否启用懒加载
            if (isLazyLoadEnable) {
                try {
                    final ArticlePicEntity picEntity = mArticlePicList.get(Integer.valueOf(picId));
                    ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(picId);
                    boolean isHasScrollRequest = articleDetailPicStateEntity.isScrollRequest;
                    //判断此id是否有相应的Entity,并且此图片是否被请求
                    if (picEntity != null && !isHasScrollRequest) {
                        articleDetailPicStateEntity.isScrollRequest = true;
                        //滚动事件回调不在主线程中
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                downLoadImg(picEntity);
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        //图片点击事件
        @android.webkit.JavascriptInterface
        public void imgClick(final String picId) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleImgClick(picId);
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void videoClick(final String json) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    handleVideoClick(json);
                }
            });
        }
    }

    final class ArticleDateInterface extends KjJsInterface {

        public ArticleDateInterface(Activity activity) {
            super(activity);
        }

        @android.webkit.JavascriptInterface
        public void dismissLoadingView() {
            if (isDetached()) {
                return;
            }

//            mActivity.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    mArticleDetailDate.setVisibility(View.VISIBLE);
//                    mHandler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            Log.i("ArticleDetail", "dismissLoadingView");
//                            mArticleDetailDate.setVisibility(View.GONE);
//                        }
//                    }, 5000L);
//                }
//            });
        }

        //登陆
        @android.webkit.JavascriptInterface
        @Override
        public void login() {
            if (isDetached()) {
                return;
            }

            LoginUtil.openLoginActivity(mActivity);
//            mActivity.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    mArticleDetailDate.setVisibility(View.GONE);
//                }
//            });
        }

        @android.webkit.JavascriptInterface
        @Override
        public void openNewHtmlPage(String htmlUrl) {
            super.openNewHtmlPage(htmlUrl);
            if (isDetached()) {
                return;
            }

            UEDAgent.trackCustomKVEvent(mActivity, "DateSign_click", null, null);
        }

        @android.webkit.JavascriptInterface
        public void closeHtmlPage() {
            if (isDetached()) {
                return;
            }

//            mActivity.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    mArticleDetailDate.setVisibility(View.GONE);
//                }
//            });
        }

    }


    private void showDateWebView(String url) {
        loadUrl(url);
    }

    /**
     * Webview监听
     */
    private class ArticleWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.i("ArticleDetail", "url: " + url);
            boolean results = false;
            if (!TextUtils.isEmpty(url)) {
                if (url.startsWith("http")) {
                    WebActivity.openActivity(getActivity(), "详情", url);
                    results = true;
                } else {
                    if (url.startsWith(Config.KANJIAN_SCHEME)) {
                        getActivity().startActivity(WebViewUtils.actionView(getActivity(), url));
                        results = true;
                    }
                }
            }
            return results;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!isLazyLoadEnable && mArticlePicList != null) {
                loadImage(mArticlePicList);
            }
            long curTime = System.currentTimeMillis();
            if (mActivity != null) {
                mActivity.setArticleDetailData(ArticleDetailReportEntity.END_LOAD_TIME, curTime);
                mActivity.setArticleDetailData(ArticleDetailReportEntity.TOTAL_LEN, getContentHeight());
                if (mIsVisibleToUser) {
                    mActivity.setArticleDetailData(ArticleDetailReportEntity.START_READ_TIME, curTime);
                }
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            FlowConManager.getInstance().handleNetWorkFailure("ArticleDetail");
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            FlowConManager.getInstance().handleNetWorkFailure("ArticleDetail");
        }
    }

    /**
     * 图片下载监听
     */
    class ArticleImgDownLoadListener extends SimpleTarget<File> {

        private String picId;

        public ArticleImgDownLoadListener(String picId) {
            this.picId = picId;
        }

        @Override
        public void onResourceReady(File file, GlideAnimation<? super File> glideAnimation) {
            if (!isDetached()) {
                if (!ResponseUtil.isEmptyList(mArticlePicList)) {
                    ArticlePicEntity articlePicEntity = mArticlePicList.get(Integer.valueOf(picId));
                    articlePicEntity.isFail = 0;
                    handleImageFile(file, articlePicEntity);
                    if (articlePicEntity.isGif == 1) {
                        //Gif图片非第一帧加载完毕时将图片加载完毕标志置为1
                        if (articlePicEntity.isKeyGif != 1) {
                            articlePicEntity.isPicLoad = 1;
                        }
                    } else {
                        //非Gif图片加载完毕时将图片加载完毕标志置为1
                        articlePicEntity.isPicLoad = 1;
                    }

                    if (articlePicEntity.isPicLoad == 1
                            && !ResponseUtil.isEmptyList(mArticleContentEntity.articlePictureList)) {
                        for (ArticlePicEntity entity : mArticleContentEntity.articlePictureList) {
                            if (!TextUtils.isEmpty(entity.originalPicUrl)
                                    && entity.originalPicUrl.equals(articlePicEntity.originalPicUrl)) {
                                entity.isPicLoad = 1;
                                break;
                            }
                        }
                    }

                }
            }
        }

        @Override
        public void onLoadStarted(Drawable placeholder) {
            //FIXME
            try {
                if (mPicStateEntityMap != null) {
                    ArticleDetailPicStateEntity articleDetailPicStateEntity = mPicStateEntityMap.get(picId);
                    if (articleDetailPicStateEntity != null) {
                        articleDetailPicStateEntity.isLoading = true;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onLoadFailed(Exception e, Drawable errorDrawable) {
            if (isDetached() || isClosing()) {
                return;
            }

            //FIXME
            try {
                if (!ResponseUtil.isEmptyList(mArticlePicList)) {
                    int position = Integer.valueOf(picId);
                    if (position < mArticlePicList.size() && position >= 0) {
                        ArticlePicEntity picEntity = mArticlePicList.get(Integer.valueOf(picId));
                        if (picEntity == null) {
                            return;
                        }
                        picEntity.isFail = 1;
                        showImgFailState(picEntity);
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }

        }
    }

    @Override
    public void destroy() {
        super.destroy();
//        if (mArticleDetailDate != null) {
//            try {
//                FlowConManager.getInstance().checkClearWebViewProxy(mArticleDetailDate);
//                mArticleDetailDate.removeAllViews();
//                mArticleDetailDate.destroy();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
        BusProvider.unregister(this);
    }

    /**
     * 最终页阅读数据上报相关函数
     */
    @Override
    public void restart() {
        if (mActivity != null) {
            mActivity.setArticleDetailData(ArticleDetailReportEntity.START_READ_TIME, System.currentTimeMillis());
        }
    }

    @Override
    public void stop() {
        if (mActivity != null) {
            mActivity.setArticleDetailData(ArticleDetailReportEntity.END_READ_TIME, System.currentTimeMillis());
        }
    }

    @Override
    public int getContentHeightBeforeDestroy() {
        return mArticleContentHeight;
    }

    /**
     * 日签逻辑
     */
    private boolean isShowDateWebview() {
        String stateStr = DefaultShared.getString(Constants.KEY_DATE_WEB_VIEW, "");
        String split = "&";

        if (!TextUtils.isEmpty(stateStr)) {
            String[] splitState = stateStr.split(split);
            if (splitState != null && splitState.length == 2) {
                long time = Long.valueOf(splitState[0]);
                if (ClientUtil.isSameDay(time, System.currentTimeMillis())) {
                    int sum = Integer.valueOf(splitState[1]);
                    if (sum > 1) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public void saveDateWebviewState() {
        String stateStr = DefaultShared.getString(Constants.KEY_DATE_WEB_VIEW, "");
        String split = "&";

        if (!TextUtils.isEmpty(stateStr)) {
            String[] splitState = stateStr.split(split);
            if (splitState != null && splitState.length == 2) {
                long time = Long.valueOf(splitState[0]);
                if (ClientUtil.isSameDay(time, System.currentTimeMillis())) {
                    int sum = Integer.valueOf(splitState[1]);
                    if (sum < 2) {
                        sum++;
                        DefaultShared.putString(Constants.KEY_DATE_WEB_VIEW, System.currentTimeMillis() + "&" + sum);
                        return;
                    }
                }
            }
        }
        DefaultShared.putString(Constants.KEY_DATE_WEB_VIEW, System.currentTimeMillis() + "&" + "1");
    }
}

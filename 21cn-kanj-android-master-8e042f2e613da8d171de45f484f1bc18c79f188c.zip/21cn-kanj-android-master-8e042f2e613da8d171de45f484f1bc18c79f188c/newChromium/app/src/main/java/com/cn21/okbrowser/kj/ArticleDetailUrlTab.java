package com.cn21.okbrowser.kj;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.TabState;
import org.chromium.chrome.browser.tab.TabUma;
import org.chromium.chrome.browser.tabmodel.TabModel;
import org.chromium.ui.base.WindowAndroid;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.cn21.android.news.flowcon.FlowConManager;
import com.cn21.android.news.manage.KjJsInterface;
import com.cn21.android.news.manage.report.IArticleReport;
import com.cn21.android.news.manage.report.model.ArticleDetailReportEntity;
import com.cn21.android.news.utils.ArticleUtil;
import com.cn21.android.news.utils.WebViewUtils;
import com.squareup.otto.Subscribe;

/**
 * Created by Administrator on 2018/2/13.
 */
public class ArticleDetailUrlTab extends BaseArticleDetailTab implements IArticleReport {
    private View mReadModeHintView;
    private boolean mIsLoadComplete = false;
    private boolean mIsVisibleToUser = false;

    public ArticleDetailUrlTab(int id, boolean incognito, WindowAndroid window) {
        super(id, incognito, window);
    }

    public ArticleDetailUrlTab(int id, int parentId, boolean incognito, Context context, WindowAndroid window, TabModel.TabLaunchType type, TabUma.TabCreationState creationState, TabState frozenState) {
        super(id, parentId, incognito, context, window, type, creationState, frozenState);
    }

    @Override
    protected View initRootView() {
        return View.inflate(getActivity(), R.layout.chrome_article_detail_url_fragment, null);
    }

    @Override
    protected void initView() {
        mReadModeHintView = mRootView.findViewById(R.id.article_detail_url_fragment_read_mode_hint_view);
        mReadModeHintView.setOnClickListener(this);
        mReadOriginalView.setVisibility(View.GONE);
    }

    @Override
    protected void setContentView() {
        super.setContentView();
        long curTime = System.currentTimeMillis();
        mIsLoadComplete = true;
        mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_END_LOAD_TIME, curTime);
        if (mIsVisibleToUser) {
            mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_START_READ_TIME, curTime);
        }
        addJavascriptInterface(new KjJsInterface(mActivity), "jsInterface");
        loadUrl(mArticleContentEntity.originalUrl);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            if (mIsLoadComplete) {
                mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_START_READ_TIME, System.currentTimeMillis());
            }
        } else {
            //只有当用户看见了页面之后再次变为不可见才记录阅读结束时间
            if (mIsLoadComplete && mIsVisibleToUser) {
                mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_END_READ_TIME, System.currentTimeMillis());
            }
        }
        mIsVisibleToUser = isVisibleToUser;
    }


    @Override
    protected void initContentView() {
        super.initContentView();
//        mArticleContentView.getSettings().setUseWideViewPort(true);
//        mArticleContentView.getSettings().setLoadWithOverviewMode(true);
//        mArticleContentView.setWebViewClient(new ArticleWebViewClient());
        setWebViewClient(new ArticleWebViewClient());
    }

    @Subscribe
    public void setMarkData(String markData) {
        if(!isDetached())
            loadUrl("javascript:bridge.setMarkData('" + markData + "')");
    }

    @Override
    protected void onWebViewProgressChange(int newProgress) {
        if (mArticleContentEntity != null
                && mArticleContentEntity.hasReadMode()
                && !ArticleUtil.isPrecedenceReadMode()) {
            if (newProgress >= 100) {
                mReadModeHintView.setVisibility(View.GONE);
            } else {
                mReadModeHintView.setVisibility(View.VISIBLE);
            }
        }
        mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_TOTAL_LEN, getContentHeight());
    }

    /**
     * webView监听
     */
    private class ArticleWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (!TextUtils.isEmpty(url)) {
                //处理Scheme跳转
                Uri schemeUri = WebViewUtils.articleDetailSchemeUtils(url);
                if (schemeUri != null) {
                    return handleScheme(schemeUri);
                } else {
                    if (!url.startsWith("http")) {
                        if (url.startsWith("kanjian")) {
                            return handleScheme(Uri.parse(url));
                        } else {
                            return true;
                        }
                    } else {
                        mScrollView.scrollToFirstView();
                        view.loadUrl(url);
                        return true;
                    }
                }
            } else {
                return true;
            }

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if(mActivity!=null){
                mActivity.setArticleDetailData(ArticleDetailReportEntity.TOTAL_LEN, getContentHeight());
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            FlowConManager.getInstance().handleNetWorkFailure("ArticleDetailUrl");
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            FlowConManager.getInstance().handleNetWorkFailure("ArticleDetailUrl");
        }

        private boolean handleScheme(Uri uri) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(uri);
            mActivity.startActivity(intent);
            mActivity.overridePendingTransition(R.anim.push_right_in, R.anim.activity_notmove);
            return true;
        }
    }

    @Override
    protected void onScrollChange(int scrollY, int contentHeight) {
        mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_TOTAL_LEN, contentHeight);
        mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_READ_LEN, scrollY);
    }

    /**
     * 最终页阅读数据上报相关函数
     */
    @Override
    public void restart() {
        if(mActivity!=null){
            mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_START_READ_TIME, System.currentTimeMillis());
        }
    }

    @Override
    public void stop() {
        if(mActivity!=null){
            mActivity.setArticleDetailData(ArticleDetailReportEntity.URL_END_READ_TIME, System.currentTimeMillis());
        }
    }

    @Override
    public int getContentHeightBeforeDestroy() {
        return mArticleContentHeight;
    }
}

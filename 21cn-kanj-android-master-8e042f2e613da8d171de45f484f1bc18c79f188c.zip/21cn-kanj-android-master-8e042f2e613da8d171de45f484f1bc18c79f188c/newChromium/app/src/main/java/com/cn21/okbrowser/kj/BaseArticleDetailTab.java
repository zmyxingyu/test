package com.cn21.okbrowser.kj;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.cn21.android.news.adapter.ArticleDetailRelatedArticleAdapter2;
import com.cn21.android.news.flowcon.FlowConManager;
import com.cn21.android.news.material.events.BusProvider;
import com.cn21.android.news.model.ArticleContentEntity;
import com.cn21.android.news.model.ArticleItem;
import com.cn21.android.news.model.ArticleRelatedInfoRes;
import com.cn21.android.news.model.IArticleContentListener;
import com.cn21.android.news.model.IArticleInfoListener;
import com.cn21.android.news.ui.home.ArticleDetailActivity;
import com.cn21.android.news.ui.home.ArticleReportActivity;
import com.cn21.android.news.ui.main.BrowserActivity;
import com.cn21.android.news.ui.main.WebActivity;
import com.cn21.android.news.utils.ClientUtil;
import com.cn21.android.news.utils.Config;
import com.cn21.android.news.utils.Constants;
import com.cn21.android.news.utils.DefaultShared;
import com.cn21.android.news.utils.JsonUtil;
import com.cn21.android.news.utils.Log;
import com.cn21.android.news.utils.ResponseUtil;
import com.cn21.android.news.view.ArticleDetailHeaderView;
import com.cn21.android.news.view.FlowLayout;
import com.cn21.android.news.view.HorizonRecyclerViewDivider;
import com.cn21.android.news.view.article.ArticleContentView;
import com.cn21.android.news.view.article.CustomListLinearLayout;
import com.cn21.android.news.view.article.TouchListenerRecyclerView;
import com.cn21.android.news.view.pairScrollView.PairScrollView;
import com.cn21.ued.apm.util.UEDAgent;
import com.corp21cn.ads.listener.AdViewListener;
import com.corp21cn.ads.util.AdUtil;
import com.corp21cn.ads.view.AdView;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.TabState;
import org.chromium.chrome.browser.tab.EmptyTabObserver;
import org.chromium.chrome.browser.tab.Tab;
import org.chromium.chrome.browser.tab.TabObserver;
import org.chromium.chrome.browser.tab.TabUma;
import org.chromium.chrome.browser.tabmodel.TabModel;
import org.chromium.content_public.browser.LoadUrlParams;
import org.chromium.ui.base.WindowAndroid;

/**
 * Created by Administrator on 2018/2/11.
 */
public abstract class BaseArticleDetailTab extends Tab implements View.OnClickListener,
        IArticleInfoListener, IArticleContentListener {

    protected /*ArticleDetailActivity*/FakeArticleDetailActivity mActivity;
    protected boolean mIsInit = false;
    protected int mScreenWidth;

    protected ArticleContentEntity mArticleContentEntity;//文章内容实体
    protected ArticleRelatedInfoRes mArticleInfoEntity;//文章信息实体

    protected View mRootView;
    protected AdView mAdView;
    protected PairScrollView mScrollView;
    private ChromeArticleContentView mArticleContentView;
    protected TouchListenerRecyclerView mRelatedArticleListRv;
    protected LinearLayoutManager mRelatedArticleLayoutManager;
    protected View mReadLayout;
    protected TextView mReadOriginalView, mReadCountView;
    protected View mArticleLikeBtn;//点赞按钮
    protected TextView mArticleLikeTitleView;//点赞按钮文字以及icon
    protected View mArticleUnLikeBtn;//点踩按钮
    protected TextView mArticleUnLikeTitleView;//点踩按钮文字以及icon
    protected FlowLayout mArticleTagFlowLayout;//文章标签布局

    protected View mRelatedBlackBoardTitleView;
    protected View mRelatedBlackBoardTitleDivider;
    protected CustomListLinearLayout mRelatedBlackBoardListView;
    protected ProgressBar mWebViewProgress;
    protected View mDeclareView;
    protected View mArticleInfoLoadingView;
    protected TextView mArticleInfoLoadingHintTv;
    protected ProgressBar mArticleInfoLoadingPr;

    protected ArticleDetailRelatedArticleAdapter2 mRelatedArticleAdapter;

    private boolean mIsAdShow = false;
    private boolean mIsAdReport = false;

    public final static int STATE_LOADING = 1;
    public final static int STATE_ERROR = -1;
    public final static int STATE_SUCCESS = 2;

    private int mArticleInfoLoadingState;

    protected int mHeadVisibleRange;
    protected static final int BOTTOM_VISIBLE_DELTA = 20;
    protected int mArticleContentHeight = 0;

    private boolean mIsPostBottomGet = false;//是否提交滑动到底部事件
    private WebViewClient mWebViewClient;

    public BaseArticleDetailTab(int id, boolean incognito, WindowAndroid window) {
        super(id, incognito, window);
    }

    public BaseArticleDetailTab(int id, int parentId, boolean incognito, Context context, WindowAndroid window, TabModel.TabLaunchType type, TabUma.TabCreationState creationState, TabState frozenState) {
        super(id, parentId, incognito, context, window, type, creationState, frozenState);
        addObserver(mTabObserver);
    }

    protected final Resources getResources() {
        return getActivity().getResources();
    }

    protected final String getString(int resId) {
        return getResources().getString(resId);
    }

    protected abstract View initRootView();

    /**
     * 1、需要Tab将Fragment中的生命周期穿起来，主要是onCreateView、onActivityCreated、onDestroy
     * 解：
     *     当Tab设置了ContentViewCore之后，这边就调用onCreateView和onActivityCreated
     *     覆写Tab的destroy方法，当Tab销毁的时候就随之做销毁操作
     */


    public void onCreateView() {
        initData();
        initView();
        mHeadVisibleRange = getResources().getDimensionPixelOffset(R.dimen.header_height);
        mIsInit = true;
    }

    public void onActivityCreated() {
        //如果数据已经传递则直接设置数据
        if (mArticleContentEntity != null) {
            setContentView();
        }
        if (mArticleInfoEntity != null) {
            setArticleInfo();
        }
    }

    protected void initData() {
        mActivity = (FakeArticleDetailActivity) getActivity();
        mScreenWidth = ClientUtil.getScreenWidth(mActivity);
    }

    protected void initView() {
        mRootView = initRootView();
        initScrollView();
        initContentView();
        initLoadingView();
        initReadView();
        initArticleDigLayout();
        initRelatedArticleView();
        initRelatedBlackBoardView();
        initAdView();
        initDeclareView();
        initArticleTagView();
    }

    protected final void loadUrl(String url) {
        loadUrl(new LoadUrlParams(url));
    }

    protected final void loadDataWithBaseURL(String baseUrl, String data,
                                             String mimeType, String encoding, String historyUrl) {
        loadUrl(LoadUrlParams.createLoadDataParamsWithBaseUrl(data, mimeType,
                false, baseUrl, historyUrl, encoding));
    }

    protected final void addJavascriptInterface(Object obj, String name) {
        getContentViewCore().addJavascriptInterface(obj, name);
    }

    protected final void setWebViewClient(WebViewClient webViewClient) {
        mWebViewClient = webViewClient;
    }

    protected final long getContentHeight() {
        return mArticleContentView.getRealContentHeight();
    }

    protected void setUserVisibleHint(boolean isVisibleToUser) {

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

    }

    protected void showLoadingProgress() {
        showLoadingProgress("");
    }

    protected ProgressDialog progressDialog;

    protected void showLoadingProgress(String hint) {
        progressDialog = new ProgressDialog(this.getActivity());
        if(!TextUtils.isEmpty(hint)){
            progressDialog.setMessage(hint);
        }else{
            progressDialog.setMessage(getResources().getString(R.string.common_waiting));
        }
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(true);
        progressDialog.setIndeterminate(true);
        progressDialog.show();
    }

    protected void dismissLoadingProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    /**
     * 滚动布局
     */
    private void initScrollView() {
        mScrollView = (PairScrollView) mRootView.findViewById(R.id.article_detail_fragment_scroll);
        mScrollView.setOnScrollListener(new ArticleScrollListener());
        mScrollView.scrollToFirstView();
    }

    /**
     * 初始化内容以及进度条初始化
     */
    protected void initContentView() {
        mWebViewProgress = (ProgressBar) mRootView.findViewById(R.id.article_detail_fragment_web_view_progress);
//        mArticleContentView = (ArticleContentView) mRootView.findViewById(R.id.article_detail_fragment_content_view);
//        mArticleContentView.setWebChromeClient(new ArticleChromeListener());
        mArticleContentView = (ChromeArticleContentView) super.getContentView();
    }

    /**
     * 初始化加载布局
     */
    protected void initLoadingView() {
        mArticleInfoLoadingState = STATE_LOADING;
        mArticleInfoLoadingView = mRootView.findViewById(R.id.article_detail_info_loading_view);
        mArticleInfoLoadingPr = (ProgressBar) mRootView.findViewById(R.id.article_detail_fragment_info_progressbar);
        mArticleInfoLoadingHintTv = (TextView) mRootView.findViewById(R.id.article_detail_fragment_info_hint_tv);
        mArticleInfoLoadingView.setOnClickListener(this);
    }

    /**
     * 初始话点赞点踩布局
     */
    protected void initArticleDigLayout() {
        mArticleLikeBtn = mRootView.findViewById(R.id.article_detail_like_btn);
        mArticleLikeTitleView = (TextView) mRootView.findViewById(R.id.article_detail_like_title_tv);
        mArticleUnLikeBtn = mRootView.findViewById(R.id.article_detail_un_like_btn);
        mArticleUnLikeTitleView = (TextView) mRootView.findViewById(R.id.article_detail_un_like_title_tv);
        mArticleLikeBtn.setOnClickListener(this);
        mArticleUnLikeBtn.setOnClickListener(this);
    }

    /**
     * 初始化相关文章
     */
    private void initRelatedArticleView() {
        mRelatedArticleListRv = (TouchListenerRecyclerView) mRootView.findViewById(R.id.article_detail_related_article_list);
        mRelatedArticleLayoutManager = new LinearLayoutManager(mActivity);
        mRelatedArticleLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRelatedArticleListRv.setLayoutManager(mRelatedArticleLayoutManager);
        HorizonRecyclerViewDivider divider = new HorizonRecyclerViewDivider(mActivity, ClientUtil.dip2px(mActivity, 8));
        divider.setFirsLeftMargin(ClientUtil.dip2px(mActivity, 15));
        divider.setEndRightMargin(ClientUtil.dip2px(mActivity, 15));
        mRelatedArticleListRv.addItemDecoration(divider);
        mRelatedArticleAdapter = new ArticleDetailRelatedArticleAdapter2(mActivity);
        mRelatedArticleAdapter.setOnItemClickListener(new RelatedArticleClickListener());
        mRelatedArticleListRv.setAdapter(mRelatedArticleAdapter);
        mScrollView.setTouchListenerRecyclerView(mRelatedArticleListRv);
    }

    /**
     * 初始化阅读相关
     */
    private void initReadView() {
        mReadLayout = mRootView.findViewById(R.id.article_detail_info_read_layout);
        mReadOriginalView = (TextView) mRootView.findViewById(R.id.article_detail_fragment_info_read_original_tv);
        mReadCountView = (TextView) mRootView.findViewById(R.id.article_detail_fragment_info_read_count_tv);
        mReadOriginalView.setOnClickListener(this);
        TextView reportTv = (TextView) mRootView.findViewById(R.id.article_detail_fragment_info_report_tv);
        reportTv.setOnClickListener(this);
    }

    /**
     * 初始化相关黑板报
     */
    private void initRelatedBlackBoardView() {
        mRelatedBlackBoardTitleView = mRootView.findViewById(R.id.article_detail_related_black_board_title);
        mRelatedBlackBoardTitleDivider = mRootView.findViewById(R.id.article_detail_related_black_board_title_divider);
        mRelatedBlackBoardListView = (CustomListLinearLayout) mRootView.findViewById(R.id.article_detail_related_black_board_list);
    }

    /**
     * 初始化相关黑板报
     */
    private void initAdView() {
        mAdView = (AdView) mRootView.findViewById(R.id.adview);
        mAdView.setAdViewListener(new MyAdListener());
        mAdView.setCloseable(false);
        mAdView.setTagViewVisible(true);
    }

    /**
     * 初始化版权声明
     */
    private void initDeclareView() {
        mDeclareView = mRootView.findViewById(R.id.article_detail_declare_layout);
        mDeclareView.setOnClickListener(this);
    }

    /**
     * 初始化文章标签布局
     */
    private void initArticleTagView() {
        mArticleTagFlowLayout = (FlowLayout) mRootView.findViewById(R.id.article_detail_tag_flow_layout);
    }

    /**
     * 视图设置内容
     */
    protected void setArticleInfo() {
        setReadView();
        setRelatedArticleView();
        //setArticleTagView();
        //mDeclareView.setVisibility(View.VISIBLE);
        //设置完毕关闭加载布局
        setArticleInfoLoadingView(STATE_SUCCESS);
    }

    /**
     * 设置文章内容
     */
    protected void setContentView() {
//        FlowConManager.getInstance().setFlowConProxyWebView(mArticleContentView, "ArticleDetail");
        setAdView();
    }

    private void setAdView() {
        if (mArticleContentEntity == null) {
            return;
        }

        //当文章内容刷新时广告不再重新请求
        if (!mIsAdReport) {
            //设置广告TAG
            mAdView.start("tabSource=1&userTabId=" + DefaultShared.getString(Constants.KEY_AD_USER_TAG, "") + "&articleTabId=" + mArticleContentEntity.groupId);
        }
    }

    /**
     * webView 加载进度
     *
     * @param newProgress
     */
    protected void onWebViewProgressChange(int newProgress) {
        if (newProgress < 100) {
            mWebViewProgress.setVisibility(View.VISIBLE);
            mWebViewProgress.setProgress(newProgress);
        } else {
            String str = DefaultShared.getString(Constants.ARTICLERELATEDINFORES, "");
            if(!TextUtils.isEmpty(str)){
                BusProvider.setMarkDataAll(JsonUtil.fromJsonString(str, ArticleRelatedInfoRes.class));
                DefaultShared.putString(Constants.ARTICLERELATEDINFORES, "");
            }
            mWebViewProgress.setVisibility(View.GONE);
        }
    }

    /**
     * 布局滚动回调
     *
     * @param scrollY
     * @param contentHeight
     */
    protected void onScrollChange(int scrollY, int contentHeight) {

    }

    /**
     * 设置加载状态
     */
    private void setArticleInfoLoadingView(int loadingState) {
        mArticleInfoLoadingState = loadingState;
        switch (loadingState) {
            case STATE_LOADING:
                mArticleInfoLoadingView.setVisibility(View.VISIBLE);
                mArticleInfoLoadingPr.setVisibility(View.VISIBLE);
                mArticleInfoLoadingHintTv.setText("加载中");
                break;
            case STATE_ERROR:
                mArticleInfoLoadingView.setVisibility(View.VISIBLE);
                mArticleInfoLoadingPr.setVisibility(View.GONE);
                mArticleInfoLoadingHintTv.setText("加载数据失败，点击重试");
                break;
            case STATE_SUCCESS:
                mArticleInfoLoadingView.setVisibility(View.GONE);
                break;
            default:
                break;
        }
    }

    /**
     * 设置阅读原文
     */
    private void setReadView() {
        if (mArticleInfoEntity == null || mArticleInfoEntity.article == null) {
            return;
        }
        mReadLayout.setVisibility(View.VISIBLE);
        if(mArticleInfoEntity.mark!=null){
            mReadCountView.setText(String.format(getString(R.string.article_detail_read_count), "" + mArticleInfoEntity.mark.readNum));
        }else
            mReadCountView.setText(String.format(getString(R.string.article_detail_read_count), "" + mArticleInfoEntity.article.readNum));
    }

    /**
     * 设置相关文章
     */
    private void setRelatedArticleView() {
        if (mArticleInfoEntity == null || mArticleInfoEntity.relatedArticles == null) {
            return;
        }

        if (!ResponseUtil.isEmptyList(mArticleInfoEntity.relatedArticles.list)) {
            mRelatedArticleListRv.setVisibility(View.VISIBLE);
            mRelatedArticleAdapter.setArticleList(mArticleInfoEntity.relatedArticles.list);
            mRelatedArticleAdapter.notifyDataSetChanged();
        } else {
            mRelatedArticleListRv.setVisibility(View.GONE);
        }
    }

    /**
     * 处理广告上报事件
     */
    private void handleReportAd() {
        //只上报一次，并且只在广告信息接收成功以及文章信息请求成功
        if (!mIsAdReport &&
                mIsAdShow &&
                mArticleInfoEntity != null) {
            //由于为嵌套布局所以adView的top需要加上一滑动布局的scrollRange*/
            int halfTotalScrollRangeY = (int) (0.5 * (float) mScrollView.getFirstViewScrollRange());
            if (mScrollView.getTotalScrollY() >= halfTotalScrollRangeY) {
                mIsAdReport = true;
                //广告上报
                mAdView.show();
            }
        }
    }

    /**
     * 文章信息请求
     */
    @Override
    public void onPreRequest() {
        //文章信息请求中监听 显示加载中布局
        if (mIsInit && !isDetached()) {
            setArticleInfoLoadingView(STATE_LOADING);
        }
    }

    /**
     * 文章信息请求成功
     */
    @Override
    public void onPostResult(ArticleRelatedInfoRes entity, boolean isFromNet) {
        mArticleInfoEntity = entity;
        if (mIsInit && !isDetached()) {
            setArticleInfo();
        }
    }

    /**
     * 文章信息请求失败
     */
    @Override
    public void onFailed(int code, String msg,String markId) {
        //文章信息加载失败 显示加载失败布局
        if (mIsInit && !isDetached()) {
            Log.i("msg", "====markId=" + markId);
            if(TextUtils.isEmpty(markId) || "undefined".equalsIgnoreCase(markId)){
                setArticleInfoLoadingView(STATE_SUCCESS);
            }else{
                setArticleInfoLoadingView(STATE_ERROR);
            }
        }
    }

    /**
     * 文章内容请求成功
     */
    @Override
    public void onPostResult(ArticleContentEntity entity, boolean isFromNet) {
        //文章内容加载监听
        mArticleContentEntity = entity;
        if (mIsInit && !isDetached()) {
            setContentView();
        }
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.article_detail_declare_layout) {
            BrowserActivity.openActivity(mActivity, "版权声明", Config.COPYRIGHT_URL);
            mActivity.postArticleDetailData();

        } else if (i == R.id.article_detail_info_loading_view) {
            if (mArticleInfoLoadingState == STATE_ERROR) {
                mActivity.reloadRelatedInfo();
            }

        } else if (i == R.id.article_detail_fragment_info_read_original_tv) {//阅读原文
            if (mArticleContentEntity != null) {
                BrowserActivity.openActivity(mActivity, getString(R.string.detail_read_original), mArticleContentEntity.originalUrl);
                mActivity.postArticleDetailData();
            }

        } else if (i == R.id.article_detail_fragment_info_report_tv) {
            if (mArticleContentEntity != null && mArticleInfoEntity != null && mArticleInfoEntity.mark != null) {
                ArticleReportActivity.openActivity(getActivity(), mArticleContentEntity.id, mArticleInfoEntity.mark.markId, ArticleReportActivity.REPORT_COMPLAIN);
            } else {
                if (mArticleContentEntity != null)
                    ArticleReportActivity.openActivity(getActivity(), mArticleContentEntity.id, "", ArticleReportActivity.REPORT_COMPLAIN);
            }

        } else {
        }
    }

    private void handleBottomGet(int scrollY) {
        if (scrollY + mRootView.getHeight() > mArticleContentView.getRealContentHeight()
                && !mIsPostBottomGet) {
            mIsPostBottomGet = true;
            UEDAgent.trackCustomKVEvent(mActivity, "article_bottom_show", null, null);
        }
    }

    /**
     * 布局滚动监听
     */
    class ArticleScrollListener implements PairScrollView.OnScrollChangeListener {

        @Override
        public void onScrollChanged(int l, int t, int oldl, int oldt) {
            handleReportAd();
            //只有在获取到文章信息之后才进行头部变换
            if (mArticleInfoEntity != null) {
                if (t >= mHeadVisibleRange) {
                    mActivity.setHeadViewState(ArticleDetailHeaderView.MULTI_RECOMMEND_VISIBLE);
                } else {
                    mActivity.setHeadViewState(ArticleDetailHeaderView.URL_ADDRESS_VISIBLE);
                }
            }

//            if(t - oldt > BOTTOM_VISIBLE_DELTA){
//                mActivity.setBottomViewState(ArticleDetailBottomView.INVISIBLE);
//            }else if(oldt - t > BOTTOM_VISIBLE_DELTA){
//                mActivity.setBottomViewState(ArticleDetailBottomView.VISIBLE);
//            }
            if (mScrollView != null) {
                onScrollChange(t, mScrollView.getRealContentHeight());
            }
            handleBottomGet(t);

        }
    }

    /**
     * 广告监听
     */
    class MyAdListener extends AdViewListener {

        @Override
        public void onReceiveAd(String s) {
            mIsAdShow = true;
            if (AdUtil.PLATFORM_SELF.equals(s)) {
                mAdView.setAdTargetSize("match_parent", "130");
            }
        }

        @Override
        public void onReceiveFailed(int error)  {
        }

        @Override
        public void onClickAd() {
        }

        @Override
        public void onClickAd(int event, String eventValue) {
            if (event == AdUtil.E_OPEN_PAGE) {
                WebActivity.openActivity(mActivity, "广告浏览", eventValue);
                mActivity.postArticleDetailData();
            } else if (event == AdUtil.E_DOWNLOAD) {
                WebActivity.openActivity(mActivity, "广告浏览", eventValue);
                mActivity.postArticleDetailData();
            }
        }

        @Override
        public void onCloseAd() {
        }

        @Override
        public void onDisplayAd() {
        }
    }

    /**
     * 相关文章阅读
     * <p/>
     * onItemClick相关阅读文章Item点击事件
     * onMoreClick更多阅读点击事件
     */
    class RelatedArticleClickListener implements ArticleDetailRelatedArticleAdapter2.OnItemClickListener {
        @Override
        public void onItemClick(int position, RecyclerView.ViewHolder viewHolder) {
            if (mArticleInfoEntity != null &&
                    mArticleInfoEntity.relatedArticles != null &&
                    !ResponseUtil.isEmptyList(mArticleInfoEntity.relatedArticles.list)) {
                ArticleItem articleItem = mArticleInfoEntity.relatedArticles.list.get(position);
                String authorOpenid = "";
                if (articleItem.user != null) {
                    authorOpenid = articleItem.user.openid;
                }

                UEDAgent.trackCustomKVEvent(mActivity, "ArticleDetail_RelatedArticle_click", null, null);
                ArticleDetailActivity.openActivity(mActivity,articleItem.id,
                        articleItem.originalUrl,ArticleDetailActivity.RELATIVE,authorOpenid);

                mActivity.postArticleDetailData();
            }

        }

        @Override
        public void onGroupClick(int position, View view) {

        }

        @Override
        public void onMoreClick() {
            /*if (mArticleInfoEntity != null &&
                    mArticleInfoEntity.relatedArticles != null) {
                if (mArticleInfoEntity.relatedArticles.type == Constants.COMMON_RELATED_ARTICLES_TYPE_USER_RECOMMEND) {
                    if (mArticleInfoEntity.article != null &&
                            mArticleInfoEntity.article.user != null) {
                        UserInfoActivity.openActivity(mActivity, mArticleInfoEntity.article.user.openid);
                        mActivity.postArticleDetailData();
                    }
                } else {
                    if (mArticleInfoEntity.article != null &&
                            mArticleInfoEntity.article.user != null) {
                        GroupArticleActivity.openActivity(mActivity, mArticleInfoEntity.article.groupId, mArticleInfoEntity.article.groupName);
                        mActivity.postArticleDetailData();
                    }
                }
            }*/
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        if (mArticleContentView != null) {
            try {
//                FlowConManager.getInstance().checkClearWebViewProxy(mArticleContentView);
                mArticleContentHeight = mArticleContentView.getRealContentHeight();
                mArticleContentView.removeAllViews();
                mArticleContentView.destroy();
            }catch (Exception e){

            }
        }
    }

    @Override
    protected boolean maybeShowNativePage(String url, boolean forceReload) {
        //不显示本地原生页面，只显示webview
        return false;
    }

    @Override
    protected void showSadTab() {
        //do nothing
    }

    @Override
    public View getContentView() {
        View webView = super.getContentView();
        if (mScrollView.indexOfChild(webView) == -1) {
            addWebViewInRootView(webView);
        }
        return webView;
    }

    @Override
    public View getView() {
        View webView = super.getView();
        if (mScrollView.indexOfChild(webView) == -1) {
            addWebViewInRootView(webView);
        }
        return webView;
    }

    protected void addWebViewInRootView(View webView) {
        if (mScrollView.getChildCount() > 1) {
            mScrollView.removeViewAt(0);
        }
        mScrollView.addView(webView, 0);
    }

    private final TabObserver mTabObserver = new EmptyTabObserver() {
        @Override
        public void onContentChanged(Tab tab) {
            super.onContentChanged(tab);
            onCreateView();
            onActivityCreated();
        }

        @Override
        public void onShown(Tab tab) {
            super.onShown(tab);
            setUserVisibleHint(true);
        }

        @Override
        public void onHidden(Tab tab) {
            super.onHidden(tab);
            setUserVisibleHint(false);
        }

        @Override
        public void onPageLoadStarted(Tab tab, String url) {
            super.onPageLoadStarted(tab, url);
            if (mWebViewClient != null) {
                mWebViewClient.onPageStarted(null, url, getFavicon());
            }
        }

        @Override
        public void onDidFinishNavigation(Tab tab, String url, boolean isInMainFrame, boolean isErrorPage, boolean hasCommitted, boolean isSameDocument, boolean isFragmentNavigation, Integer pageTransition, int errorCode, int httpStatusCode) {
            super.onDidFinishNavigation(tab, url, isInMainFrame, isErrorPage, hasCommitted, isSameDocument, isFragmentNavigation, pageTransition, errorCode, httpStatusCode);
            if (mWebViewClient != null && isInMainFrame && hasCommitted) {
                mWebViewClient.onPageFinished(null, url);
            }
        }

        @Override
        public void onDidFailLoad(Tab tab, boolean isMainFrame, int errorCode, String description, String failingUrl) {
            super.onDidFailLoad(tab, isMainFrame, errorCode, description, failingUrl);
            if (mWebViewClient != null) {
                mWebViewClient.onReceivedError(null, errorCode, description, failingUrl);
            }
        }

        @Override
        public void onLoadProgressChanged(Tab tab, int progress) {
            super.onLoadProgressChanged(tab, progress);
            onWebViewProgressChange(progress);
        }

        @Override
        public void onLoadUrl(Tab tab, LoadUrlParams params, int loadType) {
            super.onLoadUrl(tab, params, loadType);
            if (mWebViewClient != null) {
                final String url = TextUtils.isEmpty(params.getUrl()) ?
                        params.getBaseUrl() : params.getUrl();
                if (!mWebViewClient.shouldOverrideUrlLoading(null, url)) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setData(Uri.parse(url));
                    getActivity().startActivity(intent);
                }
                tab.stopLoading();
            }
        }

    };
}

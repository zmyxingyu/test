package com.cn21.okbrowser.kj;

import org.chromium.content.browser.ContentView;
import org.chromium.content.browser.ContentViewCore;

import android.content.Context;
import android.os.Build;
import android.support.v4.view.ViewCompat;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.ViewStructure;
import android.widget.Scroller;

import com.cn21.android.news.view.pairScrollView.PairScroll;

/**
 * Created by Administrator on 2018/2/11.
 */
public class ChromeArticleContentView extends ContentView implements PairScroll {
    private Context context;
    private PairScroll.OnScrollChangeListener onScrollChangeListener;

    private VelocityTracker mVelocityTracker;

    private int mVelocityY;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private boolean mEnableScroll = true;

    private Scroller mScroller;

    /**
     * Constructs a new ContentView for the appropriate Android version.
     * @param context The Context the view is running in, through which it can
     *                access the current theme, resources, etc.
     * @param cvc A pointer to the content view core managing this content view.
     * @return an instance of a ContentView.
     */
    public static ContentView createContentView(Context context, ContentViewCore cvc) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return new ChromeContentViewApi23(context, cvc);
        }
        return new ChromeArticleContentView(context, cvc);
    }

    /**
     * Creates an instance of a ContentView.
     *
     * @param context The Context the view is running in, through which it can
     *                access the current theme, resources, etc.
     * @param cvc     A pointer to the content view core managing this content view.
     */
    public ChromeArticleContentView(Context context, ContentViewCore cvc) {
        super(context, cvc);
        this.context = context;
        init();
    }

    private void init() {
//        WebSettings settings = this.getSettings();
//        settings.setJavaScriptEnabled(true);
//        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
//        settings.setDefaultTextEncodingName("UTF-8");
//        settings.setDomStorageEnabled(true);
        mContentViewCore.setAllowJavascriptInterfacesInspection(true);

        mScroller = new Scroller(context);
        mMinimumVelocity = ViewConfiguration.get(context).getScaledMinimumFlingVelocity();
        mMaximumVelocity = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (mEnableScroll) {
            switch (ev.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (!mScroller.isFinished()) {
                        mScroller.abortAnimation();
                    }
                    initOrResetVelocityTracker();
                    mVelocityTracker.addMovement(ev);
                    mVelocityY = 0;
                    break;
                case MotionEvent.ACTION_MOVE:
                    initVelocityTrackerIfNotExists();
                    mVelocityTracker.addMovement(ev);
                    break;
                case MotionEvent.ACTION_UP:
                    mVelocityTracker.computeCurrentVelocity(1000, mMaximumVelocity);
                    mVelocityY = (int) mVelocityTracker.getYVelocity(0);
                    recycleVelocityTracker();
                    break;
                case MotionEvent.ACTION_CANCEL:
                    mVelocityY = 0;
                    recycleVelocityTracker();
                    break;
                default:
                    break;
            }
            return super.onTouchEvent(ev);
        } else {
            return true;
        }

    }

    @Override
    public boolean isTop() {
        return getScrollY() == 0;
    }

    @Override
    public boolean isBottom() {
        return getScrollY() + getHeight() >= computeVerticalScrollRange();
    }

    @Override
    public void scroll(int velocity) {
        mScroller.fling(getScrollX(), getScrollY(), 0, velocity, 0, computeHorizontalScrollRange(), 0,
                computeVerticalScrollRange());
        ViewCompat.postInvalidateOnAnimation(this);
    }

    @Override
    public void stopScroll() {
        if (mScroller != null) {
            if (!mScroller.isFinished()) {
                mScroller.abortAnimation();
            }
        }
    }

    @Override
    public int computeScrollRange() {
        return computeVerticalScrollRange();
    }

    @Override
    public void computeScroll() {
        if (mScroller.computeScrollOffset()) {
            int oldX = getScrollX();
            int oldY = getScrollY();
            int x = mScroller.getCurrX();
            int y = mScroller.getCurrY();

            if (oldX != x || oldY != y) {
                int dy = y - oldY;
                scrollBy(getScrollX(), dy);
                if (!awakenScrollBars()) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
            } else {
                mScroller.forceFinished(true);
            }
        } else {
            super.computeScroll();
        }
    }

    @Override
    public void setScrollEnable(boolean enable) {
        mEnableScroll = enable;
    }

    private void initOrResetVelocityTracker() {
        if (mVelocityTracker == null) {
            mVelocityTracker = VelocityTracker.obtain();
        } else {
            mVelocityTracker.clear();
        }
    }

    private void initVelocityTrackerIfNotExists() {
        if (mVelocityTracker == null) {
            mVelocityTracker = VelocityTracker.obtain();
        }
    }

    private void recycleVelocityTracker() {
        if (mVelocityTracker != null) {
            mVelocityTracker.recycle();
            mVelocityTracker = null;
        }
    }

    private OnClickListener clickListener;

    public void setOnClickListener(OnClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public interface OnClickListener {
        void onWebViewClick();
    }

    public void destroy() {
//        clearHistory();
//        clearFormData();
//        clearCache(true);
        //FIXME
        try {
            mContentViewCore.destroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setScrollChangeListener(PairScroll.OnScrollChangeListener onScrollChangeListener) {
        this.onScrollChangeListener = onScrollChangeListener;
    }

    @Override
    public void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (onScrollChangeListener != null) {
            onScrollChangeListener.onScroll(l, t, oldl, oldt, mVelocityY);
        }
    }

    /**
     * 解决api17以下的手机上出现滚动冲突的问题
     */
    @Deprecated
    public void scrollChange() {
        onScrollChanged(getScrollX(), getScrollY(), getScrollX(), getScrollY());
    }

    @Override
    public int getRealContentHeight(){
        return (int)(mContentViewCore.getContentHeightCss() * mContentViewCore.getScale());
    }

    private static class ChromeContentViewApi23 extends ChromeArticleContentView {
        public ChromeContentViewApi23(Context context, ContentViewCore cvc) {
            super(context, cvc);
        }

        @Override
        public void onProvideVirtualStructure(final ViewStructure structure) {
            mContentViewCore.onProvideVirtualStructure(structure, false);
        }
    }
}

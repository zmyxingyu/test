package com.cn21.okbrowser.kj;

import org.chromium.chrome.browser.ChromeTabbedActivity;

import com.cn21.android.news.net.retrofit.NewsApi;
import com.cn21.android.news.net.retrofit.RetrofitService;

/**
 * Created by Administrator on 2018/2/11.
 */
public class FakeArticleDetailActivity extends ChromeTabbedActivity {

    private NewsApi mNewsApi = RetrofitService.createApi(NewsApi.class);

    public void postArticleDetailData() {

    }

    public void reloadRelatedInfo() {

    }

    public void setHeadViewState(int state) {

    }

    public void setArticleDetailData(String tag, long time) {

    }

    public NewsApi getmNewsApi() {
        return mNewsApi;
    }

    public void setBottomVisible(int flag) {

    }
}

package com.cn21.okbrowser.kj;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import com.cn21.android.news.view.pairScrollView.PairScroll;

/**
 * Created by Administrator on 2018/2/12.
 */
public class FakeView extends FrameLayout implements PairScroll{

    public FakeView(@NonNull Context context) {
        super(context);
    }

    public FakeView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean isBottom() {
        return false;
    }

    @Override
    public boolean isTop() {
        return false;
    }

    @Override
    public void scroll(int velocity) {

    }

    @Override
    public void stopScroll() {

    }

    @Override
    public int computeScrollRange() {
        return 0;
    }

    @Override
    public void setScrollChangeListener(PairScroll.OnScrollChangeListener onScrollChangeListener) {

    }

    @Override
    public void setScrollEnable(boolean enable) {

    }

    @Override
    public int getRealContentHeight() {
        return 0;
    }
}

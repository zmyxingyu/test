package com.cn21.okbrowser.onekit;

import android.content.Context;
import android.util.Log;

import com.cn21.onekit.core.OneKitConfig;
import com.cn21.onekit.core.OneKitManager;
import com.cn21.onekit.core.OneKitRuntime;
import com.cn21.onekit.lib.update.ResourceDownloadListener;
import com.cn21.onekit.lib.update.ResourcePackageManager;
import com.cn21.ued.apm.util.UEDAgent;

/**
 * Created by Administrator on 2018/2/4.
 */

public class OneKitUtil {

    public static void initOnekit(Context context) {
        Log.e("zmy", "init Onekit");
        OneKitManager.createInstance(context, oneKitDownloadRuntimeImpl, new OneKitConfig.Builder().setAccessResourceType(OneKitConfig.TYPE_H5).setDebugModel(true).build());
    }

    public static void checkUpdate(Context context) {
        Log.e("zmy","checkUpdate");
        ResourcePackageManager.getInstance().setResourceDownloadLister(mResourceDownloadLister);
        ResourcePackageManager.getInstance().init(context);
    }


    private static OneKitRuntime oneKitDownloadRuntimeImpl = new OneKitRuntime() {
        String str = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0ekoQX/bOGaAapVft23N/85hI\n" +
                "niz76wPCjcYqyqNFj2Fs2c8A/a8yPMGmK0Y6ag10lllTFI+6v6yqaQlOBkkSoOej\n" +
                "WP5GTP+nY1WL4h4fmLglwHQCp3EfVOmmFHhsg+Br8rXQe+4cjSHtYGFw4srqPtCm\n" +
                "De9qQfTPXKJll3WtPwIDAQAB";
        String account = "18927520506@189.cn";

        @Override
        public String getAccount() {
            return account;
        }

        @Override
        public void setAccount(String account) {
            this.account = account;
        }

        @Override
        public String getAppSecret() {
            return "910e316d635628ab74292388a6ef10ec71f02a3e";
        }

        @Override
        public String getAppId() {
            return "A44C7F8C180746F8BB0D8CBCD11CAD83";
        }

        @Override
        public String getPackageSecret() {
            return str;
        }
    };

    private static ResourceDownloadListener mResourceDownloadLister = new ResourceDownloadListener() {

        private void log(String mes) {
            Log.e("zmy", mes);
        }
        @Override
        public void onResourceDownloadStart(int type) {
            log(String.format("onResourceDownloadStart [%d]", type));
        }

        @Override
        public void onResourceDownload(boolean success, int type) {
            log(String.format("onResourceDownload [%d][%b]", type, success));
        }

        @Override
        public void onResourceCheckMd5(boolean success, int type) {
            log(String.format("onResourceCheckMd5 [%d][%b]", type, success));
        }

        @Override
        public void onResourceUnzip(boolean success, int type) {
            log(String.format("onResourceUnzip [%d][%b]", type, success));
        }

        @Override
        public void onResourceCheckFiles(boolean success, int type) {
            log(String.format("onResourceCheckFiles [%d][%b]", type, success));
        }

        @Override
        public void onResourceUpdateSuccess(int type) {
            log(String.format("onResourceUpdateSuccess [%d]", type));
        }
    };


}
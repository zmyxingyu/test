package com.cn21.okbrowser.qrcode.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.cn21.okbrowser.qrcode.camera.CameraManager;
import com.cn21.okbrowser.qrcode.decoding.CaptureActivityHandler;
import com.cn21.okbrowser.qrcode.decoding.InactivityTimer;
import com.cn21.okbrowser.qrcode.view.ViewfinderView;
import com.cn21.okbrowser.utils.AndroidUtil;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;

import org.chromium.chrome.R;

import java.io.IOException;
import java.util.Vector;

/**
 * Initial the camera
 * @author 
 */
public class CaptureActivity extends AppCompatActivity implements Callback {
	public static final int REQUESTCODE_QRCODE = 12;

	private Context mContext;
	private CaptureActivityHandler handler;
	private ViewfinderView viewfinderView;
	private boolean hasSurface;
	private Vector<BarcodeFormat> decodeFormats;
	private String characterSet;
	private InactivityTimer inactivityTimer;
	private MediaPlayer mediaPlayer;
	private boolean playBeep;
	private static final float BEEP_VOLUME = 0.10f;
	private boolean vibrate;
	private ImageButton mBackBtn;
	private TextView mLoginTipsTv;
	private ImageView qcode_scan_middle_line_iv;
	// 方框镜头的Rect
	private Rect frame;
	
	public final static String RESULT_STRING = "result";
	

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = CaptureActivity.this;
		setContentView(R.layout.camera);
		initNavigationBar();
		initView();
	}

	private void initNavigationBar() {
		mBackBtn = (ImageButton) findViewById(R.id.nav_back);
		mBackBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				onBackPressed();
			}
		});
	}

	private void initView() {
//		mLoginTipsTv = (TextView) this.findViewById(R.id.camera_qcode_text);
		CameraManager.init(getApplication());
		viewfinderView = (ViewfinderView) findViewById(R.id.viewfinder_view);
		qcode_scan_middle_line_iv = (ImageView) this.findViewById(R.id.qcode_scan_middle_line_iv);

		// 如果网络不可用，设置背景透明度和扫描线不可用
//		if (AndroidUtil.getAvailableNetWorkInfo(mContext) == null) {
//			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
//				viewfinderView.setAlpha(0.5f);
//			} else {
//				if (viewfinderView==null) {
//					viewfinderView = (ViewfinderView) findViewById(R.id.viewfinder_view);
//				}
//				if (viewfinderView.getBackground() != null) {
//					viewfinderView.getBackground().setAlpha(128);
//				}
//			}
//			qcode_scan_middle_line_iv.setVisibility(View.GONE);
//		} else {
//			qcode_scan_middle_line_iv.setVisibility(View.VISIBLE);
//		}
		hasSurface = false;
		inactivityTimer = new InactivityTimer(this);
	}

	@Override
	public void onResume() {
		super.onResume();
		SurfaceView surfaceView = (SurfaceView) findViewById(R.id.preview_view);
		SurfaceHolder surfaceHolder = surfaceView.getHolder();
		if (hasSurface) {
			initCamera(surfaceHolder);
		} else {
			surfaceHolder.addCallback(this);
		}
		surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		decodeFormats = null;
		characterSet = null;

		playBeep = true;
		AudioManager audioService = (AudioManager) getSystemService(AUDIO_SERVICE);
		if (audioService.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) {
			playBeep = false;
		}
		initBeepSound();
		vibrate = true;

		frame = CameraManager.get().getFramingRect();
		if (frame == null) {
			// 第一次进入时frame为空，要延迟执行，等ViewfinderView调用onDraw方法getFramingRect才有值
			new Handler().postDelayed(new Runnable(){
				@Override
				public void run() {
					frame = CameraManager.get().getFramingRect();
					if (frame != null) {
						setImageViewScanAnimation();
					}
				}
			}, 500);
		} else {
			frame = CameraManager.get().getFramingRect();
			setImageViewScanAnimation();
		}
	}

	/**
	 * 设置ImageView的扫描动画
	 */
	private void setImageViewScanAnimation() {
		if (qcode_scan_middle_line_iv.getVisibility() == View.VISIBLE) {
			int width = (int) (mContext.getResources().getDisplayMetrics().widthPixels * 0.7);
			ViewGroup.LayoutParams lp = qcode_scan_middle_line_iv.getLayoutParams();
			lp.width = width;
			qcode_scan_middle_line_iv.setLayoutParams(lp);
			qcode_scan_middle_line_iv.clearAnimation();
			int margintTop = AndroidUtil.px2dip(mContext, 30.0f);
			int marginBottom = AndroidUtil.px2dip(mContext, 80.0f);
			TranslateAnimation animation =
					new TranslateAnimation(0, 0, frame.top + margintTop, frame.bottom - marginBottom);
			animation.setDuration(2000);    // 设置动画持续时间
			animation.setRepeatCount(-1);   // 设置重复次数
			animation.setInterpolator(new LinearInterpolator());    //匀速
			qcode_scan_middle_line_iv.startAnimation(animation);
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (handler != null) {
			handler.quitSynchronously();
			handler = null;
		}
		CameraManager.get().closeDriver();
	}

	@Override
	protected void onDestroy() {
		inactivityTimer.shutdown();
		super.onDestroy();
	}

	@Override
	public void onBackPressed() {
		CaptureActivity.this.finish();
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
			CaptureActivity.this.overridePendingTransition(android.R.anim.fade_in, R.anim.activity_slide_out_right);
		}
	}

	/**
	 * Handler scan result
	 * @param result
	 * @param barcode
	 */
	public void handleDecode(Result result, Bitmap barcode) {
		inactivityTimer.onActivity();
		playBeepSoundAndVibrate();
		String resultString = result.getText();
		if (TextUtils.isEmpty(resultString)) {
			AndroidUtil.showToast(CaptureActivity.this, "扫码失败", Toast.LENGTH_SHORT);
		} else {
			Intent resultIntent = new Intent();
			Bundle bundle = new Bundle();
			bundle.putString(RESULT_STRING, resultString);
			resultIntent.putExtras(bundle);
			this.setResult(RESULT_OK, resultIntent);
		}
		CaptureActivity.this.finish();
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
			CaptureActivity.this.overridePendingTransition(android.R.anim.fade_in, R.anim.activity_slide_out_right);
		}
	}
	
	private void initCamera(SurfaceHolder surfaceHolder) {
		try {
			CameraManager.get().openDriver(surfaceHolder);
		} catch (IOException ioe) {
			return;
		} catch (RuntimeException e) {
			return;
		}
		if (handler == null) {
			handler = new CaptureActivityHandler(this, decodeFormats,
					characterSet);
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {

	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		if (!hasSurface) {
			hasSurface = true;
			initCamera(holder);
		}

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		hasSurface = false;

	}

	public ViewfinderView getViewfinderView() {
		return viewfinderView;
	}

	public Handler getHandler() {
		return handler;
	}

	public void drawViewfinder() {
		viewfinderView.drawViewfinder();

	}

	private void initBeepSound() {
		if (playBeep && mediaPlayer == null) {
			// The volume on STREAM_SYSTEM is not adjustable, and users found it
			// too loud,
			// so we now play on the music stream.
			setVolumeControlStream(AudioManager.STREAM_MUSIC);
			mediaPlayer = new MediaPlayer();
			mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaPlayer.setOnCompletionListener(beepListener);

			AssetFileDescriptor file = getResources().openRawResourceFd(
					R.raw.beep);
			try {
				mediaPlayer.setDataSource(file.getFileDescriptor(),
						file.getStartOffset(), file.getLength());
				file.close();
				mediaPlayer.setVolume(BEEP_VOLUME, BEEP_VOLUME);
				mediaPlayer.prepare();
			} catch (IOException e) {
				mediaPlayer = null;
			}
		}
	}

	private static final long VIBRATE_DURATION = 200L;

	private void playBeepSoundAndVibrate() {
		if (playBeep && mediaPlayer != null) {
			mediaPlayer.start();
		}
		if (vibrate) {
			Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
			vibrator.vibrate(VIBRATE_DURATION);
		}
	}

	/**
	 * When the beep has finished playing, rewind to queue up another one.
	 */
	private final OnCompletionListener beepListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mediaPlayer) {
			mediaPlayer.seekTo(0);
		}
	};

}
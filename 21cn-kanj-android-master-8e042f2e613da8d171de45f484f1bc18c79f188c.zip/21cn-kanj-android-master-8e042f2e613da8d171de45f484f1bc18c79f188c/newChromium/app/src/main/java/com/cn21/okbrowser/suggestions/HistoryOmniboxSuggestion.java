package com.cn21.okbrowser.suggestions;

import android.util.Log;

import org.chromium.chrome.browser.history.BrowsingHistoryBridge;
import org.chromium.chrome.browser.history.HistoryItem;
import org.chromium.chrome.browser.history.HistoryProvider;
import org.chromium.chrome.browser.omnibox.AutocompleteController;
import org.chromium.chrome.browser.omnibox.MatchClassificationStyle;
import org.chromium.chrome.browser.omnibox.OmniboxSuggestion;
import org.chromium.chrome.browser.omnibox.OmniboxSuggestionType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by zhangmuy on 2018/1/4.
 */

public class HistoryOmniboxSuggestion implements HistoryProvider.BrowsingHistoryObserver {
    private HistoryProvider   mHistoryProvider;

    private List<HistoryItem> historyItems;
    private List<OmniboxSuggestion> suggestions = new ArrayList<>();

    public static final long TIME_DAY = 24 * 60 * 60 * 1000;

    private boolean  mIsInitialized = false;
    AutocompleteController.OnSuggestionsReceivedListener listener;

    public HistoryOmniboxSuggestion(AutocompleteController.OnSuggestionsReceivedListener listener) {
        initialize();
        this.listener = listener;
    }

    public void onDestroyed() {
        mHistoryProvider.destroy();
        mIsInitialized = false;
    }

    public void initialize() {
        if (!mIsInitialized) {
            mIsInitialized = true;
            mHistoryProvider = new BrowsingHistoryBridge(false);
            mHistoryProvider.setObserver(this);
        }
    }

    public void queryHistory(long time) {
        mHistoryProvider.queryHistory("", time);
    }

    @Override
    public void onQueryHistoryComplete(List<HistoryItem> items, boolean hasMorePotentialMatches) {
        if (items != null && items.size() > 0) {
            historyItems = items;
            initSuggestion(items);
        }
    }

    private void initSuggestion(List<HistoryItem> items) {
        Log.e("zmy", "CusHistoryManager initSuggestion:" + items.size());
        List list = new ArrayList();
        int i = 0;
        for (HistoryItem item : items) {
            List<OmniboxSuggestion.MatchClassification> classifications = new ArrayList<>();
            classifications.add(new OmniboxSuggestion.MatchClassification(0, MatchClassificationStyle.NONE));
            list.add(new OmniboxSuggestion(
                    OmniboxSuggestionType.HISTORY_URL,
                    false,
                    i++,
                    1,
                    item.getTitle(),
                    classifications,
                    null,
                    classifications,
                    null,
                    null,
                    null,
                    item.getUrl(),
                    false,
                    false));
        }
        list = getSuggestions(list);
        synchronized (suggestions) {
            suggestions.clear();
            suggestions.addAll(list);
        }
        if (listener != null && suggestions.size() > 0) {
            listener.onSuggestionsReceived(suggestions, suggestions.get(0).getUrl());
        }
    }

    private List<OmniboxSuggestion> getSuggestions(List<OmniboxSuggestion> list) {
        Set set = new HashSet();
        List newList = new ArrayList();
        for (OmniboxSuggestion cd : list) {
            if (set.add(cd)) {
                newList.add(cd);
            }
        }
        return newList;
    }

    @Override
    public void onHistoryDeleted() {
    }

    @Override
    public void hasOtherFormsOfBrowsingData(boolean hasOtherForms, boolean hasSyncedResults) {

    }

    public List<OmniboxSuggestion> getOmniboxSuggestionsForZeroSuggest() {
        List<OmniboxSuggestion> result = null;
        synchronized (suggestions){
            if (suggestions != null && suggestions.size() > 0) {
                result = new ArrayList<>(suggestions);
            }
        }
        return result;
    }
}

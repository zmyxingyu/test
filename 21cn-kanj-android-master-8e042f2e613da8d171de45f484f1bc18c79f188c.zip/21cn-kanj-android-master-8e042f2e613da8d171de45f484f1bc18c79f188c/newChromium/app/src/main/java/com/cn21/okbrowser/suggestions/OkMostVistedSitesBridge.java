package com.cn21.okbrowser.suggestions;

import android.util.Log;

import org.chromium.chrome.browser.suggestions.MostVisitedSites;
import org.chromium.chrome.browser.suggestions.TileSource;
import org.chromium.chrome.browser.suggestions.TileVisualType;

/**
 * Created by Administrator on 2017/12/26.
 */

public class OkMostVistedSitesBridge implements MostVisitedSites {
    @Override
    public void destroy() {

    }

    @Override
    public void setObserver(Observer observer, int numSites) {

    }

    @Override
    public void addBlacklistedUrl(String url) {

    }

    @Override
    public void removeBlacklistedUrl(String url) {

    }

    @Override
    public void recordPageImpression(int tilesCount) {

    }

    @Override
    public void recordTileImpression(int index, @TileVisualType int type, @TileSource int source, String url) {
        Log.e("zmy","recordTileImpression"+url);

    }

    @Override
    public void recordOpenedMostVisitedItem(int index, @TileVisualType int type, @TileSource int source) {
        Log.e("zmy","recordTileImpression"+index);
    }
}

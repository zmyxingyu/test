package com.cn21.okbrowser.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.LinearLayout;

import org.chromium.chrome.browser.widget.selection.SelectionDelegate;

import java.util.List;

/**
 * Created by zhangmy on 2018/1/18.
 */

public class SelectableListBottombar<E> extends LinearLayout implements SelectionDelegate.SelectionObserver<E>{
    private SelectionDelegate<E> mSelectionDelegate;
    private boolean mIsDestroyed;
    public boolean mIsSelectionEnabled;

    /**
     * Constructor for inflating from XML.
     */
    public SelectableListBottombar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onSelectionStateChange(List<E> selectedItems) {
        boolean wasSelectionEnabled = mIsSelectionEnabled;
        mIsSelectionEnabled = mSelectionDelegate.isSelectionEnabled();
        Log.e("zmy", "SelectableListBottombar onSelectionStateChange size : " + selectedItems.size());
        setVisibility(mIsSelectionEnabled ? VISIBLE : GONE);
    }

    public void initialize(SelectionDelegate<E> delegate) {
        mSelectionDelegate = delegate;
        mSelectionDelegate.addObserver(this);
    }

    public void destroy() {
        mIsDestroyed = true;
        if (mSelectionDelegate != null) mSelectionDelegate.removeObserver(this);
    }

    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mIsDestroyed) return;
        mSelectionDelegate.clearSelection();
    }

    public SelectionDelegate getSelectionDelegate() {
        return mSelectionDelegate;
    }
}

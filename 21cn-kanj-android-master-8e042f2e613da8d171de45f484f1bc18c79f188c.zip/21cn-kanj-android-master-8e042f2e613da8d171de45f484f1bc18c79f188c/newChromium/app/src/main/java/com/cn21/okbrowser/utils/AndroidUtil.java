package com.cn21.okbrowser.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Patterns;
import android.widget.Toast;

import com.cn21.okbrowser.qrcode.activity.CaptureActivity;

/**
 * Created by zhangmy on 2017/12/29.
 */

public class AndroidUtil {
    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
     */
    public static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);

    }

    public static void showToast(Context context, String str, int lengthShort) {
        Toast.makeText(context,str,lengthShort).show();
    }

    // 用于获取网络标识（WIFI、CTWap、CTNet）
    public static NetworkInfo getAvailableNetWorkInfo(Context context) {
        if (context == null) {
            return null;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetInfo != null && activeNetInfo.isConnected()) {
            return activeNetInfo;
        } else {
            return null;
        }
    }

    public static boolean isUrl(String searchContent) {
        if (Patterns.WEB_URL.matcher(searchContent).matches()) {
            //符合标准
            return true;
        }
        //不符合标准
        return false;
    }
}

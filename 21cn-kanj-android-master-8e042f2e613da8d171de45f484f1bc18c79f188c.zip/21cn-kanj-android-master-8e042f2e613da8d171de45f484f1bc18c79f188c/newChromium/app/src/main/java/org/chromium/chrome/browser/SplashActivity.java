package org.chromium.chrome.browser;

import org.chromium.chrome.R;
import org.chromium.ui.widget.Toast;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Administrator on 2017/12/15.
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                launchMainActivity();
                finish();
            }
        }, 2000);
    }

    @Override
    public void onBackPressed() {

    }

    private void launchMainActivity() {
        Intent newIntent = new Intent(getIntent());
        newIntent.setClass(this, ChromeTabbedActivity.class);
        newIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            newIntent.addFlags(Intent.FLAG_ACTIVITY_RETAIN_IN_RECENTS);
        }
        Uri uri = newIntent.getData();
        if (uri != null && UrlConstants.CONTENT_SCHEME.equals(uri.getScheme())) {
            newIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        // This system call is often modified by OEMs and not actionable. http://crbug.com/619646.
        try {
            startActivity(newIntent);
        } catch (SecurityException ex) {
            Toast.makeText(
                    this, R.string.external_app_restricted_access_error,
                    Toast.LENGTH_LONG).show();
        }
    }

}

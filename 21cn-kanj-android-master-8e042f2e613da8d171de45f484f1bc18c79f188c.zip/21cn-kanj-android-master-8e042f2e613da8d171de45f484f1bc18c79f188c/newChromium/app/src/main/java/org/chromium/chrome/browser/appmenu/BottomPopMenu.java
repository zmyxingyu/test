package org.chromium.chrome.browser.appmenu;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.ChromeActivity;
import org.chromium.chrome.browser.UrlConstants;
import org.chromium.chrome.browser.bookmarks.BookmarkModel;
import org.chromium.chrome.browser.bookmarks.BookmarkUtils;
import org.chromium.chrome.browser.tab.Tab;
import org.chromium.chrome.browser.tabmodel.TabModel;
import org.chromium.components.bookmarks.BookmarkId;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.Toast;

/**
 * Created by Administrator on 2018/1/18.
 */
public class BottomPopMenu implements View.OnClickListener{
    private PopupWindow mPopWindow;
    private ChromeActivity mActivity;

    /**true表示正在执行退场动画**/
    private boolean mIsDismissAnimating;
    private View.OnClickListener mDismissClickListener;

    public BottomPopMenu(ChromeActivity activity) {
        mActivity = activity;
    }

    public boolean isMenuShowing() {
        return mPopWindow != null && mPopWindow.isShowing();
    }

    public void dismissMenu() {
        if (isMenuShowing() && !mIsDismissAnimating) {
            if (mDismissClickListener != null) {
                mDismissClickListener.onClick(null);
            } else {
                mPopWindow.dismiss();
            }
        }
    }

    public void showMenu() {
        if (isMenuShowing()) {
            dismissMenu();
            return;
        }

        if (mPopWindow == null) {
            mPopWindow = new PopupWindow(mActivity);
            mPopWindow.setFocusable(true);
            mPopWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // The window layout type affects the z-index of the popup window on M+.
            mPopWindow.setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_SUB_PANEL);
        }
        mPopWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        mPopWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);

        mPopWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        final ViewGroup root = (ViewGroup) View.inflate(mActivity, R.layout.bottom_pop_menu, null);
        prepareMenu(root);
        setupClickListeners(root);
        setupAnimation(root);

        mPopWindow.setContentView(root);
        mPopWindow.showAtLocation(mActivity.getWindow().getDecorView(), Gravity.NO_GRAVITY, 0, 0);

        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_MENU) {
                    mActivity.onMenuOrKeyboardAction(R.id.show_menu, true);
                    return true;
                }
                return false;
            }
        });
    }

    private void prepareMenu(ViewGroup root) {
        Button incognitoBtn = root.findViewById(R.id.new_incognito_tab_menu_id);
        incognitoBtn.setCompoundDrawablesWithIntrinsicBounds(0,
                mActivity.getCurrentTabModel().isIncognito() ?
                        R.drawable.opened_incognito_mode : R.drawable.incognito_mode, 0, 0);

        Button bookmarkBtn = root.findViewById(R.id.bookmark_this_page_id);
        final Tab curTab = mActivity.getActivityTab();
        if (curTab != null && curTab.getBookmarkId() != Tab.INVALID_BOOKMARK_ID) {
            bookmarkBtn.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.in_bookmark, 0, 0);
            bookmarkBtn.setText(R.string.bottom_pop_menu_added2bookmark);
        } else {
            bookmarkBtn.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.add2bookmark, 0, 0);
        }

    }

    private void setupAnimation(ViewGroup root) {
        final View content = root.findViewById(R.id.bottom_pop_menu_content);
        startSlideInOutAnimation(content, true, null);

        final View bg = root.findViewById(R.id.bottom_pop_menu_alpha_bg);
        bg.setBackgroundColor(Color.BLACK);
        startPopWindowBgAnimation(bg, true);

        final Animation.AnimationListener dismissAnimationListener = new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mIsDismissAnimating = true;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mIsDismissAnimating = false;
                mDismissClickListener = null;
                mPopWindow.dismiss();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        };
        mDismissClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPopWindowBgAnimation(bg, false);
                startSlideInOutAnimation(content, false, dismissAnimationListener);
            }
        };
        root.findViewById(R.id.btn_dismiss_pop_menu).setOnClickListener(mDismissClickListener);
        bg.setOnClickListener(mDismissClickListener);
    }

    private void setupClickListeners(ViewGroup root) {
        root.findViewById(R.id.bookmark_this_page_id).setOnClickListener(this);
        root.findViewById(R.id.open_history_menu_id).setOnClickListener(this);
        root.findViewById(R.id.reload_menu_id).setOnClickListener(this);
        root.findViewById(R.id.share_menu_id).setOnClickListener(this);
        root.findViewById(R.id.new_incognito_tab_menu_id).setOnClickListener(this);
        root.findViewById(R.id.preferences_id).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        final int btnId = v.getId();
        if (btnId == R.id.bookmark_this_page_id) {
            final Tab curTab = mActivity.getActivityTab();
            if (curTab != null) {
                final Button bookmarkBtn = (Button) v;
                if (curTab.getBookmarkId() != Tab.INVALID_BOOKMARK_ID) {
//                    bookmarkBtn.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.in_bookmark, 0, 0);
                } else {
                    final BookmarkModel model = new BookmarkModel();
                    model.runAfterBookmarkModelLoaded(new Runnable() {
                        @Override
                        public void run() {
                            BookmarkId bookmarkId = BookmarkUtils.addBookmarkSilently(
                                    mActivity, model, curTab.getTitle(), curTab.getUrl());
                            if (bookmarkId != null) {
                                bookmarkBtn.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.in_bookmark, 0, 0);
                                bookmarkBtn.setText(R.string.bottom_pop_menu_added2bookmark);
                            } else {
                                Toast.makeText(mActivity, R.string.bottom_pop_menu_add_bookmark_failed, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                return;
            }
        } else if (btnId == R.id.share_menu_id) {

        } else if (btnId == R.id.new_incognito_tab_menu_id) {
            //开关隐身模式
            final Button incognitoBtn = (Button) v;
            boolean isIncognito = mActivity.getCurrentTabModel().isIncognito();
            incognitoBtn.setCompoundDrawablesWithIntrinsicBounds(0,
                    isIncognito ? R.drawable.incognito_mode : R.drawable.opened_incognito_mode, 0, 0);

            final TabModel tabModel = mActivity.getTabModelSelector().getModel(!isIncognito);
            if (tabModel.getCount() <= 0) {
                mActivity.getTabCreator(!isIncognito).launchUrl(UrlConstants.NTP_URL, TabModel.TabLaunchType.FROM_CHROME_UI);
            } else {
                mActivity.getTabModelSelector().selectModel(!isIncognito);
            }
        } else {
            //默认按键处理方法
            mActivity.onMenuOrKeyboardAction(btnId, true);
        }
        //隐藏弹框，没有动画
        mPopWindow.dismiss();
    }

    private void startPopWindowBgAnimation(View v, boolean inOrOut) {
        v.clearAnimation();

        float startAlpha = inOrOut ? 0.0f : 0.3f;
        float endAlpha = inOrOut ? 0.3f : 0.0f;
        AlphaAnimation alphaAnimation = new AlphaAnimation(startAlpha, endAlpha);
        alphaAnimation.setInterpolator(new LinearInterpolator());
        alphaAnimation.setFillAfter(true);
        alphaAnimation.setDuration(mActivity.getResources().getInteger(R.integer.bottom_pop_menu_ani_time));
        v.startAnimation(alphaAnimation);
    }

    private void startSlideInOutAnimation(View v, boolean inOrOut, Animation.AnimationListener listener) {
        v.clearAnimation();
        Animation animation = AnimationUtils.loadAnimation(mActivity, inOrOut ? R.anim.slide_in_up : R.anim.slide_out_down);
        if (listener != null) animation.setAnimationListener(listener);
        v.startAnimation(animation);
    }

}

package org.chromium.chrome.browser.bookmarks;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import com.cn21.okbrowser.ui.view.SelectableListBottombar;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.widget.selection.SelectionDelegate;
import org.chromium.components.bookmarks.BookmarkId;

import java.util.List;

/**
 * Created by zhangmy on 2018/1/19.
 */

public class BookmarkBottombar extends SelectableListBottombar<BookmarkId> implements BookmarkUIObserver,View.OnClickListener {

    private BookmarkDelegate mDelegate;
    private View editView, moveView, deleteView, selectAllView;

    private BookmarkBridge.BookmarkModelObserver mBookmarkModelObserver = new BookmarkBridge.BookmarkModelObserver() {
        @Override
        public void bookmarkModelChanged() {
            onSelectionStateChange(mDelegate.getSelectionDelegate().getSelectedItems());
        }
    };
    private BookmarkBridge.BookmarkItem mCurrentFolder;

    @Override
    public void onSelectionStateChange(List<BookmarkId> selectedItems) {
        super.onSelectionStateChange(selectedItems);
        if (mDelegate == null) return;
        if (mIsSelectionEnabled) {

        }else{
            mDelegate.notifyStateChange(this);
        }
        notifyDataChange(selectedItems);
    }

    public BookmarkBottombar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onBookmarkDelegateInitialized(BookmarkDelegate delegate) {
        mDelegate = delegate;
        mDelegate.addUIObserver(this);
        delegate.getModel().addObserver(mBookmarkModelObserver);
    }

    @Override
    public void onDestroy() {
        mDelegate.removeUIObserver(this);
        mDelegate.getModel().removeObserver(mBookmarkModelObserver);
    }

    @Override
    public void onFolderStateSet(BookmarkId folder) {
        mCurrentFolder = mDelegate.getModel().getBookmarkById(folder);
    }

    @Override
    public void onSearchStateSet() {

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.edit_button_id:
                onEditBookmark();
                Log.e("zmy", "edit !!");
                break;
            case R.id.move_button_id:
                onMoveBookmark();
                Log.e("zmy", "move !!");
                break;
            case R.id.delete_button_id:
                new BookmarkConfirmView((BookmarkActivity) getContext(), new BookmarkConfirmView.ConfirmCallback() {
                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            onDeleteBookmark();
                        }
                    }
                }).show();
                Log.e("zmy", "delete !!");
                break;
            case R.id.select_all_button_id:
                Log.e("zmy", "select !!");
                break;
        }
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        editView = findViewById(R.id.edit_button_id);
        editView.setOnClickListener(this);
        moveView = findViewById(R.id.move_button_id);
        moveView.setOnClickListener(this);
        deleteView = findViewById(R.id.delete_button_id);
        deleteView.setOnClickListener(this);
        selectAllView = findViewById(R.id.select_all_button_id);
        selectAllView.setOnClickListener(this);
    }

    private void notifyDataChange(List<BookmarkId> selectedItems){
        if (selectedItems == null || selectedItems.size() < 1) {
            return;
        }
        boolean includeSuggestionFolder = false;
        for (BookmarkId id : selectedItems) {
            if (id.equals(BookmarkUtils.getSuggestionBookmark())) {
                includeSuggestionFolder = true;
            }
        }
        if (includeSuggestionFolder) {
            editView.setVisibility(GONE);
            moveView.setVisibility(GONE);
            deleteView.setVisibility(GONE);
//            selectAllView.setVisibility(VISIBLE);
        } else {
            if (selectedItems.size() > 1) {
                editView.setVisibility(GONE);
            } else {
                editView.setVisibility(VISIBLE);
            }
            moveView.setVisibility(VISIBLE);
            deleteView.setVisibility(VISIBLE);
//            selectAllView.setVisibility(VISIBLE);
        }
    }

    private void onEditBookmark() {
        SelectionDelegate<BookmarkId> selectionDelegate = mDelegate.getSelectionDelegate();
        List<BookmarkId> list = selectionDelegate.getSelectedItems();
        assert list.size() == 1;
        BookmarkBridge.BookmarkItem item = mDelegate.getModel().getBookmarkById(list.get(0));
        if (item.isFolder()) {
            BookmarkAddEditFolderActivity.startEditFolderActivity(getContext(), item.getId());
        } else {
            BookmarkUtils.startEditActivity(getContext(), item.getId());
        }
    }

    private void onDeleteBookmark() {
        SelectionDelegate<BookmarkId> selectionDelegate = mDelegate.getSelectionDelegate();
        mDelegate.getModel().deleteBookmarks(
                selectionDelegate.getSelectedItems().toArray(new BookmarkId[0]));
    }

    private void onMoveBookmark(){
        SelectionDelegate<BookmarkId> selectionDelegate = mDelegate.getSelectionDelegate();
        List<BookmarkId> list = selectionDelegate.getSelectedItems();
        if (list.size() >= 1) {
            BookmarkFolderSelectActivity.startFolderSelectActivity(getContext(),
                    list.toArray(new BookmarkId[list.size()]));
        }
    }
}

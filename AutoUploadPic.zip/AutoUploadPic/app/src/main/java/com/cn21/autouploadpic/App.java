package com.cn21.autouploadpic;

import android.app.Application;
import android.content.Intent;

import com.cn21.autouploadpic.service.PicMonitorService;
import com.cn21.autouploadpic.util.CrashHandler;

/**
 * Created by Administrator on 2017/11/23.
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        CrashHandler.getInstance().init(this);
        startService(new Intent(this, PicMonitorService.class));
    }
}

package com.cn21.autouploadpic;

/**
 * Created by Administrator on 2017/11/23.
 */
public class Constant {

    public static final String EXTERNAL_DIR_NAME = "pic_monitor";

    public static final String CONFIG_FILE = "conf.txt";

    public static final String SERVER_URL = "server_url";
    public static final String CONNECTION_TIME_OUT = "connection_time_out";
    public static final String READ_TIME_OUT = "read_time_out";
}

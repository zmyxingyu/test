package com.cn21.autouploadpic.service;

import java.io.File;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Process;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.text.format.DateFormat;
import android.util.Log;

import com.cn21.autouploadpic.task.UploadTask;
import com.cn21.autouploadpic.util.LogUtil;

/**
 * Created by Administrator on 2017/11/23.
 */
public class PicMonitorService extends Service {
    private static final String TAG = "PicMonitor";
    private Handler mWorkerHandler;
    private ContentObserver mContentObserver;
    private Handler mContentChangeHandler;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startWorker() {
        stopWorker();
        HandlerThread thread = new HandlerThread("worker", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        mWorkerHandler = new Handler(thread.getLooper());
    }

    private void stopWorker() {
        if (mWorkerHandler != null) {
            mWorkerHandler.removeCallbacksAndMessages(null);
            mWorkerHandler.getLooper().quit();
            mWorkerHandler = null;
        }
    }

    private void startContentChangeWorker() {
        stopContentChangeWorker();
        HandlerThread thread = new HandlerThread("content", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        mContentChangeHandler = new Handler(thread.getLooper());
    }

    private void stopContentChangeWorker() {
        if (mContentChangeHandler != null) {
            mContentChangeHandler.removeCallbacksAndMessages(null);
            mContentChangeHandler.getLooper().quit();
            mContentChangeHandler = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mContentObserver != null) {
            getContentResolver().unregisterContentObserver(mContentObserver);
        }
        stopWorker();
        stopContentChangeWorker();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startPicMonitor();
        return START_STICKY;
    }

    private void startPicMonitor() {
        startWorker();

        startContentChangeWorker();
        if (mContentObserver == null) {
            mContentObserver = new PicContentObserver(this, mContentChangeHandler, mWorkerHandler);
            Uri imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            getContentResolver().registerContentObserver(imageUri, false, mContentObserver);
        }
    }

    private static class PicContentObserver extends ContentObserver {
        private Context mContext;
        private Handler mUploadHandler;

        public PicContentObserver(Context context, Handler handler, Handler uploadHandler) {
            super(handler);
            mContext = context;
            mUploadHandler = uploadHandler;
        }

        /**
         * 主要在onChange中响应数据库变化，并进行相应处理
         */
        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            LogUtil.d(TAG, "database is changed!------------------------------------------");

            Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

            Cursor cursor = mContext.getContentResolver().query(uri, null, null, null,
                    MediaStore.Images.ImageColumns.DATE_ADDED + " desc limit 1");

            if (cursor != null) {
                try {
                    LogUtil.d(TAG, "The number of data is:" + cursor.getCount());
                    if (cursor.moveToNext()) {
                        String fileName = cursor.getString(cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA));
                        long lastModifyTime = new File(fileName).lastModified();
                        LogUtil.d(TAG, "the new picture : %s, modify time is %s",
                                fileName, DateFormat.format("yyyyMMdd-kkmmss", lastModifyTime));

                        if (Math.abs(System.currentTimeMillis() - lastModifyTime) < 10000) {
                            //修改文件时间与当前系统时间相差在10秒之内
                            //上传文件
                            mUploadHandler.removeCallbacksAndMessages(null);
                            mUploadHandler.post(new UploadTask(fileName));
                        } else {
                            LogUtil.d(TAG, "the diff between picture modify time and system time is bigger than 10 seconds");
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    LogUtil.d(TAG, "got error : %s", Log.getStackTraceString(e));
                } finally {
                    cursor.close();
                }
            }
        }

    }
}


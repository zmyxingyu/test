package com.cn21.autouploadpic.task;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.cn21.autouploadpic.Constant;
import com.cn21.autouploadpic.util.LogUtil;
import com.cn21.autouploadpic.util.TransportUtil;

/**
 * Created by Administrator on 2017/11/23.
 */
public class UploadTask implements Runnable {

    private static class UploadConfig {
        public String serverUrl;
        public int connectionTimeoutMs;
        public int readTimeoutMs;

        @Override
        public String toString() {
            return "url: " + serverUrl
                    + ", connectionTimeoutMs: " + connectionTimeoutMs
                    + ", readTimeoutMs: " + readTimeoutMs;
        }
    }

    private static final String TAG = "UPLOAD";

    private final String mFilePath;

    public UploadTask(String filePath) {
        mFilePath = filePath;
    }

    @Override
    public void run() {
        UploadConfig config = getConfig();
        LogUtil.d(TAG, "upload config : %s", config);
        boolean success = TransportUtil.uploadFile(config.serverUrl, new File(mFilePath), null,
                config.connectionTimeoutMs, config.readTimeoutMs);
        LogUtil.d(TAG, "upload %s result : %s", mFilePath, success);
    }

    private UploadConfig getConfig() {
        UploadConfig uploadConfig = new UploadConfig();
        uploadConfig.serverUrl = "";
        uploadConfig.connectionTimeoutMs = 10000;// 10s
        uploadConfig.readTimeoutMs = 5000;// 5s
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            final File dir = new File(Environment.getExternalStorageDirectory(), Constant.EXTERNAL_DIR_NAME);
            dir.mkdirs();
            final File configFile = new File(dir, Constant.CONFIG_FILE);
            InputStream is = null;
            OutputStream os = null;
            try {
                if (configFile.exists()) {
                    is = new BufferedInputStream(new FileInputStream(configFile));
                    Properties config = new Properties();
                    config.load(is);

                    String r_server_url = config.getProperty(Constant.SERVER_URL);
                    String r_connection_timeout = config.getProperty(Constant.CONNECTION_TIME_OUT);
                    String r_read_timeout = config.getProperty(Constant.READ_TIME_OUT);
                    if (!TextUtils.isEmpty(r_server_url)) {
                        uploadConfig.serverUrl = String.valueOf(r_server_url);
                    }

                    if (!TextUtils.isEmpty(r_connection_timeout)) {
                        uploadConfig.connectionTimeoutMs = Integer.valueOf(String.valueOf(r_connection_timeout));
                    }

                    if (!TextUtils.isEmpty(r_read_timeout)) {
                        uploadConfig.readTimeoutMs = Integer.valueOf(String.valueOf(r_read_timeout));
                    }

                } else {
                    os = new BufferedOutputStream(new FileOutputStream(configFile, false));
                    Properties config = new Properties();

                    config.setProperty(Constant.SERVER_URL, "unknown");
                    config.setProperty(Constant.CONNECTION_TIME_OUT, "10000");
                    config.setProperty(Constant.READ_TIME_OUT, "5000");
                    config.store(os, "init properties");
                }
            } catch (Exception e) {
                e.printStackTrace();
                LogUtil.d(TAG, Log.getStackTraceString(e));
            } finally {
                TransportUtil.close(is);
                TransportUtil.close(os);
            }

        }
        return uploadConfig;
    }
}

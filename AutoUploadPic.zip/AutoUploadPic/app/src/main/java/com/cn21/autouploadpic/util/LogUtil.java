package com.cn21.autouploadpic.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.util.Log;

import com.cn21.autouploadpic.Constant;

import static android.os.Process.myTid;

/**
 * Created by Administrator on 2017/11/23.
 */
public class LogUtil {

    private LogUtil() {
    }

    public static void d(String tag, String msg, Object... args) {
        int tid = Process.myTid();
        String name = Thread.currentThread().getName();
        if (args != null && args.length > 0) {
            mLogHandler.post(new LogTask(tag, tid + "_" + name, String.format(msg, args)));
        } else {
            mLogHandler.post(new LogTask(tag, tid + "_" + name, msg));
        }
    }

    private static Handler mLogHandler;

    static {
        HandlerThread thread = new HandlerThread("log_thread", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        mLogHandler = new Handler(thread.getLooper());
    }

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd-HHmmss.SSS");

    private static class LogTask implements Runnable {
        private final String date = String.valueOf(DATE_FORMAT.format(new Date()));
        private final String tag;
        private final String msg;
        private final String threadInfo;

        public LogTask(String tag, String threadInfo, String msg) {
            this.tag = tag;
            this.threadInfo = threadInfo;
            this.msg = msg;
        }

        @Override
        public void run() {
            Log.d(tag, msg);

            if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
                final File dir = new File(Environment.getExternalStorageDirectory(), Constant.EXTERNAL_DIR_NAME);
                dir.mkdirs();
                final File logFile = new File(dir, "log.txt");
                Writer writer = null;
                try {
                    writer = new BufferedWriter(new FileWriter(logFile, true));
                    writer.write(date);
                    writer.write("---");

                    writer.write("[");
                    writer.write(tag);
                    writer.write("/");
                    writer.write(threadInfo);
                    writer.write("]");

                    writer.write("---");
                    writer.write(msg);

                    writer.write("\n\n");
                    writer.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (writer != null) {
                        try {
                            writer.close();
                        } catch (IOException e) {
                        }
                    }
                }
            }
        }
    }

}

#!/bin/sh

echo -e " 清理上一次文件 "
rm -r -f Build

echo -e " 清理node_modules "
watchman watch-del-all
rm -rf node_modules && npm install
rm -fr $TMPDIR/react-*

echo -e " 开始copy模版 "
cp -R ./template ./Build


cd ..
echo -e " 开始编译 React Native "
react-native bundle --entry-file index.ios.js --bundle-output ./bundle/Build/RNResources.bundle/index.ios.jsbundle --platform ios --assets-dest ./bundle/Build/RNResources.bundle --dev false
echo -e " 编译结束 "

/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {
    AppRegistry,
} from 'react-native';
import {
    CircleApp,
    ListingApp,
    UserInfoDetailApp,
    FollowPageApp,
    MyKCoinApp,
} from './js/app';
import FirstPage from './js/page/FirstPage';
import MinePage from './js/page/MinePage';
import AddCirclePage from './js/page/AddCirclePage';
import AddMarkPage from './js/page/AddMarkPage';
import DraftArticlePage from './js/page/DraftArticlePage';
import ArticleListPage from './js/page/ArticleListPage';
import ShareToPage from './js/page/ShareToPage';
import DiscountPage from './js/page/DiscountPage';

class MineApp extends Component {
    render() {
        return <MinePage isLogin={this.props.isLogin} openid={this.props.openid}/>;
    }
}

class FirstApp extends Component {
    render() {
        return <FirstPage isLogin={this.props.isLogin} openid={this.props.openid}/>;
    }
}

class CircleRoot extends Component {
    render() {
        //通过设置screenProps可以获取启动参数,在导航初始页通过读取this.props.screenProps.openid获取openid值
        return <CircleApp screenProps={this.props}/>;
    }
}
class ListingRoot extends Component {
    render() {
        return <ListingApp screenProps={this.props}/>;
    }
}

class UserInfoRoot extends Component {
    render() {
        return <UserInfoDetailApp screenProps={this.props}/>;
    }
}

class AddCircleApp extends Component {
    render() {
        return <AddCirclePage openid={this.props.openid} isLogin={this.props.isLogin}/>;
    }
}

class AddMarkApp extends Component {
    render() {
        return <AddMarkPage openid={this.props.openid} isLogin={this.props.isLogin}/>;
    }
}

class DraftArticleApp extends Component {
    render() {
        return <DraftArticlePage openid={this.props.openid} isLogin={this.props.isLogin}/>;
    }
}

class ArticleListApp extends Component {
    render() {
        return <ArticleListPage openid={this.props.openid} isLogin={this.props.isLogin} nullOpenId={this.props.nullOpenId}/>;
    }
}

class FollowPageRoot extends Component {
    render() {
        return <FollowPageApp screenProps={this.props}/>;
    }
}

class MyKCoinRoot extends Component {
    render() {
        return <MyKCoinApp screenProps={this.props}/>;
    }
}

class ShareToApp extends Component {
    render() {
        return (
            <ShareToPage
                openid={this.props.openid}
                listId={this.props.listId}
                listType={this.props.listType}
                markId={this.props.markId}
            />
        );
    }
}

class DiscountApp extends Component {
    render() {
        return (
            <DiscountPage
                openid={this.props.openid}
                listId={this.props.listId}
                listType={this.props.listType}
                from={this.props.from}
            />
        );
    }
}

AppRegistry.registerComponent('ShareToApp', () => ShareToApp);
AppRegistry.registerComponent('HomeApp', () => FirstApp);
AppRegistry.registerComponent('MineApp', () => MineApp);
AppRegistry.registerComponent('RNCircleApp', () => CircleRoot);
AppRegistry.registerComponent('RNListingApp', () => ListingRoot);
AppRegistry.registerComponent('UserInfoDetailApp', () => UserInfoRoot);
AppRegistry.registerComponent('AddCircleApp', () => AddCircleApp);
AppRegistry.registerComponent('AddMarkApp', () => AddMarkApp);
AppRegistry.registerComponent('DraftArticleApp', () => DraftArticleApp);
AppRegistry.registerComponent('ArticleListApp', () => ArticleListApp);
AppRegistry.registerComponent('FollowApp', () => FollowPageRoot);
AppRegistry.registerComponent('MyKCoinApp', () => MyKCoinRoot);
AppRegistry.registerComponent('DiscountApp', () => DiscountApp);


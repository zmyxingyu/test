/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {
    AppRegistry,
    Text,
} from 'react-native';
import {
    CircleApp,
    ListingApp,
    UserInfoDetailApp,
    FollowPageApp,
    MyKCoinApp,
} from './js/app';
import FirstPage from './js/page/FirstPage';
import MinePage from './js/page/MinePage';
import AddCirclePage from './js/page/AddCirclePage';
import AddMarkPage from './js/page/AddMarkPage';
import DraftArticlePage from './js/page/DraftArticlePage';
import ArticleListPage from './js/page/ArticleListPage';
import ShareToPage from './js/page/ShareToPage';
import DiscountPage from './js/page/DiscountPage';

class MineApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <MinePage isLogin={this.props.isLogin} openid={this.props.openid}/>;
    }
}
class FirstApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <FirstPage isLogin={this.props.isLogin} openid={this.props.openid}/>;
    }
}
class CircleRoot extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        //通过设置screenProps可以获取启动参数,在导航初始页通过读取this.props.screenProps.openid获取openid值
        return <CircleApp screenProps={this.props}/>;
    }
}
class ListingRoot extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <ListingApp screenProps={this.props}/>;
    }
}

class UserInfoRoot extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <UserInfoDetailApp screenProps={this.props}/>;
    }
}

class AddCircleApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }

    render() {
        return <AddCirclePage openid={this.props.openid}/>;
    }
}

class AddMarkApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }

    render() {
        return <AddMarkPage openid={this.props.openid}/>;
    }
}

class DraftArticleApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <DraftArticlePage openid={this.props.openid}/>;
    }
}

class ArticleListApp extends Component {
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <ArticleListPage openid={this.props.openid}/>;
    }
}

class FollowPageRoot extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <FollowPageApp screenProps={this.props}/>;
    }
}

class MyKCoinRoot extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <MyKCoinApp screenProps={this.props}/>;
    }
}

class ShareToApp extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <ShareToPage openid={this.props.openid}/>;
    }
}

class DiscountApp extends Component{
    constructor() {
        super();
        Text.defaultProps.allowFontScaling=false;
    }
    render() {
        return <DiscountPage openid={this.props.openid}/>;
    }
}

AppRegistry.registerComponent('MineApp', () => MineApp);
AppRegistry.registerComponent('HomeApp', () => FirstApp);
AppRegistry.registerComponent('myKCoinPage', () => MyKCoinRoot);
AppRegistry.registerComponent('userInfoPage', () => UserInfoRoot);
AppRegistry.registerComponent('addCirclePage', () => AddCircleApp);
AppRegistry.registerComponent('followPage', () => FollowPageRoot);
AppRegistry.registerComponent('addMarkPage', () => AddMarkApp);
AppRegistry.registerComponent('circlePage', () => CircleRoot);
AppRegistry.registerComponent('listingPage', () => ListingRoot);
AppRegistry.registerComponent('draftArticlePage', () => DraftArticleApp);
AppRegistry.registerComponent('myArticleListPage', () => ArticleListApp);
AppRegistry.registerComponent('shareToPage', () => ShareToApp);
AppRegistry.registerComponent('discountPage', () => DiscountApp);



/**
 * Created by lizhj on 2017/8/9.
 */

import {StackNavigator,} from 'react-navigation';
import leftInRightOutConfig from './config/LeftInRightOutConfig';
import CircleInfoPage from './page/CircleInfoPage';
import UserInfoPage from './page/UserInfoPage';
import ListingInfoPage from './page/ListingInfoPage';
import IncomePage from './page/IncomePage';
import EditCircleNamePage from './page/EditCircleNamePage';
import JoinSettingPage from './page/JoinSettingPage';
import CircleMemberPage from './page/CircleMemberPage';
import TotalSubscriptPage from './page/TotalSubscriptPage';
import UpdateNickNamePage from './page/UpdateNickNamePage';
import UpdateProfilePage from './page/UpdateProfilePage';
import UpdateJobPage from './page/UpdateJobPage';
import UpdateIndustryPage from './page/UpdateIndustryPage';
import UpdateAgePage from './page/UpdateAgePage';
import UpdateEduPage from './page/UpdateEduPage';
import ReviewPage from './page/ReviewPage';
import FollowPage from './page/FollowPage';
import OtherUserInfoPage from './page/OtherUserInfoPage';
import MyKCoinPage from './page/MyKCoinPage';
import PayRecordPage from './page/PayRecordPage';

export const CircleApp = StackNavigator({
    CircleInfoPage: {screen: CircleInfoPage, navigationOptions: {gesturesEnabled: true}},
    TotalSubscriptPage: {screen: TotalSubscriptPage, navigationOptions: {gesturesEnabled: true}},
    CircleMemberPage: {screen: CircleMemberPage, navigationOptions: {gesturesEnabled: true}},
    JoinSettingPage: {screen: JoinSettingPage, navigationOptions: {gesturesEnabled: true}},
    ReviewPage: {screen: ReviewPage, navigationOptions: {gesturesEnabled: true}},
    IncomePage: {screen: IncomePage, navigationOptions: {gesturesEnabled: true}},
    EditCircleNamePage: {screen: EditCircleNamePage, navigationOptions: {gesturesEnabled: true}},
}, {
    headerMode: 'none',
    transitionConfig: leftInRightOutConfig,
});

export const ListingApp = StackNavigator({
    ListingInfoPage: {screen: ListingInfoPage, navigationOptions: {gesturesEnabled: true}},
    TotalSubscriptPage: {screen: TotalSubscriptPage, navigationOptions: {gesturesEnabled: true}},
    CircleMemberPage: {screen: CircleMemberPage, navigationOptions: {gesturesEnabled: true}},
    JoinSettingPage: {screen: JoinSettingPage, navigationOptions: {gesturesEnabled: true}},
    ReviewPage: {screen: ReviewPage, navigationOptions: {gesturesEnabled: true}},
    IncomePage: {screen: IncomePage, navigationOptions: {gesturesEnabled: true}},
    EditCircleNamePage: {screen: EditCircleNamePage, navigationOptions: {gesturesEnabled: true}},
}, {
    headerMode: 'none',
    transitionConfig: leftInRightOutConfig,
});

export const UserInfoDetailApp = StackNavigator({
    UserInfoPage: {screen: UserInfoPage, navigationOptions: {gesturesEnabled: true}},
    UpdateNickNamePage: {screen: UpdateNickNamePage, navigationOptions: {gesturesEnabled: true}},
    UpdateJobPage: {screen: UpdateJobPage, navigationOptions: {gesturesEnabled: true}},
    UpdateProfilePage: {screen: UpdateProfilePage, navigationOptions: {gesturesEnabled: true}},
    UpdateIndustryPage: {screen: UpdateIndustryPage, navigationOptions: {gesturesEnabled: true}},
    UpdateAgePage: {screen: UpdateAgePage, navigationOptions: {gesturesEnabled: true}},
    UpdateEduPage: {screen: UpdateEduPage, navigationOptions: {gesturesEnabled: true}},
}, {
    headerMode: 'none',
    transitionConfig: leftInRightOutConfig,
});

export const FollowPageApp = StackNavigator({
    FollowPage: {screen: FollowPage, navigationOptions: {gesturesEnabled: true}},
    OtherUserInfoPage: {screen: OtherUserInfoPage, navigationOptions: {gesturesEnabled: true}},
}, {
    headerMode: 'none',
    transitionConfig: leftInRightOutConfig,
});

export const MyKCoinApp = StackNavigator({
    MyKCoinPage: {screen: MyKCoinPage, navigationOptions: {gesturesEnabled: true}},
    PayRecordPage: {screen: PayRecordPage, navigationOptions: {gesturesEnabled: true}},
}, {
    headerMode: 'none',
    transitionConfig: leftInRightOutConfig,
});


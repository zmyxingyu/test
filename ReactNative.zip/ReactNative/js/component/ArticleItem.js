/**
 * 侧滑删除item
 * Created by yf on 2017/8/31
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,PixelRatio,
    Text,View,Image,
    TouchableOpacity
} from 'react-native';
import px2dp from '../utils/px2dp';
import CCCImage from '../component/CCCImage';
import theme from '../utils/theme';
import DividingLine from  '../component/DividingLine';

export default class ArticleItem extends Component {
    //PropType声明
    static propTypes = {
        deletePress:PropTypes.func.isRequired,
        onItemClick: PropTypes.func.isRequired,
        renderItem: PropTypes.func,
        rowData: PropTypes.object,
        index: PropTypes.number,
    };

    constructor(props) {
        super(props);
        this.state = {
            index:-1
        }
    }

    //默认属性
    static defaultProps = {
        renderItem: null,
        rowData: null,
        onItemClick:null,
        deletePress:null
    };

    render() {
        return (
            <TouchableOpacity onPress={this.props.onItemClick.bind(this, this.props.rowData)}  activeOpacity={theme.btnActiveOpacity}>
                {
                    this._renderItem(this.props.rowData)
                }
            </TouchableOpacity>
        );
    }

    _renderItem(rowData){
        return (
            <View style={{flexDirection:'column'}}>
                <View style={{flexDirection:'row',justifyContent:'center',alignItems:'center',paddingLeft:px2dp(10),paddingBottom:px2dp(15),paddingTop:px2dp(15),paddingRight:px2dp(10),backgroundColor:'white'
                    }}>
                    {
                        rowData.thumbPicList?<CCCImage source={{uri: rowData.thumbPicList[0].replace('/o/','/s240x240/')}} style={styles.image}/>
                            :null
                    }
                    <View style={{flexDirection: 'column',flex:1}}>
                        <Text style={{color: '#444', fontSize: px2dp(15),flex:1,marginRight:px2dp(10)}} numberOfLines={1}>{rowData.title}</Text>
                        <Text style={{color: '#999', fontSize: px2dp(12),flex:1,marginRight:px2dp(10)}} numberOfLines={2}>{rowData.summary}</Text>
                    </View>
                    <TouchableOpacity onPress={this.props.deletePress.bind(this)}  activeOpacity={theme.btnActiveOpacity}
                                      style={{width: px2dp(20),height: px2dp(30),justifyContent:'center',alignItems:'center'}}>
                        <Image source={require('../image/icon_remove.png')} style={{width: px2dp(15),height: px2dp(16),resizeMode: 'contain'}}/>
                    </TouchableOpacity>
                </View>
                <DividingLine/>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor,
        borderTopWidth: 1 / PixelRatio.get()
    },
    item: {
        flexDirection: 'row',alignItems:'center',
        width: theme.screenWidth,
        height: px2dp(70),
        backgroundColor: '#fff',
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        borderTopColor: '#d4d4d4'
    },
    image: {
        height: px2dp(55),
        width: px2dp(55),
        backgroundColor: '#f4f4f4',
        resizeMode: 'cover',
        marginRight:px2dp(12)
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row'
    }
});
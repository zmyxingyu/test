/**
 * 通用Image封装，添加defaultSource和出错处理
 * Created by lizhj on 2017/8/30.
 */
import React, {Component, PropTypes} from 'react';
import {
    Image,
    View
} from 'react-native';

export default class CCCImage extends Component {
    static propTypes = {
        isRound: PropTypes.bool,
        source: PropTypes.object.isRequired,
        placeholderSource: PropTypes.number,
        placeholderErrorSource: PropTypes.number,
    };

    static defaultProps = {
        isRound: false,
        placeholderSource: require('../image/group_default_icon.png'),
        placeholderErrorSource: require('../image/group_default_icon.png'),
    };

    constructor(props) {
        super(props);
        this.state = {
            isLoaded: false,
            isError: false,
        };
    }

    onLoadEnd() {
        this.setState({
            isLoaded: true
        });
    }


    onError() {
        this.setState({
            isError: true
        });
    }

    render() {
        if (this.props.source.uri || this.props.source.uri !== '') {
            if (this.props.isRound) {
                return (
                    <View>
                        <Image
                            onLoadEnd={() => this.onLoadEnd()}
                            onError={() => this.onError()}
                            style={this.props.style}
                            source={this.props.source}
                        >
                        </Image>
                        {
                            this.state.isLoaded ?
                                this.state.isError ?
                                    <Image
                                        style={[this.props.style, {position: 'absolute'}]}
                                        source={ this.props.placeholderErrorSource}
                                    /> :
                                    null
                                :
                                <Image
                                    style={[this.props.style, {position: 'absolute'}]}
                                    source={this.props.placeholderSource}
                                />
                        }
                    </View>
                );
            } else {
                return (
                    <Image
                        onLoadEnd={() => this.onLoadEnd()}
                        onError={() => this.onError()}
                        style={this.props.style}
                        source={this.props.source}
                    >
                        {
                            this.state.isLoaded ?
                                this.state.isError ?
                                    <Image

                                        style={this.props.style}
                                        source={ this.props.placeholderErrorSource}
                                    /> :
                                    null
                                :
                                <Image
                                    style={this.props.style}
                                    source={this.props.placeholderSource}
                                />
                        }
                    </Image>
                );
            }
        } else {
            return (
                <Image
                    style={this.props.style}
                    source={ this.props.placeholderSource}
                />
            );
        }

    }
}
/**
 * 平台统一Swtich
 * Created by lizhj on 2017/9/4.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Image,
    TouchableOpacity,
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';

export default class CCCSwitch extends Component {
    static propTypes = {
        on: PropTypes.bool.isRequired,
        onValueChange: PropTypes.func,

    };

    static defaultProps = {
        on: false,
        onValueChange: null,
    };


    render() {
        return (
            <TouchableOpacity onPress={() => {
                this.props.onValueChange(!this.props.on);
            }}
                              activeOpacity={theme.btnActiveOpacity}>
                <Image
                    style={[styles.switchImg, this.props.style]}
                    source={this.props.on ? require('../image/switch_on.png') : require('../image/switch_off.png')} />
            </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    switchImg: {
        width: px2dp(51),
        height: px2dp(31),
        resizeMode: 'contain',
    }
});
﻿/**
 * 保存item
 * Created by lizhj on 2017/8/17.
 */
import React, {Component, PropTypes} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Image,
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';

export default class SaveItem extends Component {
    //PropType声明
    static propTypes = {
        itemTitle: PropTypes.string.isRequired,
        itemNum: PropTypes.number.isRequired,
    };

    //默认属性
    static defaultProps = {
        itemTitle: '',
        itemNum: 0,
    };

    constructor(props) {
        super(props);
        this.state = {
            isSelected: false,
        };
    }

    render() {
        return (
            <TouchableOpacity onPress={() => {
                this.setState({
                    isSelected: !this.state.isSelected,
                });
            }}
            >
                <View style={styles.itemContainer}>
                    <View style={styles.itemBg}>
                        {this.state.isSelected ? <Image  style={styles.selectMark} source={{uri: ''}} /> : null}
                    </View>
                    <Text>{this.props.itemTitle}</Text>
                    <Text>{this.props.itemNum}</Text>
                </View>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    itemContainer: {
        width: 50,
        height: 80,
        borderRadius: 8,
        borderWidth: ScreenUtils.onePixel,
    },
    itemBg: {
        width: 50,
        height: 50,
        backgroundColor: '#CECECE',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
    },
    selectMark: {
        width: 20,
        height: 20,
        borderRadius: 10,
    }

});

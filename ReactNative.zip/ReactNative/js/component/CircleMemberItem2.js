/**
 * Created by lizhj on 2017/11/1.
 */
/**
 * 圈子成员单个item 第二种样式
 * Created by lizhj on 2017/8/23.
 */
import React, {Component, PropTypes} from 'react';
import {
    View,
    Text,
    Image,
    StyleSheet,
    TouchableOpacity,
    Platform,
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import ScreenUtils from '../utils/ScreenUtils';
import Constants from '../config/Constants';
import CCCImage from './CCCImage';


export default class CircleMemberItem2 extends Component {
    //PropType声明
    static propTypes = {
        rank: PropTypes.number.isRequired,
        circleMember: PropTypes.object.isRequired,
        onItemClick: PropTypes.func,
        deletePress: PropTypes.func,
        showDelete: PropTypes.bool,
    };

    //默认属性
    static defaultProps = {
        rank: -1,
        showDelete: false,
        circleMember: {
            nickname: '',
            iconUrl: '',
            contribution: 0,
            permission: 0,
        },
        onItemClick: null,
        deletePress: null,
    };

    renderRankNumber(rank) {
        if (rank === 1) {
            return (
                <View style={styles.rankImgContainer}>
                    <Image style={styles.rankImg} source={require('../image/icon_rank_1.png')}/>
                </View>
            );
        } else if (rank === 2) {
            return (
                <View style={styles.rankImgContainer}>
                    <Image style={styles.rankImg} source={require('../image/icon_rank_2.png')}/>
                </View>
            );
        } else if (rank === 3) {
            return (
                <View style={styles.rankImgContainer}>
                    <Image style={styles.rankImg} source={require('../image/icon_rank_3.png')}/>
                </View>
            );
        } else {
            return <Text style={styles.rankText} numberOfLines={1}>{rank}</Text>;
        }
    }

    render() {
        const rank = this.props.rank;
        const {nickName, iconUrl, contribution, permission} = this.props.circleMember;
        const isOwner = permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;//判断是否为圈主
        return (
            <TouchableOpacity
                activeOpacity={theme.btnActiveOpacity}
                onPress={this.props.onItemClick}>
                <View style={styles.container}>
                    {this.renderRankNumber(rank)}
                    <CCCImage
                        isRound
                        style={this.props.avatar ? this.props.avatar : styles.avatar}
                        source={{uri: iconUrl}}
                    />
                    <View style={styles.midLayout}>
                        <View style={{flexDirection: 'row', alignItems: 'center'}}>
                            <Text style={styles.nameText} numberOfLines={1}>{nickName}</Text>
                            {isOwner ? <Image style={styles.ownerImg}
                                              source={require('../image/icon_circle_owner.png')}/> : null}
                        </View>
                        <Text style={styles.contributeText} numberOfLines={1}>{`贡献值${contribution}`}</Text>
                    </View>
                    {
                        this.props.showDelete ?
                            isOwner ? null :
                                <TouchableOpacity
                                    onPress={this.props.deletePress}
                                    activeOpacity={theme.btnActiveOpacity}
                                    style={{
                                        width: px2dp(45),
                                        height: px2dp(62),
                                        justifyContent: 'center',
                                        alignItems: 'center'
                                    }}>
                                    <Image
                                        source={require('../image/icon_remove.png')}
                                        style={{width: px2dp(15), height: px2dp(16), resizeMode: 'contain'}}/>
                                </TouchableOpacity> : null
                    }
                </View>
            </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        height: px2dp(62),
        alignItems: 'center',
        backgroundColor: 'white',
        borderBottomWidth: ScreenUtils.onePixel,
        borderColor: '#ECECEC',
    },
    avatar: {
        width: px2dp(40),
        height: px2dp(40),
        borderRadius: px2dp(40) / 2,
    },
    nameText: {
        fontSize: px2dp(15),
        color: '#444444',
    },
    ownerImg: {
        width: px2dp(33),
        height: px2dp(18),
        resizeMode: 'contain',
        marginLeft: px2dp(8),
    },
    contributeText: {
        fontSize: px2dp(12),
        color: '#999999',
        textAlign: 'right',
    },
    rankImgContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: px2dp(15),
        width: px2dp(25),
        height: px2dp(21),
        marginRight: px2dp(8),
    },
    rankImg: {
        width: px2dp(17),
        height: px2dp(21),
        resizeMode: 'contain',
    },
    rankText: {
        width: px2dp(28),
        marginLeft: px2dp(15),
        color: '#999999',
        fontSize: px2dp(24),
        marginRight: px2dp(8),
        textAlign: 'center',
    },
    midLayout: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft: px2dp(8),
    },
});
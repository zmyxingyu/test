/**
 * 通用内容栏，适用于类设置项组件
 * Created by lizhj on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    View,
    Text,
    Image,
    TouchableOpacity
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';

export default class CommonContentItem extends Component {
    //PropType声明
    static propTypes = {
        item: PropTypes.object.isRequired,
        onClick: PropTypes.func,
        rightArrowShow: PropTypes.bool,
        clickable: PropTypes.bool,
    };

    //默认属性
    static defaultProps = {
        item: {
            title: '',
            content: '',
        },
        onClick: null,
        rightArrowShow: true,
        clickable: true,
    };

    render() {
        const {title, content} = this.props.item;
        return (
            <TouchableOpacity
                activeOpacity={theme.btnActiveOpacity}
                disabled={!this.props.clickable}
                onPress={this.props.onClick}
            >
                <View style={[styles.commonItemLayout, this.props.style]}>
                    <Text style={styles.title}>{title}</Text>
                    <View style={styles.rightLayout}>
                        <View style={styles.touchableLayout}>
                            <Text style={styles.content} numberOfLines={1}>{content}</Text>
                            {this.props.rightArrowShow ?
                                <Image
                                    style={styles.rightArrowImg}
                                    source={require('../image/more_icon.png')}/> :
                                null}
                        </View>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    commonItemLayout: {
        paddingRight: px2dp(15),
        backgroundColor: 'white',
        flexDirection: 'row',
        height: px2dp(56),
        width: ScreenUtils.width,
        alignItems: 'center',
    },
    rightLayout: {
        flex: 1,
        height: px2dp(56),
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    touchableLayout: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        flex: 1,
    },
    title: {
        marginLeft: px2dp(15),
        marginRight:px2dp(30),
        fontSize: px2dp(16),
        color: '#444444'
    },
    content: {
        marginRight: px2dp(6),
        marginLeft: 8,
        flex: 1,
        textAlign: 'right',
        fontSize: px2dp(14),
        color: '#999999',
    },
    rightArrowImg: {
        width: px2dp(16),
        height: px2dp(16),
        resizeMode: 'contain',
    },
});
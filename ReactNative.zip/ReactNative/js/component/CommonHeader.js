/**
 * 通用导航头部
 * Created by lizhj on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    View, Platform,
    Text,
    Image,
    TouchableOpacity
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import DividingLine from './DividingLine';

export default class CommonHeader extends Component {
    //PropType声明
    static propTypes = {
        title: PropTypes.string.isRequired,
        onBack: PropTypes.func.isRequired,
        onRight: PropTypes.func,
        rightText: PropTypes.string,
        showRightButton: PropTypes.bool.isRequired,
        clickable: PropTypes.bool.isRequired,
        renderRight: PropTypes.bool,
    };

    //默认属性
    static defaultProps = {
        title: '',
        onBack: null,
        onRight: null,
        rightText: '确定',
        showRightButton: false,
        clickable: false,
        renderRight: false,
    };

    render() {
        return (
            <View>
                <View style={[styles.headerContainer, this.props.style]}>
                    <TouchableOpacity
                        activeOpacity={theme.btnActiveOpacity}
                        style={styles.leftTouchableArea}
                        onPress={this.props.onBack}
                    >
                        <Image
                            style={styles.backImg}
                            source={require('../image/icon_back.png')}
                        />
                    </TouchableOpacity>
                    <Text style={styles.titleText}>{this.props.title}</Text>
                    {this.props.showRightButton ?
                        <TouchableOpacity
                            disabled={!this.props.clickable}
                            style={styles.rightTouchableArea}
                            activeOpacity={theme.btnActiveOpacity}
                            onPress={this.props.onRight}
                        >
                            {
                                this.props.renderRight ?
                                    <Image
                                        style={styles.confirmImg}
                                        source={require('../image/icon_question.png')}
                                    /> :
                                    <Text
                                        style={[styles.rightText, this.props.clickable ? null : {color: '#999'}]}>
                                        {this.props.rightText}
                                    </Text>
                            }
                        </TouchableOpacity>
                        :
                        null
                    }
                </View>
                <DividingLine/>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    headerContainer: {
        backgroundColor: 'white',
        flexDirection: 'row',
        height: theme.actionBar.height,
        width: ScreenUtils.width,
        alignItems: 'center',
        paddingTop: (Platform.OS === 'ios' ? ScreenUtils.isIPhoneX ? px2dp(44) : px2dp(20) : 0),
    },
    leftTouchableArea: {
        paddingLeft: px2dp(15),
        height: px2dp(44),
        width: 40,
        justifyContent: 'center',
    },
    rightTouchableArea: {
        top: (Platform.OS === 'ios' ? px2dp(20) : 0),
        right: px2dp(0),
        height: px2dp(44),
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        position: 'absolute',
        justifyContent: 'center',
        alignItems: 'center',
    },
    backImg: {
        width: px2dp(12),
        height: px2dp(20),
    },
    titleText: {
        width: ScreenUtils.width - 80,
        textAlign: 'center',
        fontSize: px2dp(17),
        color: '#444444',
    },
    rightText: {
        textAlign: 'center',
        color: '#FF5252',
        fontSize: px2dp(17)
    },
    confirmImg: {
        resizeMode: 'contain',
        width: px2dp(18),
        height: px2dp(18),
    }
});
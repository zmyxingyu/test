/**
 * 通用导航头部
 * Created by lizhj on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    View,
    Text,Platform,
    Image,
    TouchableOpacity
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';

export default class CommonHeader extends Component {
    //PropType声明
    static propTypes = {
        title: PropTypes.string.isRequired,
        rightName: PropTypes.string.isRequired,
        onSubmit: PropTypes.func.isRequired,
        onBack: PropTypes.func.isRequired,
        clickable:PropTypes.bool.isRequired,
    };

    //默认属性
    static defaultProps = {
        title: '',
        rightName:'',
        onSubmit: null,
        onBack: null,
        clickable:false,
    };

    render() {
        return (
            <View style={styles.headerContainer}>
                <TouchableOpacity activeOpacity={theme.btnActiveOpacity}
                    style={styles.touchableArea}
                    onPress={this.props.onBack}
                >
                    <Image
                        style={styles.backImg}
                        source={require('../image/icon_back.png')}
                    />
                </TouchableOpacity>
                <Text style={styles.titleText}>{this.props.title}</Text>
                {
                    this.props.clickable?
                        <TouchableOpacity activeOpacity={theme.btnActiveOpacity}
                            style={styles.touchableArea}
                            onPress={this.props.onSubmit}
                        >
                            <Text style={{ width: px2dp(50),textAlign: 'center',
                                fontSize: px2dp(17),color: '#ff5252',justifyContent: 'center'}}>{this.props.rightName}</Text>
                        </TouchableOpacity>
                        :
                        <Text style={{ width: px2dp(50),textAlign: 'center',
                            fontSize: px2dp(17),color: '#999',justifyContent: 'center'}}>{this.props.rightName}</Text>
                }
            </View>
        )
    }
}
const styles = StyleSheet.create({
    headerContainer: {
        backgroundColor: 'white',
        flexDirection: 'row',
        height: theme.actionBar.height,
        width: ScreenUtils.width,
        alignItems: 'center',
        paddingTop: (Platform.OS === 'ios' ? ScreenUtils.isIPhoneX ? px2dp(44) : px2dp(20) : 0),
    },
    touchableArea: {
        width: px2dp(50),
        height: px2dp(50),
        justifyContent: 'center',
    },
    backImg: {
        marginLeft: px2dp(10),
        width: px2dp(12),
        height: px2dp(20),
    },
    titleText: {
        flex: 1,
        textAlign: 'center',
        fontSize: px2dp(17),
        color: '#444444',
    }
});
/**
 * 自定义的内容栏，可以对内容栏右侧自定义
 * Created by lizhj on 2017/8/25.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    View,
    Text,
    TouchableOpacity
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';

export default class CustomCommonItem extends Component {
    //PropType声明
    static propTypes = {
        title: PropTypes.string.isRequired,
        renderRight: PropTypes.func.isRequired,
        onClick: PropTypes.func,
        clickable: PropTypes.bool,
    };

    //默认属性
    static defaultProps = {
        title: '',
        renderRight: null,
        onClick: null,
        clickable: true,
    };

    render() {
        const title = this.props.title;
        return (
            <TouchableOpacity
                disabled={!this.props.clickable}
                activeOpacity={theme.btnActiveOpacity}
                onPress={this.props.onClick}
            >
                <View style={[styles.commonItemLayout, this.props.style]}>
                    <Text style={styles.title}>{title}</Text>
                    <View style={styles.rightLayout}>
                        {this.props.renderRight()}
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    commonItemLayout: {
        paddingRight: px2dp(15),
        backgroundColor: 'white',
        flexDirection: 'row',
        height: px2dp(56),
        width: ScreenUtils.width,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#f2f2f2'
    },
    rightLayout: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    touchableLayout: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    title: {
        marginLeft: px2dp(15),
        fontSize: px2dp(16),
        color: '#444444'
    },
    content: {
        fontSize: px2dp(14),
        color: '#999999'
    },
    rightArrowImg: {
        width: px2dp(5),
        height: px2dp(10),
        resizeMode: 'contain',
        marginLeft: px2dp(6),
    },
});
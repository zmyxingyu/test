/**
 * Created by lizhj on 2017/10/16.
 */
import React from 'react';
import {
    Text,
    StyleSheet
} from 'react-native';
import DividingLine from '../component/DividingLine';
import px2dp from '../utils/px2dp';
import ScreenUtils from '../utils/ScreenUtils'

export default function customHrTag(node, index, siblings, parent, defaultRenderer) {
    const divideWidth = ScreenUtils.width - px2dp(15) * 2;
    if (node.name === 'hr') {
        return (
            <DividingLine
                key={index}
                style={{width: divideWidth, backgroundColor: '#DFDFDF', marginBottom: px2dp(16)}}/>
        );
    } else if (node.name === 'h1') {
        const specialStyle = node.attribs.style;
        return (
            <Text key={index} style={[specialStyle, {fontWeight: 'bold', fontSize: px2dp(20), paddingBottom: px2dp(8)}]}>
                {defaultRenderer(node.children, parent)}
            </Text>
        );
    } else if (node.name === 'br') {
        return (
            <Text key={index}>{''}</Text>
        );
    }
}
const styles = StyleSheet.create({
    defaultText: {
        fontSize: px2dp(16),
        color: '#999999',
    }
});
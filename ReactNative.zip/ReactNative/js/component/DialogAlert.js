/**
 * 提醒对话框，包含一个标题，一个子标题，一个确认按钮
 * Created by lizhj on 2017/9/1.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity
} from 'react-native';
import PopupDialog from 'react-native-popup-dialog';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import ScreenUtils from '../utils/ScreenUtils';

export default class DialogAlert extends Component {
    //PropType声明
    static propTypes = {
        title: PropTypes.string,
        subTitle: PropTypes.string,
        onConfirm: PropTypes.func.isRequired,
    };

    //默认属性
    static defaultProps = {
        title: '',
        subTitle: '',
        onConfirm: null,
    };


    renderConfirmButton() {
        return (
            <TouchableOpacity
                style={styles.confirmBg} activeOpacity={theme.btnActiveOpacity}
                onPress={this.props.onConfirm}>
                <View>
                    <Text style={styles.buttonText}>知道了</Text>
                </View>
            </TouchableOpacity>
        );
    }

    render() {
        let width = 320;
        if (ScreenUtils.width - 60 < 320) {
            width = ScreenUtils.width - 60;
        }
        return (
            <PopupDialog
                {...this.props}
                ref={(popupDialog) => {
                    this.alertDialog = popupDialog;
                }}
                width={px2dp(width)}
                height={px2dp(185)}
            >
                <Text style={styles.title}>{this.props.title}</Text>
                <Text style={styles.subTitle}>{this.props.subTitle}</Text>
                {this.renderConfirmButton()}
            </PopupDialog>
        );
    }
}

const styles = StyleSheet.create({
    title: {
        marginTop: px2dp(45),
        fontSize: px2dp(18),
        textAlign: 'center',
        color: '#222222'
    },
    subTitle: {
        marginTop: 10,
        fontSize: px2dp(14),
        textAlign: 'center',
        color: '#999999'
    },
    confirmBg: {
        backgroundColor: '#FF3A3B',
        height: px2dp(44),
        marginRight: px2dp(18),
        marginLeft: px2dp(18),
        borderRadius: px2dp(4),
        marginTop: px2dp(25),
        justifyContent: 'center',
    },
    buttonText: {
        color: 'white',
        fontSize: px2dp(16),
        textAlign: 'center',
    },
});
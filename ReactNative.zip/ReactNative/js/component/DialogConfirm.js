﻿/**
 *  确认对话框
 *  包含一个标题，一个取消按钮，一个确认按钮
 * Created by lizhj on 2017/8/21.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity
} from 'react-native';
import PopupDialog from 'react-native-popup-dialog';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import ScreenUtils from '../utils/ScreenUtils';

export default class DialogConfirm extends Component {
    //PropType声明
    static propTypes = {
        content: PropTypes.string,
        onConfirm: PropTypes.func,
    };
    //默认属性
    static defaultProps = {
        content: '确定要删除吗？',
        onConfirm: null,
    };

    renderCancelButton() {
        return (
            <TouchableOpacity activeOpacity={theme.btnActiveOpacity} onPress={() => {
                this.popupDialog.dismiss();
            }}
            >
                <View style={styles.cancelBg}>
                    <Text style={styles.buttonText}>取消</Text>
                </View>
            </TouchableOpacity>
        );
    }

    renderConfirmButton() {
        return (
            <TouchableOpacity activeOpacity={theme.btnActiveOpacity} onPress={this.props.onConfirm}>
                <View style={styles.confirmBg}>
                    <Text style={styles.buttonText}>确定</Text>
                </View>
            </TouchableOpacity>
        );
    }

    render() {
        let width = 320;
        if (ScreenUtils.width - 60 < 320) {
            width = ScreenUtils.width - 60;
        }
        return (
            <PopupDialog
                {...this.props}
                ref={(popupDialog) => {
                    this.popupDialog = popupDialog;
                }}
                width={px2dp(width)}
                height={px2dp(185)}
            >
                <View>
                    <Text style={styles.contentText}>{this.props.content}</Text>
                    <View style={styles.buttonLayout}>
                        {this.renderCancelButton()}
                        {this.renderConfirmButton()}
                    </View>
                </View>
            </PopupDialog>
        );
    }
}
const dialogBtnWidth = ScreenUtils.width - 60 < 320 ? 110 : 137;
const styles = StyleSheet.create({
    contentText: {
        marginTop: px2dp(48),
        fontSize: px2dp(18),
        textAlign: 'center',
        color: '#222222'
    },
    buttonLayout: {
        flexDirection: 'row',
        marginTop: px2dp(48),
        justifyContent: 'space-around',
    },
    cancelBg: {
        backgroundColor: '#999999',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    confirmBg: {
        backgroundColor: '#FF3A3B',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        color: 'white',
        fontSize: px2dp(16),
        textAlign: 'center',
    },
});
/**
 *  确认对话框
 * Created by lizhj on 2017/8/21.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    TextInput,
    Keyboard,
} from 'react-native';
import PopupDialog from 'react-native-popup-dialog';
import px2dp from '../utils/px2dp';
import ScreenUtils from '../utils/ScreenUtils';
import theme from '../utils/theme';

export default class DialogInput extends Component {

    //PropType声明
    static propTypes = {
        title: PropTypes.string,
        content: PropTypes.string,
        contentLength: PropTypes.number,
        onConfirm: PropTypes.func.isRequired,
    };

    //默认属性
    static defaultProps = {
        title: '',
        content: '',
        contentLength: 16,
        onConfirm: null,
    };

    constructor(props) {
        super(props);
        this.state = {
            text: this.props.content,
        };
    }

    getInputText = () => {
        return this.state.text;
    };

    renderCancelButton() {
        return (
            <TouchableOpacity
                onPress={() => {
                    Keyboard.dismiss();
                    this.popupDialog.dismiss();
                }}
                activeOpacity={theme.btnActiveOpacity}
            >
                <View style={styles.cancelBg}>
                    <Text style={styles.buttonText}>取消</Text>
                </View>
            </TouchableOpacity>
        );
    }

    renderConfirmButton() {
        return (
            <TouchableOpacity onPress={this.props.onConfirm} activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.confirmBg}>
                    <Text style={styles.buttonText}>确定</Text>
                </View>
            </TouchableOpacity>
        );
    }

    render() {
        let width = 320;
        if (ScreenUtils.width - 60 < 320) {
            width = ScreenUtils.width - 60;
        }
        return (
            <PopupDialog
                {...this.props}
                ref={(popupDialog) => {
                    this.popupDialog = popupDialog;
                }}
                width={px2dp(width)}
                height={px2dp(185)}
            >
                <View>
                    <Text style={styles.titleText}>{this.props.title}</Text>
                    <TextInput
                        maxLength={this.props.contentLength}
                        style={[styles.textInput, {width: px2dp(width) - px2dp(36)}]}
                        underlineColorAndroid="transparent"
                        onChangeText={(text) => this.setState({text})}
                        value={this.state.text}
                    />
                    <View style={styles.buttonLayout}>
                        {this.renderCancelButton()}
                        {this.renderConfirmButton()}
                    </View>
                </View>
            </PopupDialog>
        );
    }
}

const dialogBtnWidth = ScreenUtils.width - 60 < 320 ? 110 : 137;
const styles = StyleSheet.create({
    titleText: {
        marginTop: px2dp(20),
        fontSize: px2dp(18),
        textAlign: 'center',
        color: '#222222'
    },
    textInput: {
        borderWidth: ScreenUtils.onePixel,
        height: px2dp(44),
        marginTop: px2dp(10),
        borderColor: '#E0E0E0',
        alignSelf: 'center',
        fontSize: px2dp(18),
    },
    buttonLayout: {
        flexDirection: 'row',
        marginTop: px2dp(22),
        justifyContent: 'space-around',
    },
    cancelBg: {
        backgroundColor: '#999999',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    confirmBg: {
        backgroundColor: '#FF3A3B',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        color: 'white',
        fontSize: px2dp(16),
        textAlign: 'center',
    },
});
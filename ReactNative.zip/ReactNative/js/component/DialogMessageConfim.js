/**
 *  确认对话框
 *  包含一个标题，一个取消按钮，一个确认按钮
 * Created by lizhj on 2017/8/21.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity
} from 'react-native';
import theme from '../utils/theme';
import PopupDialog from 'react-native-popup-dialog';
import px2dp from '../utils/px2dp';
import ScreenUtils from '../utils/ScreenUtils';

export default class DialogMessageConfim extends Component {
    //PropType声明
    static propTypes = {
        message: PropTypes.string,
        content: PropTypes.string,
        cancelText: PropTypes.string,
        confirmText: PropTypes.string,
        onConfirm: PropTypes.func,
        onCancel: PropTypes.func,
    };
    //默认属性
    static defaultProps = {
        content: '确定要删除吗？',
        message: '',
        cancelText: '取消',
        confirmText: '确定',
        onConfirm: null,
        onCancel: null,
    };

    renderCancelButton() {
        if(this.props.onCancel){
            return (
                <TouchableOpacity onPress={this.props.onCancel} activeOpacity={theme.btnActiveOpacity}>
                    <View style={styles.cancelBg}>
                        <Text style={styles.buttonText}>{this.props.cancelText}</Text>
                    </View>
                </TouchableOpacity>
            );
        }else{
            return (
                <TouchableOpacity onPress={() => {
                    this.popupDialog.dismiss();
                }} activeOpacity={theme.btnActiveOpacity}
                >
                    <View style={styles.cancelBg}>
                        <Text style={styles.buttonText}>{this.props.cancelText}</Text>
                    </View>
                </TouchableOpacity>
            );
        }
    }

    renderConfirmButton() {
        return (
            <TouchableOpacity onPress={this.props.onConfirm} activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.confirmBg}>
                    <Text style={styles.buttonText}>{this.props.confirmText}</Text>
                </View>
            </TouchableOpacity>
        );
    }

    render() {
        let width = 320;
        if (ScreenUtils.width - 60 < 320) {
            width = ScreenUtils.width - 60;
        }
        return (
            <PopupDialog
                {...this.props}
                ref={(popupDialog) => {
                    this.popupDialog = popupDialog;
                }}
                width={px2dp(width)}
                height={px2dp(185)}
            >
                <View>
                    <Text style={styles.contentText}>{this.props.content}</Text>
                    <Text style={{fontSize: px2dp(14),textAlign: 'center',color: '#6f6f6f',marginTop:px2dp(10),marginLeft:px2dp(25),marginRight:px2dp(25)}}>{this.props.message}</Text>
                    <View style={styles.buttonLayout}>
                        {this.renderCancelButton()}
                        {this.renderConfirmButton()}
                    </View>
                </View>
            </PopupDialog>
        );
    }
}

const dialogBtnWidth = ScreenUtils.width - 60 < 320 ? 110 : 137;
const styles = StyleSheet.create({
    contentText: {
        marginTop: px2dp(35),
        fontSize: px2dp(18),
        textAlign: 'center',
        color: '#222222'
    },
    buttonLayout: {
        flexDirection: 'row',
        marginTop: px2dp(25),
        justifyContent: 'center',
    },
    cancelBg: {
        backgroundColor: '#999999',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 4,
        marginRight:px2dp(10),
        justifyContent: 'center',
        alignItems: 'center'
    },
    confirmBg: {
        backgroundColor: '#FF3A3B',
        width: px2dp(dialogBtnWidth),
        height: px2dp(44),
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText: {
        color: 'white',
        fontSize: px2dp(16),
        textAlign: 'center',
    },
});
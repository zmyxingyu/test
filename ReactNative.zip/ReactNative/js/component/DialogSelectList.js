/**
 * 列表对话框
 * Created by lizhj on 2017/9/6.
 */
import React, {Component, PropTypes} from 'react';
import {
    StyleSheet,
    Text,
    TouchableOpacity,
} from 'react-native';
import PopupDialog from 'react-native-popup-dialog';
import ScreenUtils from '../utils/ScreenUtils';
import theme from '../utils/theme';

export default class DialogSelectList extends Component {

    //PropType声明
    static propTypes = {
        items: PropTypes.array.isRequired,
        onSelect: PropTypes.func.isRequired,
    };

    //默认属性
    static defaultProps = {
        items: [],
        onSelect: null,
    };

    render() {
        return (
            <PopupDialog
                {...this.props}
                ref={(popupDialog) => {
                    this.selectDialog = popupDialog;
                }}
                width={ScreenUtils.width - 30}
                height={110}
            >
                {
                    this.props.items.map((item, index) => {
                        return (
                            <TouchableOpacity activeOpacity={theme.btnActiveOpacity}
                                key={item}
                                style={styles.itemContainer}
                                onPress={() => {
                                    this.props.onSelect(index);
                                }}>
                                <Text style={styles.itemText}>{item}</Text>
                            </TouchableOpacity>
                        );
                    })
                }
            </PopupDialog>
        );
    }
}
const styles = StyleSheet.create({
    itemText: {
        fontSize: 16,
        marginLeft: 20,
        color: 'black',
    },
    itemContainer: {
        flex: 1,
        height: 50,
        justifyContent: 'center',
    }
});
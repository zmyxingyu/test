/**
 * 优惠券item组件
 * Created by lizhj on 2017/10/9.
 */
import React, {Component, PropTypes} from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';
import px2dp from '../utils/px2dp';
import {dateFormat} from '../utils/FormatDateUtil';
import theme from '../utils/theme';

export default class DiscountItem extends Component {
    //PropType声明
    static propTypes = {
        cardName: PropTypes.string.isRequired,
        cardValue: PropTypes.number.isRequired,
        validEndTime: PropTypes.number.isRequired,
        discountSelected: PropTypes.func.isRequired,
    };

    //默认属性
    static defaultProps = {
        cardName: null,
        cardValue: 0,
        validEndTime: 0,
        discountSelected: null,
    };

    render() {
        const isOutOfDate = new Date().getTime() > this.props.validEndTime;
        return (
            isOutOfDate ?
                <View style={styles.container}>
                    <View style={styles.cardContent}>
                        <Text style={styles.cardNameStyle2}>{this.props.cardName}</Text>
                    </View>
                    <View style={styles.cardFooter}>
                        <Text style={styles.validEndTimeText2}>{`有效期至：${dateFormat(this.props.validEndTime)}`}</Text>
                        {isOutOfDate ? <Text style={styles.outOfDateText}>已过期</Text> : null}
                    </View>
                </View> :
                <TouchableOpacity onPress={this.props.discountSelected}
                                  activeOpacity={theme.btnActiveOpacity}>
                    <View style={styles.container}>
                        <View style={styles.cardContent}>
                            <Text style={styles.cardNameStyle}>{this.props.cardName}</Text>
                        </View>
                        <View style={styles.cardFooter}>
                            <Text style={styles.validEndTimeText}>{`有效期至：${dateFormat(this.props.validEndTime)}`}</Text>
                        </View>
                    </View>
                </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        marginRight: px2dp(15),
        marginLeft: px2dp(15),
        marginTop: px2dp(15),
        paddingTop: px2dp(20),
        borderRadius: px2dp(4),
        height: px2dp(134),
    },
    cardContent: {
        flex: 1,
        paddingLeft: px2dp(20),
        paddingRight: px2dp(20),
    },
    cardNameStyle: {
        fontSize: px2dp(20),
        color: '#444444',
    },
    cardNameStyle2: {
        fontSize: px2dp(20),
        color: '#CCCCCC',
    },
    cardDescStyle: {
        fontSize: px2dp(14),
        color: '#999999',
        marginTop: px2dp(6),
    },
    cardDescStyle2: {
        fontSize: px2dp(14),
        color: '#CCCCCC',
        marginTop: px2dp(6),
    },
    cardFooter: {
        paddingLeft: px2dp(20),
        paddingRight: px2dp(20),
        flexDirection: 'row',
        backgroundColor: '#f7f7f7',
        alignItems: 'center',
        paddingTop: px2dp(10),
        paddingBottom: px2dp(10),
        height: px2dp(40),
    },
    validEndTimeText: {
        fontSize: px2dp(14),
        color: '#999999',
    },
    validEndTimeText2: {
        flex: 1,
        fontSize: px2dp(14),
        color: '#CCCCCC',
    },
    outOfDateText: {
        fontSize: px2dp(14),
        color: '#CCCCCC',
    },
});
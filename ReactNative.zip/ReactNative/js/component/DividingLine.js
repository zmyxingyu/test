/**
 * Created by lizhj on 2017/8/17.
 */
import React, {Component} from 'react';
import {
    View,
} from 'react-native';
import ScreenUtils from '../utils/ScreenUtils';

export default class DividingLine extends Component {
    render() {
        return (
            <View style={[{
                width: ScreenUtils.width,
                height: ScreenUtils.onePixel,
                backgroundColor: '#E0E0E0',
            }, this.props.style]}
            />
        );
    }
};
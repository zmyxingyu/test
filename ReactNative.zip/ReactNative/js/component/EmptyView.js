/**
 * Created by lizhj on 2017/7/17.
 */
import React, {Component,PropTypes} from 'react';
import {View, Text,Image, StyleSheet} from 'react-native';
import screen from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';

export default class EmptyView extends Component {
    //PropType声明
    static propTypes = {
        tips: PropTypes.string.isRequired,
    };

    //默认属性
    static defaultProps = {
        tips: '暂无数据',
    };

    render() {
        return (
            <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(80)}}>
                <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>{this.props.tips}</Text>
            </View>
        );
    }
}
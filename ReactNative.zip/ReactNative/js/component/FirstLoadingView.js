/**
 * Created by lizhj on 17/5/11.
 * 正在加载组件
 */

import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import theme from '../utils/theme';

export default class FirstLoadingView extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Text style={styles.tipText}>
                    正在加载中...
                </Text>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: theme.pageBackgroundColor
    },
    tipText: {
        color: '#AEAEAE',
        fontSize: 14,
        marginTop: 15,
    },
});
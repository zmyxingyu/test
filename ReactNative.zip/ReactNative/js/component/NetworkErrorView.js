/**
 * Created by lizhj on 2017/5/24.
 */
import React, {Component, PropTypes} from 'react'
import {View, Text, Image, TouchableOpacity, StyleSheet} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';

export default class NetworkErrorView extends Component {
    static propTypes = {
        onPress: PropTypes.func.isRequired,
    };

    //默认属性
    static defaultProps = {
        onPress: null,
    };

    render() {
        return (
            <View style={styles.container}>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: px2dp(70)}}>
                    <Image source={require('../image/no_network.png')}
                           style={{width: px2dp(140), height: px2dp(140), resizeMode: 'cover'}}/>
                    <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>网络不顺畅</Text>
                    <TouchableOpacity onPress={this.props.onPress} activeOpacity={theme.btnActiveOpacity}
                                      style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{marginTop:px2dp(88),borderRadius:px2dp(4),justifyContent:'center',alignItems:'center',borderColor:'#ff5252',borderWidth:px2dp(1),height:px2dp(40),width:px2dp(110)}}>
                            <Text style={{color: '#ff5252',textAlign:'center',fontSize: px2dp(17)}}>重新加载</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: theme.backgroundColor,
    },
    tipText: {
        color: '#AEAEAE',
        fontSize: px2dp(17),
        marginTop: 8,
        marginBottom: 10,
    },
    reloadBtn: {
        borderRadius: 5,
        color: 'white',
        fontSize: 14,
        padding: 5,
        backgroundColor: '#25A5E1'
    },
})
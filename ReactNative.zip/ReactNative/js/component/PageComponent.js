/**
 * Created by yf on 2017/8/24.
 * 监听返回键关闭
 */
import React, {Component,PropTypes} from 'react';
import {BackHandler,NativeModules} from 'react-native';

export default class PageComponent extends Component{

    constructor(props){
        super(props);
        this.handleBack = this._handleBack.bind(this);
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress', this.handleBack);
    }

    componentWillUnmount() {
        BackHandler.removeEventListener('hardwareBackPress', this.handleBack);
    }

    _handleBack() {
        NativeModules.CommonModule.goBack();
    }

}
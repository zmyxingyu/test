/**
 *
 * Created by lizhj on 2017/8/28.
 */
export default {
    HTTP_BASE_URL_RELEASE: 'http://121.14.129.183:83',
    HTTP_BASE_URL_HUIDU: 'http://121.14.129.183:83',
    HTTP_BASE_URL_TEST: 'http://121.14.129.183:83',
    HTTP_BASE_URL: 'http://121.14.129.183:83',//http://k.21cn.com
    shareCircleURL: '/api/app/5.0.0/share/mark_list.html?listId=',//分享圈子/清单二维码地址
    sharePersonalURL: '/api/app/5.0.0/share/personal.html?targetOpenid=',//分享个人二维码地址
    getTagList: '/api/v5/marklist/tag/list', //获取圈子/清单的标签列表
    getCircleMemberList: '/api/v5/marklist/members.do', //获取圈子成员列表
    subscribers: '/api/v5/marklist/subscribers.do', //获取圈子订阅者成员列表
    getListingDetail: '/api/v5/marklist/info.do', //获取圈子/清单详细信息
    updateInfo: '/api/v5/marklist/update.do', //修改圈子/清单
    updateUserInfo: '/api/v5/user/update.do',//修改用户信息
    updateNickName: '/api/v5/marklist/member/updateNickName.do',//修改所在圈子昵称
    changePushSwitch: '/api/v5/marklist/pushSwitch.do', //修改圈子的订阅开关
    subscribeMarkList: '/api/v5/marklist/subscribe.do', //订阅清单／圈子
    deleteMarkList: '/api/v5/marklist/delete.do', //删除圈子／清单
    unSubscribeMarkList: '/api/v5/marklist/unsubscribe.do',//退订圈子／清单
    rank: '/api/rank/rank.html',//等级
    introduction: '/introduction_v4.7.html',//使用指南
    suspension: '/suspension_setting.html',//使用指南
    wapHelpAndFeedback: 'https://help.21cn.com/feedback/wapHelpAndFeedback.do?',//问题反馈
    deleteMember: '/api/v5/marklist/removeMember.do', //移除圈子成员
    credit: '/api/app/exchange_center/index.html',//兑换中心
    otherIndex: '/api/v5/user/index.do',//其他用户主页
    updateRemarkName: '/api/userCenter/updateRemarkName.do',//修改备注
    addExtract: '/api/v5/mark/add.do', //添加摘抄
    coinRecord: '/api/payment/coinRecord.do', //交易记录
    updateConcern: '/api/v5/user/relation/update.do',//关注
    pushSwitch: '/api/v5/user/relation/pushSwitch.do',//用户推送开关设置
    markList: '/api/v5/marklist/list.do',//圈子清单列表
    getDiscountList: '/api/payment/cards.do', //获取可用优惠券
    getAllDiscount: '/api/payment/allCards.do', //获取全部优惠券
    getOperatingAd: '/api/v5/article/getOperating.do', //获取运营广告
    discountUseRule: '/api/app/5.0.0/manual/coupon_rules.html', //优惠券使用规则
    circlePayRule: '/api/app/5.0.0/manual/marklist_pay_rules.html', //清单圈子付费规则
    circleManageRule: '/api/app/5.0.0/manual/marklist_rules.html', //圈子运营规则
    myIndex: '/api/v5/user/myindex.do',//我的主页
    addMarkOrCircle: '/api/v5/marklist/add.do',//创建清单、圈子  0 清单  1 圈子
    getDraftArticleList: '/api/v5/publish/getDraftArticleList.do',//获取草稿列表
    deleteArticle: '/api/v5/publish/deleteArticle.do',//删除文章或草稿
    firstIndex: '/api/v5/feed/index.do',//首页列表数据
};
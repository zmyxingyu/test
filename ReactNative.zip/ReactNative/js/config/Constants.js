/**
 * Created by lizhj on 2017/8/17.
 */

export default {
    MINEINFO: 'mineInfo',
    USERINFO: 'userInfo',//用户信息  暂时不用
    FIRSTINFO: 'firstInfo',
    OPENPUSH: 'openPush',
    OPENWINDOW: 'openWindow',
    waitInfo: '正在提交数据，请稍后...',
    NAME_REGEX: /^[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
    JOB_REGEX: /^[a-zA-Z\u4e00-\u9fa5]+$/,
    openid: '',
    LIST_TYPE: {
        LISTING: 0, //清单
        CIRCLE: 1, //圈子
    },
    CIRCLE_IDENTITY_TYPE: {
        SUBSCRIBER: 0, //订阅用户
        MEMBER: 1, //圈子成员
        OWNER: 2, //圈主
    },

    PAY_TYPE: { //圈子清单订阅用户
        FREE: 0, //免费
        MONTH: 1, //按月付费
        YEAR: 2, //按年付费
        PERMANENT: 3, //永久
    },
    SWITCH: { //开关状态
        OFF: 0,
        ON: 1,
    },
    NATIVE_CACHE_TYPE: {
        boolean: 'boolean',
        int: 'int',
        long: 'long',
        string: 'string',
        float: 'float',
    },
    UPDATE_MINEINFO_TYPE: {
        UPDATE_CIRCLE_NAME: 0, //更新圈子名称
        UPDATE_LISTING_NAME: 1, //更新清单名称
        DELETE_CIRCLE: 2, //删除圈子
        DELETE_LISTING: 3, //删除清单
        TRANSFORM_LISTING: 4, //将清单转换为圈子
        UPDATE_PRIVATE_STATE: 5, //更改私密开关状态
    },
    HAS_SUBSCRIBE: {
        NO: 0,
        YES: 1,
    },
    IS_PRIVATE: {
        NO: 0,
        YES: 1,
    }
};
/**
 * 添加清单的页面
 * Created by yf on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    Text, View, StyleSheet,Image, Keyboard,NativeEventEmitter,AsyncStorage,DeviceEventEmitter,NativeModules,Platform, PixelRatio, TouchableOpacity, TextInput,ScrollView
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import CommonHeader from  '../component/CommonHeaderText';
import Toast,{DURATION} from 'react-native-easy-toast';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import APIService from '../config/APIService';
import HTMLView from 'react-native-htmlview';
import DividingLine from  '../component/DividingLine';
import customHrTag from '../component/CustomHrTagComponent';
import getStringLen from '../utils/CommonUtils';

const {CommonModule} = NativeModules;
const {MarkManager} = NativeModules;
const MarkManagerEmitter = new NativeEventEmitter(MarkManager);
var isPosting=true;//是否提交
export default class AddMarkPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title:'',
            description:'',
            price:0,
            clickable:false,
            markProfile:'',
            switchBtn:false,//私密  false表示公开
            isFree:true,//true表示免费
            payMethod:0,//付款方式  0:免费  1：按月  2：按年  3：永久
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            this.saveMarkProfile = MarkManagerEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({markProfile:response.content});
            });
        }else{
            this.saveMarkProfile = DeviceEventEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({markProfile:response.content});
            });
        }
    }

    componentWillUnmount() {
        this.saveMarkProfile.remove();
    }

    _handleItemClick(position){
        switch (position){
            case 0:
                if(this.state.switchBtn){
                    this.setState({switchBtn:false})
                }else{
                    this.setState({switchBtn:true})
                }
                break;
            case 1:
                this.setState({isFree:true,payMethod:0})
                break;
            case 2:
                this.setState({isFree:false,payMethod:1})
                break;
            case 3:
                this.setState({payMethod:1})
                break;
            case 4:
                this.setState({payMethod:2})
                break;
            case 5:
                this.setState({payMethod:3})
                break;
            case 6://确定
                Keyboard.dismiss();
                if(this.state.title == '' || this.state.title == null){
                    this.toast.show('请输入清单名称',DURATION.LENGTH_SHORT);
                    break;
                }
                if(!this.state.isFree){
                    if(this.state.price < 1 || this.state.price >200){
                        this.toast.show('请输入合理的价格',DURATION.LENGTH_SHORT);
                        break;
                    }
                }
                if(isPosting){
                    isPosting=false;
                    this._fetchData();
                }
                break;
            case 7://跳转到文章发布页编辑
                NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?listType=0&isEditArticle=0&markContent="+this.state.markProfile);
                break;
        }
    }

    _fetchData() {
        let context = this;
        if (!Constants.NAME_REGEX.test(this.state.title)) {
            isPosting=true;
            context.toast.show('名称应为中英文、数字和下划线', DURATION.LENGTH_LONG);
            return;
        } else if (getStringLen(this.state.title) < 4 || getStringLen(this.state.title) > 40) {
            isPosting=true;
            context.toast.show('名称应为2-20个汉字或4-40个字母', DURATION.LENGTH_LONG);
            return;
        }
        NativeModules.CommonModule.showRNLoadingProgress(Constants.waitInfo);
        var url = APIService.addMarkOrCircle;
        let par = {
            'openid' : this.props.openid,
            'listName' : this.state.title,
            'description' : this.state.markProfile,
            'payType' : this.state.payMethod+"",
            'payPrice' : this.state.price+"",
            'listType' : "0",
            'isPrivate' : (this.state.switchBtn?1:0)+""
        };
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            isPosting=true;
            if(data){
                if(data.ret === 0){
                    context.asQuery(Constants.MINEINFO,data.obj)
                    NativeModules.CommonModule.sendUpdateCircleInfoEvent();
                    NativeModules.CommonModule.goBack();

                }else{
                    context.toast.show(data.msg,DURATION.LENGTH_SHORT);
                }
            }
        });
    }

    asQuery(key,obj) {
        AsyncStorage.getItem(key, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    data.marklists.push(obj);
                    AsyncStorage.setItem(key, JSON.stringify(data), (error) => {
                        if (!error) {
                            if (Platform.OS === 'ios') {
                                CommonModule.refreshMinePage();
                            } else {
                                DeviceEventEmitter.emit('refreshMine');
                            }
                        }
                    });
                }
            }
        })
    }

    render()
    {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'创建清单'}
                    onBack={() => {
                        NativeModules.CommonModule.goBack();
                    }
                    }
                    clickable={this.state.clickable}
                    rightName={'保存'}
                    onSubmit={() => {
                        this._handleItemClick(6);
                    }}
                />
                <ScrollView style={styles.container}>
                    <View style={styles.container}>
                        <View style={{flexDirection:'row',height: px2dp(56),marginTop:px2dp(15),alignItems:'center',backgroundColor:'white'}}>
                            <TextInput placeholder={'名字（不超过20字）'} numberOfLines={1} placeholderTextColor={'#999'} underlineColorAndroid={'transparent'}
                                       style={{fontSize:px2dp(16),color:'#444',flex:1,paddingLeft:px2dp(10),paddingRight:px2dp(10),backgroundColor:'white'}}
                                       onChangeText={(text) => {
                                           this.setState({title:text});
                                           if(text != '' && text != null){
                                               this.setState({clickable:true});
                                           }else{
                                               this.setState({clickable:false});
                                           }
                                       }}/>
                        </View>
                        <View style={{flexDirection:'row',marginTop:15}}>
                            <TouchableOpacity onPress={this._handleItemClick.bind(this,7)} style={{flex:1}} activeOpacity={theme.btnActiveOpacity}>
                                {
                                    this.state.markProfile?
                                        <HTMLView
                                            value={this.state.markProfile}
                                            style={{flex:1,padding:px2dp(10),backgroundColor:'white',minHeight:px2dp(146)}}
                                            renderNode={customHrTag}
                                             textComponentProps={{style: styles.p}}
                                        />
                                        :
                                        <HTMLView  stylesheet={styles}
                                            value={"<p>简单描述一下清单（选填）</p>"}
                                            style={{height: px2dp(146),flex:1,padding:px2dp(10),backgroundColor:'white'}}
                                        />
                                }
                            </TouchableOpacity>
                        </View>
                        <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white', marginTop:px2dp(10)}}>
                            <Text style={{fontSize:px2dp(15),color:'#000',flex:1,paddingLeft:px2dp(10)}}>私密清单</Text>
                            <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity}>
                                {
                                    this.state.switchBtn?<Image source={require('../image/switch_on.png')} style={{width: px2dp(51),height: px2dp(31),resizeMode: 'contain'}}/>
                                        :<Image source={require('../image/switch_off.png')} style={{width: px2dp(51),height: px2dp(31),resizeMode: 'contain'}}/>
                                }
                            </TouchableOpacity>
                        </View>
                        <View style={{flexDirection:'row',marginTop:px2dp(10)}}>
                            <Text style={{height: px2dp(20),fontSize:px2dp(14),flex:1,color:'#666',marginLeft:px2dp(10)}}>开启私密清单后只有自己能够查看此清单。</Text>
                        </View>
                        {
                            this.state.switchBtn?null:
                                <View>
                                    <TouchableOpacity onPress={this._handleItemClick.bind(this,1)} activeOpacity={theme.btnActiveOpacity}>
                                        <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white',
                                            marginTop:px2dp(30)}}>
                                            <Text style={{fontSize:px2dp(16),color:'#000',flex:1,paddingLeft:px2dp(10)}}>免费订阅</Text>
                                            {
                                                this.state.isFree?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                                                    :null
                                            }
                                        </View>
                                    </TouchableOpacity>
                                    <DividingLine/>
                                    <TouchableOpacity onPress={this._handleItemClick.bind(this,2)} activeOpacity={theme.btnActiveOpacity}>
                                        <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>
                                            <Text style={{fontSize:px2dp(16),color:'#000',flex:1,paddingLeft:px2dp(10)}}>付费订阅</Text>
                                            {
                                                !this.state.isFree?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                                                    :null
                                            }
                                        </View>
                                    </TouchableOpacity>
                                    {
                                        !this.state.isFree?
                                            <View >
                                                <View style={{flexDirection:'row',marginTop:px2dp(30)}}>
                                                    <Text style={{height: px2dp(20),fontSize:px2dp(14),flex:1,color:'#666',marginLeft:px2dp(10),marginBottom:px2dp(8)}}>付费金额</Text>
                                                </View>
                                                <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>
                                                    <TextInput placeholder={'1~200'} keyboardType='numeric' numberOfLines={1} placeholderTextColor={'#999'} underlineColorAndroid={'transparent'}
                                                               style={{fontSize:px2dp(16),paddingLeft:px2dp(10),paddingRight:px2dp(10),color:'#444',flex:1,backgroundColor:'white'}}
                                                               onChangeText={(text) => this.setState({price:text})}/>
                                                    <Text style={{fontSize:px2dp(16),color:'#999',paddingRight:px2dp(10)}}>阅读币</Text>
                                                </View>
                                                <View style={{flexDirection:'row',marginTop:px2dp(30)}}>
                                                    <Text style={{height: px2dp(20),fontSize:px2dp(14),flex:1,color:'#666',marginLeft:px2dp(10)}}>付款方式</Text>
                                                </View>
                                                <TouchableOpacity onPress={this._handleItemClick.bind(this,3)} activeOpacity={theme.btnActiveOpacity}>
                                                    <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white',
                                                        marginTop:px2dp(8)}}>
                                                        <Text style={{fontSize:px2dp(16),color:'#000',flex:1,paddingLeft:px2dp(10)}}>按月付费</Text>
                                                        {
                                                            this.state.payMethod==1?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                                                                :null
                                                        }
                                                    </View>
                                                </TouchableOpacity>
                                                <DividingLine/>
                                                <TouchableOpacity onPress={this._handleItemClick.bind(this,4)} activeOpacity={theme.btnActiveOpacity}>
                                                    <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white',
                                                    }}>
                                                        <Text style={{fontSize:px2dp(16),color:'#000',flex:1,paddingLeft:px2dp(10)}}>按年付费</Text>
                                                        {
                                                            this.state.payMethod==2?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                                                                :null
                                                        }
                                                    </View>
                                                </TouchableOpacity>
                                                <DividingLine/>
                                                <TouchableOpacity onPress={this._handleItemClick.bind(this,5)} activeOpacity={theme.btnActiveOpacity}>
                                                    <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white',marginBottom:px2dp(30)}}>
                                                        <Text style={{fontSize:px2dp(16),color:'#000',flex:1,paddingLeft:px2dp(10)}}>永久有效</Text>
                                                        {
                                                            this.state.payMethod==3?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                                                                :null
                                                        }
                                                    </View>
                                                </TouchableOpacity>
                                            </View>
                                            :
                                            null
                                    }
                                </View>
                        }

                    </View>
                </ScrollView>
                <Toast ref={(ref) => this.toast = ref}  position={'center'}/>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        height: px2dp(50),flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',
        borderBottomWidth: 1/PixelRatio.get(),borderTopColor: '#c4c4c4',borderTopWidth: 1/PixelRatio.get()
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row'
    },
    p: {
        fontSize: px2dp(16),
        color: '#999999',
    },
});
/**
 * 圈子信息页面
 * Created by lizhj on 2017/8/21.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Text,
    Image,
    TouchableOpacity,
    NativeModules,
    ScrollView,
    InteractionManager,
    Linking,
    NetInfo,
    Platform,
    Keyboard,
    DeviceEventEmitter,
    NativeEventEmitter
} from 'react-native';
import {NavigationActions} from 'react-navigation';
import Toast, {DURATION} from 'react-native-easy-toast';
import ScreenUtils from '../utils/ScreenUtils';
import HttpUtils from '../utils/HttpUtils';
import UserInfoUtils from '../utils/UserInfoUtils';
import DividingLine from '../component/DividingLine';
import CommonHeader from '../component/CommonHeader';
import CircleMemberItem from '../component/CircleMemberItem';
import CommonContentItem from '../component/CommonContentItem';
import CCCImage from '../component/CCCImage';
import CCCSwitch from '../component/CCCSwitch';
import Constants from '../config/Constants';
import APIService from '../config/APIService';
import px2dp from '../utils/px2dp';
import getStringLen from '../utils/CommonUtils';
import theme from '../utils/theme';
import CustomCommonItem from '../component/CustomCommonItem';
import DialogInput from '../component/DialogInput';
import DialogAlert from '../component/DialogAlert';
import DialogConfirm from '../component/DialogConfirm';
import DialogMessageConfirm from '../component/DialogMessageConfim';
import NetworkErrorView from '../component/NetworkErrorView';
import FirstLoadingView from '../component/FirstLoadingView';
import URLUtils from '../utils/URLUtils';
import {dateFormat, getNextMonth, getNextYear} from '../utils/FormatDateUtil';

const {CommonModule, RNShareModule, IntentFromJsModule} = NativeModules;
const {RNPurchaseManager} = NativeModules;
const PurchaseEventEmitter = new NativeEventEmitter(RNPurchaseManager);
const {MarkManager, MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
const MarkManagerEmitter = new NativeEventEmitter(MarkManager);

export default class CircleInfoPage extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loaded: false,
            isLogin: this.props.screenProps.isLogin,
            openid: this.props.screenProps.openid,
            listId: this.props.screenProps.listId,
            to: this.props.screenProps.to,
            subscribeNum: 0, //累计订阅人数
            weeklySubscribe: 0, //七天新增订阅
            totalRevenue: 0, //累计收入
            dueRevenue: 0, //已到账收入
            members: [], //成员
            listName: null, //圈子名称
            listType: -1, //类型, 0-清单, 1-圈子
            nickName: null, //在本圈子昵称
            payType: 0,
            payPrice: 0,
            permission: 0,//0-订阅用户,1-圈子成员,2-圈主
            description: '',
            expireDate: '',
            pushSwitch: false,
            creator: {openid: '', nickName: '', iconUrl: null},
            quitFailReason: '已有人付费订阅，不能退出此圈子。',
            distributionType: 0, //收益分配方式
            isSubscribe: 0,
            isNetworkAvailable: true,
            isPrivate: Constants.IS_PRIVATE.NO,
            imgUrl: '',
        };
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            Linking.getInitialURL().then((url) => {
                const result = URLUtils.parseQueryString(url);
                if (result.to) {//从原生页面直接跳转圈子成员页面
                    let resetAction = NavigationActions.reset({
                        index: 0,
                        actions: [NavigationActions.navigate({
                            routeName: 'CircleMemberPage',
                            params: {
                                openid: this.state.openid,
                                listId: result.listId,
                                isCreator: this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER,
                                backToNative: true,
                            },
                        })],
                    });
                    this.props.navigation.dispatch(resetAction);
                } else {
                    InteractionManager.runAfterInteractions(() => {
                        this.params = {
                            openid: this.state.openid,
                            listId: result.listId,
                        };
                        this.requestData();
                    });
                }
            }).catch(err => console.error('An error occurred', err));
        } else {
            if (this.state.to) {
                let resetAction = NavigationActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({
                        routeName: 'CircleMemberPage',
                        params: {
                            openid: this.state.openid,
                            listId: this.state.listId,
                            isCreator: this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER,
                            backToNative: true,
                        },
                    })],
                });
                this.props.navigation.dispatch(resetAction);
            } else {
                InteractionManager.runAfterInteractions(() => {
                    this.params = {
                        openid: this.state.openid,
                        listId: this.state.listId,
                    };
                    this.requestData();
                });
            }
        }

        if (Platform.OS === 'ios') {
            this.saveDraftEvent = PurchaseEventEmitter.addListener('purchaseCircleSuccess', () => {
                this.receivePurchaseSuccess();
            });
            this.saveMarkProfile = MarkManagerEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({description: response.content});
                this.postCircleInfo();
            });
            this.refreshEvent = MineManagerEmitter.addListener('refreshCirclePage', (openid) => {
                this.setState({
                    openid
                }, this.requestData);
            });
        } else {
            this.saveDraftEvent = DeviceEventEmitter.addListener('purchaseCircleSuccess', () => {
                this.receivePurchaseSuccess();
            });
            this.saveMarkProfile = DeviceEventEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({description: response.content});
                this.postCircleInfo();
            });
            this.refreshEvent = DeviceEventEmitter.addListener('refreshCirclePage', (openid) => {
                this.setState({
                    openid
                }, this.requestData);
            });
        }
    }

    postCircleInfo() {
        let params = {
            openid: this.state.openid,
            listId: this.params.listId,
            listName: this.state.listName,
            description: this.state.description,
        };
        HttpUtils.doPost(APIService.updateInfo, params, '').then(({data, error}) => {
            if (data) {
                if (data.ret === 0) {
                } else {
                    console.warn(data.msg);
                }
            } else {
                console.warn(error);
            }
        });
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        this.refreshEvent.remove();
        this.saveMarkProfile.remove();
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
        if (!this.state.loaded) {
            this.requestData();
        }
    };

    /**
     * 接收圈子购买成功事件
     */
    receivePurchaseSuccess() {
        this.setState({
            permission: Constants.CIRCLE_IDENTITY_TYPE.SUBSCRIBER,
            isSubscribe: Constants.HAS_SUBSCRIBE.YES,
            expireDate: this.updateSubscribeExprieDate(),
        });
    }

    /**
     * 根据请求返回结果初始化页面数据
     * @param data
     */
    initPage(data) {
        this.setState({
            loaded: true,
            nickName: data.obj.nickName ? data.obj.nickName : '未设置',
            permission: data.obj.permission,
            listName: data.obj.listName,
            listType: data.obj.listType,
            description: data.obj.description,
            subscribeNum: data.obj.subscribeNum,
            totalRevenue: data.obj.totalRevenue,
            dueRevenue: data.obj.dueRevenue,
            weeklySubscribe: data.obj.weeklySubscribe,
            pushSwitch: data.obj.pushSwitch === Constants.SWITCH.ON,
            payType: data.obj.payType,
            payPrice: data.obj.payPrice,
            expireDate: data.obj.expireDate ? data.obj.expireDate : '永久',
            members: data.members,
            creator: {
                openid: data.obj.creator.openid,
                nickName: data.obj.creator.nickName,
                iconUrl: data.obj.creator.iconUrl,
            },
            distributionType: data.obj.distributionType,
            isSubscribe: data.obj.isSubscribe,
            isPrivate: data.obj.isPrivate,
            imgUrl: data.obj.imgUrl,
        });
    }

    /**
     * 设置圈子加入方式
     * @param payType
     * @returns {*}
     */
    setJoinType(payType) {
        if (this.state.isPrivate === Constants.IS_PRIVATE.YES) {
            return '私密';
        }
        if (payType === Constants.PAY_TYPE.FREE) {
            return '免费';
        } else if (payType === Constants.PAY_TYPE.MONTH) {
            return `${this.state.payPrice}阅读币/月`;
        } else if (payType === Constants.PAY_TYPE.YEAR) {
            return `${this.state.payPrice}阅读币/年`;
        } else if (payType === Constants.PAY_TYPE.PERMANENT) {
            return `${this.state.payPrice}阅读币/永久`;
        }
        return '';
    }

    updateSubscribeExprieDate() {
        if (this.state.payType === Constants.PAY_TYPE.MONTH) {
            return getNextMonth();
        } else if (this.state.payType === Constants.PAY_TYPE.YEAR) {
            return getNextYear();
        } else {
            return '永久';
        }
    }

    /**
     * 请求网络数据初始化页面
     */
    requestData = () => {
        if (!this.params || !this.params.listId) return;
        if (this.state.isNetworkAvailable) {
            const res = {
                openid: this.state.openid,
                listId: this.params.listId,
            };
            HttpUtils.doPost(APIService.getListingDetail, res).then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.initPage(data);
                    } else {
                        console.warn(data.msg);
                    }
                } else {
                    console.warn(error);
                }
            });
        }
    };

    /**
     * 提交修改昵称
     */
    updateNickName() {
        if (this.state.isNetworkAvailable) {
            let nick=this.editNickNameDialog.getInputText();
            if (!Constants.NAME_REGEX.test(this.state.nick)) {
                this.toast.show('名称应为中英文、数字和下划线', DURATION.LENGTH_LONG);
                return;
            } else if (getStringLen(nick) < 4 || getStringLen(nick) > 16) {
                this.toast.show('名称应为2-8个汉字或4-16个字母', DURATION.LENGTH_LONG);
                return;
            }
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
                nickName: nick,
            };
            HttpUtils.doPost(APIService.updateNickName, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.setState({nickName: params.nickName});
                        this.toast.show('在圈子昵称修改成功!', DURATION.LENGTH_SHORT);
                        let tempMembers = this.state.members;
                        for (let index = 0; index < tempMembers.length; index++) {
                            if (tempMembers[index].openid === this.state.openid) {
                                tempMembers[index].nickName = params.nickName;
                                break;
                            }
                        }
                        this.setState({members: tempMembers});
                    } else {
                        this.toast.show('在圈子昵称修改失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    console.warn(error);
                    this.toast.show('在圈子昵称修改失败：' + error, DURATION.LENGTH_SHORT);
                }
                this.editNickNameDialog.popupDialog.dismiss();
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }


    /**
     * 提交开关状态
     */
    updatePushSwitch(value) {
        if (this.state.isNetworkAvailable) {
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
                pushSwitch: value ? '1' : '0',
            };
            HttpUtils.doPost(APIService.changePushSwitch, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.setState({pushSwitch: value});
                        this.toast.show('修改成功', DURATION.LENGTH_SHORT);
                        CommonModule.sendUpdateCircleInfoEvent();
                    } else {
                        this.toast.show('修改失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('修改失败：' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }


    /**
     * 提交订阅圈子请求
     */
    postSubscribeRequest() {
        if (this.state.isNetworkAvailable) {
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
            };
            HttpUtils.doPost(APIService.subscribeMarkList, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.toast.show('订阅成功', DURATION.LENGTH_SHORT);
                        this.setState({
                            permission: Constants.CIRCLE_IDENTITY_TYPE.SUBSCRIBER,
                            isSubscribe: Constants.HAS_SUBSCRIBE.YES,
                        });
                        CommonModule.sendUpdateCircleInfoEvent(); //通知原生刷新圈子/清单以及首页
                    } else {
                        this.toast.show('订阅失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('订阅失败：' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 删除/退出圈子请求
     */
    postQuitRequest() {
        if (this.state.isNetworkAvailable) {
            const isCreator = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER
            const uri = isCreator ? APIService.deleteMarkList : APIService.unSubscribeMarkList;
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
            };
            HttpUtils.doPost(uri, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
                    this.deleteConfirmDialog.popupDialog.dismiss();
                } else {
                    this.unSubscribeConfirmDialog.popupDialog.dismiss();
                }
                // if (this.unSubscribeConfirmDialog.popupDialog.dialog.state.dialogState === 'opended') {
                //     this.unSubscribeConfirmDialog.popupDialog.dismiss();
                // }
                // if (this.deleteConfirmDialog.popupDialog.dialog.state.dialogState === 'opended') {
                //     this.deleteConfirmDialog.popupDialog.dismiss();
                // }
                if (data) {
                    if (data.ret === 0) {
                        //如果是圈主，则同时发送原生通知事件，圈子已删除,回退时回到正确的上一级,否则回退到圈子首页
                        if (isCreator) {
                            CommonModule.sendDeleteCircleEvent({isCreator: true});
                        } else {
                            CommonModule.sendDeleteCircleEvent({isCreator: false});
                        }
                        //更新RN缓存并刷新MinePage
                        UserInfoUtils.updateMineInfoCache(
                            Constants.UPDATE_MINEINFO_TYPE.DELETE_CIRCLE,
                            this.params.listId);
                        CommonModule.goBack();
                    } else {
                        this.setState({quitFailReason: data.msg});
                        this.alertDialog.alertDialog.show();
                    }
                } else {
                    this.setState({quitFailReason: data.msg});
                    this.alertDialog.alertDialog.show();
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 判断退出按钮显示内容
     * @returns {string}
     */
    judgeQuitBtnText() {
        if (this.state.permission !== undefined) {
            if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
                return '删除圈子';
            } else if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.MEMBER) {
                return '退出圈子';
            } else {
                return '取消订阅';
            }
        } else {
            if (this.state.payType === Constants.PAY_TYPE.FREE) {
                return '订阅圈子';
            } else {
                return `立即购买  ${this.setJoinType(this.state.payType)}`;
            }
        }
    }

    _handleItemClick(position){
        InteractionManager.runAfterInteractions(() => {
            switch (position){
                case 0:
                    this.props.navigation.navigate('TotalSubscriptPage',
                        {
                            openid:this.state.openid,
                            listId:this.state.listId,
                        });
                    break;
            }
        });
    }

    renderSubscribeLayoutAndIncome() {
        const {navigate} = this.props.navigation;
        return (
            <View>
                <View style={styles.subscribeContainer}>
                    <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity} style={styles.subscribeItem}>
                        <View style={styles.subscribeItem}>
                            <Text style={styles.subscribeCount}>{this.state.subscribeNum}</Text>
                            <Text style={styles.increaseTipText}>累计订阅人数</Text>
                        </View>
                    </TouchableOpacity>
                    <View style={{width: 1, height: 58, backgroundColor: '#F5F5F5'}}/>
                    <View style={styles.subscribeItem}>
                        <Text style={styles.subscribeCount}>{this.state.weeklySubscribe}</Text>
                        <Text style={styles.increaseTipText}>新增订阅</Text>
                    </View>
                </View>
                <DividingLine/>
                <CommonContentItem
                    item={{
                        title: '累计收入 (圈主和成员可见)',
                        content: `¥ ${this.state.totalRevenue !== 0 ? this.state.totalRevenue / 100.0 : 0}`
                    }}
                    onClick={() => {
                        navigate('IncomePage', {
                            openid: this.state.openid,
                            listId: this.params.listId,
                            listType: this.state.listType,
                            totalRevenue: this.state.totalRevenue,
                            dueRevenue: this.state.dueRevenue,
                            distributionType: this.state.distributionType,
                            callback: (data) => {
                                this.setState(data);
                            },
                        });
                    }}
                />
            </View>
        );
    }

    renderCircleMemberFooter() {
        const canShowInvite = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        return (
            canShowInvite ?
                <View style={styles.circleInviteLayout}>
                    <TouchableOpacity
                        activeOpacity={theme.btnActiveOpacity}
                        style={styles.circleInviteItem}
                        onPress={() => {
                            RNShareModule.showShareDialog({
                                nickName: this.state.creator.nickName,
                                listId: this.params.listId,
                                listName: this.state.listName,
                                imgUrl: this.state.imgUrl,
                            });
                        }}
                    >
                        <View style={styles.circleInviteItem}>
                            <Image style={styles.invitePeopleImg} source={require('../image/icon_add_people.png')}/>
                            <Text style={styles.circleInviteText}>邀请成员</Text>
                        </View>
                    </TouchableOpacity>
                </View> : null
        );
    }

    renderCircleMemberLayout() {
        return (
            <View style={styles.circleMemberLayout}>
                <View style={styles.circleMemberHeader}>
                    <Text style={styles.circleMemberTitle}>成员贡献排名</Text>
                    <TouchableOpacity
                        activeOpacity={theme.btnActiveOpacity}
                        style={styles.circleShowMoreLayout}
                        onPress={() => {
                            this.props.navigation.navigate('CircleMemberPage', {
                                openid: this.state.openid,
                                nickName: this.state.creator.nickName,
                                listId: this.params.listId,
                                listName: this.state.listName,
                                imgUrl: this.state.imgUrl,
                                isCreator: this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER,
                            });
                        }}
                    >
                        <View style={styles.circleShowMoreLayout}>
                            <Text style={styles.circleMemberTitle}>查看全部</Text>
                            <Image style={styles.circleMemberShowAll} source={require('../image/icon_show_all.png')}/>
                        </View>
                    </TouchableOpacity>
                </View>
                {
                    this.state.members.map(
                        (item, index) => {
                            return (
                                <CircleMemberItem
                                    key={index}
                                    rank={index + 1}
                                    avatar={{
                                        width: px2dp(30),
                                        height: px2dp(30),
                                        borderRadius: px2dp(30) / 2,
                                    }}
                                    circleMember={item}
                                    onItemClick={() => {
                                        IntentFromJsModule.openPageFromJS('kanjian://RNApp/followPage?otherOpenid=' + item.openid);
                                    }}
                                />
                            );
                        }
                    )
                }
                {this.renderCircleMemberFooter()}
            </View>
        );
    }

    /**
     * 渲染圈子基本信息
     */
    renderCircleBasicInfo() {
        const isOwner = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        return (
            <View style={styles.circleBasicInfoContainer}>
                <CommonContentItem
                    item={{
                        title: '圈子名称',
                        content: `${this.state.listName}`
                    }}
                    clickable={isOwner}
                    rightArrowShow={isOwner}
                    onClick={() => {
                        const {navigate} = this.props.navigation;
                        navigate('EditCircleNamePage', {
                            openid: this.state.openid,
                            listId: this.params.listId,
                            listName: this.state.listName,
                            listType: Constants.LIST_TYPE.CIRCLE,
                            callback: (data) => {
                                if (data) this.setState(data);
                            },
                        });
                    }}
                />
                <DividingLine/>
                <TouchableOpacity
                    activeOpacity={theme.btnActiveOpacity}
                    style={styles.touchableLayout}
                    onPress={() => {
                        let description = this.state.description ? this.state.description : '';
                        if (isOwner) {
                            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?listType=1&isEditArticle=0&markContent=" + description);
                        } else {
                            NativeModules.IntentFromJsModule.openPageFromJS('kanjian://MainApp/webPage?title=圈子介绍&url=' + description + '&isLoadContent=true');
                        }
                    }}
                >
                    <View style={{flexDirection: 'row'}}>
                        <Text style={styles.circleIntroduceTipText}>圈子介绍</Text>
                        <View style={styles.rightLayout}>
                            <View style={styles.touchableLayout}>
                                <Text style={styles.content}>{isOwner ? '编辑' : '查看'}</Text>
                                <Image
                                    style={styles.rightArrowImg}
                                    source={require('../image/more_icon.png')}
                                />
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
                <DividingLine/>
                {isOwner ?
                    null :
                    <CustomCommonItem
                        title="圈主"
                        onClick={() => {
                            IntentFromJsModule.openPageFromJS('kanjian://RNApp/followPage?otherOpenid=' + this.state.creator.openid);
                        }}
                        renderRight={() => {
                            return (
                                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                                    <CCCImage
                                        isRound
                                        placeholderSource={require('../image/default_header_img.png')}
                                        placeholderErrorSource={require('../image/default_header_img.png')}
                                        style={styles.circleInfoImg}
                                        source={{uri: this.state.creator.iconUrl}}
                                    />
                                    <Text style={styles.circleInfoText}>
                                        {this.state.creator.nickName}
                                    </Text>
                                    <Image
                                        style={[styles.rightArrowImg, {marginRight: 0}]}
                                        source={require('../image/more_icon.png')}
                                    />
                                </View>
                            );
                        }}
                    />
                }

            </View>
        );
    }


    /**
     * 渲染消息接收开关
     */
    renderMessageSwitch() {
        return (
            <CustomCommonItem
                style={styles.messageSwitchLayout}
                title={'接收消息通知'}
                clickable={false}
                renderRight={() => {
                    return (
                        <CCCSwitch
                            on={this.state.pushSwitch}
                            onValueChange={(value) => {
                                this.updatePushSwitch(value);
                            }}
                        />
                    );
                }}
            />
        );
    }

    renderShareItem() {
        return (
            <CustomCommonItem
                title={'分享圈子'}
                onClick={() => {
                    NativeModules.UxSDKModule.trackCustomKVEvent('listCircle_information_share_click');
                    IntentFromJsModule.openPageFromJS('kanjian://MainApp/commonSharePage?title=分享圈子&url=' +
                        APIService.HTTP_BASE_URL + APIService.shareCircleURL + this.params.listId + '&typeId=' + this.params.listId + '&QrCodeType=3' + '&listId=' + this.params.listId);
                }}
                renderRight={() => {
                    return (
                        <View style={styles.touchableLayout}>
                            <Image
                                style={styles.qrcodeImage}
                                source={require('../image/my_qrcode.png')}
                            />
                            <Image
                                style={[styles.rightArrowImg, {marginRight: 0}]}
                                source={require('../image/more_icon.png')}
                            />
                        </View>
                    );
                }}
            />
        );
    }

    /**
     * 渲染圈主可见选项
     */
    renderOwnerOptions() {
        const {navigate} = this.props.navigation;
        return (
            <View style={styles.otherLayout}>
                <CommonContentItem
                    item={{
                        title: '我在本圈子的昵称',
                        content: `${this.state.nickName}`
                    }}
                    onClick={() => {
                        this.editNickNameDialog.popupDialog.show();
                    }}
                />
                {this.renderMessageSwitch()}
                <CommonContentItem
                    item={{
                        title: '加入方式',
                        content: this.setJoinType(this.state.payType)
                    }}
                    onClick={() => {
                        navigate('JoinSettingPage', {
                            listName:this.state.listName,
                            subscribeNum :this.state.subscribeNum,
                            openid: this.state.openid,
                            listId: this.params.listId,
                            payType: this.state.payType,
                            payPrice: this.state.payPrice,
                            listType: Constants.LIST_TYPE.CIRCLE,
                            isPrivate: this.state.isPrivate,
                            callback: (data) => {
                                if (data) this.setState(data);
                            }
                        });
                    }}
                />
                <DividingLine/>
                {this.renderShareItem()}
            </View>
        );
    }


    /**
     * 渲染成员可见选项
     */
    renderMemberOptions() {
        return (
            <View >
                {this.renderMessageSwitch()}
                <CommonContentItem
                    item={{
                        title: '我在本圈子的昵称',
                        content: `${this.state.nickName}`
                    }}
                    onClick={() => {
                        this.editNickNameDialog.popupDialog.show();
                    }}
                />
                <DividingLine/>
                <CommonContentItem
                    item={{
                        title: '加入方式',
                        content: this.setJoinType(this.state.payType)
                    }}
                    onClick={() => {
                    }}
                />
                <DividingLine/>
                {this.renderShareItem()}
            </View>
        );
    }

    /**
     * 渲染订阅者可见选项
     */
    renderSubscriberOptions() {
        return (
            <View >
                {this.renderMessageSwitch()}
                {
                    this.state.payType !== Constants.PAY_TYPE.FREE ? <CommonContentItem
                        item={{
                            title: '付费有效期至',
                            content: this.state.expireDate === '永久' ? this.state.expireDate : `${dateFormat(this.state.expireDate)}`
                        }}
                        onClick={() => {
                        }}
                    /> : null
                }
                <DividingLine/>
                {this.renderShareItem()}
            </View>
        );
    }

    renderOptions() {
        if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
            return this.renderOwnerOptions();
        } else if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.MEMBER) {
            return this.renderMemberOptions();
        } else if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.SUBSCRIBER) {
            return this.renderSubscriberOptions();
        } else {
            return this.renderShareItem();
        }
    }

    renderQuitButton() {
        const isCreator = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        return (
            <TouchableOpacity
                activeOpacity={theme.btnActiveOpacity}
                style={styles.quitButton}
                onPress={() => {
                    if (this.state.isLogin) {
                        if (this.state.isSubscribe === Constants.HAS_SUBSCRIBE.YES) {
                            if (isCreator) {
                                this.deleteConfirmDialog.popupDialog.show();
                            } else {
                                this.unSubscribeConfirmDialog.popupDialog.show();
                            }
                        } else {
                            if (this.state.payType === Constants.PAY_TYPE.FREE) {//免费
                                this.postSubscribeRequest();
                            } else {
                                //需要付费则调用支付
                                CommonModule.showPurchaseBottomDialog(this.params.listId, this.state.listType + '',
                                    this.state.listName, this.state.imgUrl, this.state.payPrice + '', '', '0', '1');
                            }
                        }
                    } else {
                        IntentFromJsModule.openPageFromJS('kanjian://MainApp/loginPage?to=kanjian://RNApp/circlePage');
                    }
                }}
            >
                <Text style={styles.quitButtonText}>
                    {this.judgeQuitBtnText()}
                </Text>
            </TouchableOpacity>
        );
    }

    /**
     * 渲染编辑圈子昵称对话框
     */
    renderEditNickNameDialog() {
        if (this.state.nickName) {
            return (
                <DialogInput
                    ref={(ref) => {
                        this.editNickNameDialog = ref;
                    }}
                    contentLength={50}
                    content={this.state.nickName === '未设置' ? '' : this.state.nickName}
                    title="编辑我在本圈子的昵称"
                    onConfirm={() => {
                        Keyboard.dismiss();
                        this.updateNickName();
                    }}
                />
            );
        }
        return null;
    }

    /**
     * 渲染提醒话框
     */
    renderAlertDialog() {
        return (
            <DialogAlert
                ref={(ref) => {
                    this.alertDialog = ref;
                }}
                title="暂不能退出圈子"
                subTitle={this.state.quitFailReason}
                onConfirm={() => this.alertDialog.alertDialog.dismiss()}
            />
        );
    }

    /**
     * 二次确认是否删除圈子对话框
     */
    renderConfirmDeleteDialog() {
        if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
            return (
                <DialogConfirm
                    ref={(ref) => {
                        this.deleteConfirmDialog = ref;
                    }}
                    content="确认删除该圈子吗？"
                    onConfirm={() => {
                        this.postQuitRequest();
                    }}
                />
            );
        }
        return null;
    }

    /**
     * 二次确认是否退出圈子对话框
     */
    renderConfirmDialog() {
        if (this.state.permission !== Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
            let content;
            if (this.state.payType !== Constants.PAY_TYPE.FREE) {
                content = '取消付费订阅后，再次订阅需重新付费，确定要取消订阅吗？';
            } else {
                content = '确认退订该圈子吗？';
            }
            return (
                <DialogMessageConfirm
                    ref={(ref) => {
                        this.unSubscribeConfirmDialog = ref;
                    }}
                    content="温馨提示"
                    message={content}
                    onConfirm={() => {
                        this.postQuitRequest();
                    }}
                />
            );
        }
        return null;
    }

    render() {
        const isOwner = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        const canShowData = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER ||
            this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.MEMBER;
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'圈子信息'}
                    onBack={() => {
                        CommonModule.goBack();
                    }}
                    clickable={isOwner}
                    showRightButton={isOwner}
                    renderRight={isOwner}
                    onRight={() => {
                        IntentFromJsModule.openPageFromJS('kanjian://MainApp/webPage?title=圈子运营规则&url=' + APIService.HTTP_BASE_URL + APIService.circleManageRule);
                    }}
                />
                { this.state.loaded ?
                    <ScrollView>
                        <View style={styles.infoContainer}>
                            {canShowData ? this.renderSubscribeLayoutAndIncome() : null}
                            {this.renderCircleMemberLayout()}
                            {this.renderCircleBasicInfo()}
                            {this.renderOptions()}
                            {this.renderQuitButton()}
                        </View>
                    </ScrollView>
                    :
                    this.state.isNetworkAvailable ?
                        <FirstLoadingView/> :
                        <NetworkErrorView onPress={() => {
                            if (this.state.isNetworkAvailable) {
                                this.requestData();
                            } else {
                                this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
                            }
                        }}
                        />
                }
                {this.renderEditNickNameDialog()}
                {this.renderAlertDialog()}
                {this.renderConfirmDialog()}
                {this.renderConfirmDeleteDialog()}
                <Toast ref={(ref) => this.toast = ref}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f2f2f2',
    },
    infoContainer: {
        flex: 1,
        paddingBottom: 15,
    },
    subscribeContainer: {
        height: px2dp(122),
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    subscribeItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    subscribeTitle: {
        fontSize: 14,
    },
    subscribeCount: {
        marginTop: 10,
        fontSize: px2dp(28),
        color: '#FF5252',
    },
    rightArrowImg: {
        width: px2dp(16),
        height: px2dp(16),
        resizeMode: 'contain',
        marginLeft: px2dp(6),
        marginRight: px2dp(15),
    },
    circleInviteText: {
        fontSize: px2dp(16),
        color: '#879DAC',
        marginLeft: px2dp(6),
    },
    circleMemberLayout: {
        marginTop: px2dp(15),
        backgroundColor: 'white',
    },
    circleMemberHeader: {
        paddingTop: px2dp(18),
        paddingLeft: px2dp(15),
        flexDirection: 'row',
    },
    circleMemberTitle: {
        fontSize: px2dp(14),
        color: '#999999',
    },
    circleMemberShowAll: {
        width: px2dp(17),
        height: px2dp(17),
        marginLeft: px2dp(6),
        marginRight: px2dp(15),
    },
    circleInviteLayout: {
        height: 56,
        flexDirection: 'row',
        width: ScreenUtils.width,
        backgroundColor: 'white',
        alignItems: 'center',
    },
    circleShowMoreLayout: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    circleInviteItem: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    otherLayout: {
        marginTop: px2dp(15),
    },
    quitButton: {
        height: 56,
        width: ScreenUtils.width,
        backgroundColor: 'white',
        marginTop: 15,
        justifyContent: 'center',
        alignItems: 'center',
    },
    quitButtonText: {
        color: '#FF5252',
        fontSize: px2dp(16),
    },
    circleBasicInfoContainer: {
        backgroundColor: 'white',
        marginTop: px2dp(15),
    },
    circleIntroduceTipText: {
        paddingLeft: px2dp(15),
        paddingTop: px2dp(17),
        fontSize: px2dp(16),
        color: '#444444',
    },
    circleIntroduceText: {
        paddingTop: px2dp(12),
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        paddingBottom: px2dp(18),
    },
    circleIntroduceText2: {
        fontSize: px2dp(16),
        color: '#999999',
        marginLeft: px2dp(15),
        paddingBottom: px2dp(18),
    },
    increaseTipText: {
        fontSize: px2dp(12),
        color: '#A9A9A9',
    },
    messageSwitchLayout: {
        marginTop: px2dp(15),
        marginBottom: px2dp(15),
    },
    touchableLayout: {
        height: px2dp(56),
        flexDirection: 'row',
        alignItems: 'center',
    },
    qrcodeImage: {
        width: px2dp(20),
        height: px2dp(20),
    },
    circleOwnerItem: {
        flexDirection: 'row',
    },
    circleInfoText: {
        marginLeft: px2dp(7),
        fontSize: px2dp(14),
        marginRight: px2dp(9),
    },
    circleInfoImg: {
        width: px2dp(30),
        height: px2dp(30),
        borderRadius: px2dp(30) / 2,
    },
    invitePeopleImg: {
        width: px2dp(16),
        height: px2dp(16),
    },
    rightLayout: {
        flex: 1,
        height: px2dp(56),
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    content: {
        fontSize: px2dp(14),
        color: '#999999'
    },
    p: {
        fontSize: px2dp(16),
        color: '#999999',
    },
});
/**
 * 圈子成员页面
 * Created by lizhj on 2017/8/21.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Text,
    Image,
    TouchableOpacity,
    NativeModules,
    NetInfo,
    Platform
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import CCCFlatList from '../component/CCCFlatList';
import CommonHeader from '../component/CommonHeader';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import DividingLine from '../component/DividingLine';
import HttpUtils from '../utils/HttpUtils';
import APIService from '../config/APIService';
import CircleMemberItem2 from '../component/CircleMemberItem2';
import DialogConfirm from '../component/DialogConfirm';

const PAGE_SIZE = 10;
const {CommonModule, IntentFromJsModule, RNShareModule} = NativeModules;
export default class CircleMemberPage extends Component {
    constructor(props) {
        super(props);
        const {openid, nickName, listId, listName, imgUrl, isCreator, backToNative} = this.props.navigation.state.params;
        this.state = {
            openid,
            listId,
            nickName,
            listName,
            imgUrl,
            isCreator,
            backToNative,
            index: -1,
            isNetworkAvailable: true,
            loaded: false,
        };
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
        if (!this.state.loaded && isConnected) {
            this.memberList.refresh();
        }
    };

    onFetch = async (page = 1, startFetch, abortFetch) => {
        this.requestParams = {
            openid: this.state.openid,
            listId: this.state.listId,
            pageNo: page + '',
            pageSize: PAGE_SIZE + ''
        };
        HttpUtils.doPost(APIService.getCircleMemberList, this.requestParams)
            .then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.setState({loaded: true});
                        startFetch(data.list, PAGE_SIZE);
                        this.setDataSource(data.list);
                    } else {
                        this.toast.show(data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('获取成员数据失败:' + error, DURATION.LENGTH_SHORT);
                    abortFetch();
                }
            });
    };

    setDataSource(data = []) {
        if (!this.dataSource) this.dataSource = data;
        this.dataSource.concat(data);
    }


    /**
     * 提交要删除的成员数据
     */
    postDeleteData(index) {
        const params = {
            openid: this.state.openid,
            listId: this.state.listId,
            targetOpenid: this.dataSource[index].openid,
        };
        HttpUtils.doPost(APIService.deleteMember, params)
            .then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.memberList.deleteAndUpdateDataSource(index);
                        this.toast.show('移除成功', DURATION.LENGTH_SHORT);

                    } else {
                        this.toast.show('移除失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    console.warn(error);
                    this.toast.show('移除失败', DURATION.LENGTH_SHORT);
                }
                this.confirmDialog.popupDialog.dismiss();
            });
    }

    /**
     * 邀请成员按钮
     * @returns {XML}
     */
    renderInviteButton = () => {
        if (this.state.isCreator) {
            return (
                <View style={styles.circleInviteLayout}>
                    <TouchableOpacity
                        activeOpacity={theme.btnActiveOpacity}
                        style={styles.circleInviteItem}
                        onPress={() => {
                            RNShareModule.showShareDialog({
                                nickName: this.state.nickName,
                                listId: this.state.listId,
                                listName: this.state.listName,
                                imgUrl: this.state.imgUrl,
                            });
                        }}
                    >
                        <View style={styles.circleInviteItem}>
                            <Image style={styles.invitePeopleImg} source={require('../image/icon_add_people.png')}/>
                            <Text style={styles.circleInviteText}>邀请成员</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        }
        return null;
    };

    /**
     * 渲染FlatList 的单个item
     * @param item
     * @returns {XML}
     * @private
     */
    renderItemComponent = (item, index) => {
        return (
            <CircleMemberItem2
                showDelete={this.state.isCreator}
                deletePress={() => {
                   this.setState({index});
                    this.confirmDialog.popupDialog.show();
                }}
                onItemClick={() => {

                    IntentFromJsModule.openPageFromJS('kanjian://RNApp/followPage?otherOpenid=' + item.openid);
                }}
                rank={index + 1}
                circleMember={item}
            />
        );
    };

    renderConfirmDialog() {
        return (
            <DialogConfirm
                ref={(ref) => {
                    this.confirmDialog = ref;
                }}
                content="确定将该成员删除吗？"
                onConfirm={() => {
                    this.postDeleteData(this.state.index);
                }}
            />
        );
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'圈子成员'}
                    onBack={() => {
                        if (this.state.backToNative) {//从原生跳转过来返回则直接回到原生
                            CommonModule.goBack();
                        } else {
                            this.props.navigation.goBack();
                        }
                    }}
                />
                <DividingLine/>
                <CCCFlatList
                    ref={(ref) => this.memberList = ref}
                    onFetch={this.onFetch}
                    item={this.renderItemComponent}
                    paginationAllLoadedView={this.renderInviteButton}
                />
                <Toast ref={(ref) => this.toast = ref}/>
                {this.renderConfirmDialog()}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f1f1f1',
    },
    circleInviteLayout: {
        marginTop: px2dp(15),
        marginBottom: px2dp(32),
        height: 56,
        flexDirection: 'row',
        width: ScreenUtils.width,
        backgroundColor: 'white',
        alignItems: 'center',
    },
    circleInviteItem: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    invitePeopleImg: {
        width: px2dp(16),
        height: px2dp(16),
    },
    circleInviteText: {
        fontSize: px2dp(16),
        color: '#879DAC',
        marginLeft: px2dp(6),
    },
});
/**
 * 可用优惠券页面
 * Created by lizhj on 2017/10/9.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    InteractionManager,
    NativeModules,
    NetInfo,
    Platform,
    Linking,
    TouchableOpacity,
    Image,
    Text,
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import CCCFlatList from '../component/CCCFlatList';
import DividingLine from '../component/DividingLine';
import HttpUtils from '../utils/HttpUtils';
import URLUtils from '../utils/URLUtils';
import APIService from '../config/APIService';
import DiscountItem from '../component/DiscountItem';
import FirstLoadingView from '../component/FirstLoadingView';
import EmptyView from '../component/EmptyView';
import theme from '../utils/theme';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';

const PAGE_SIZE = 10;
const {CommonModule,IntentFromJsModule} = NativeModules;
export default class DiscountPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loaded: false,
            openid: this.props.openid,
            listId: this.props.listId,
            listType: this.props.listType,
            isNetworkAvailable: true,
            from: this.props.from,
        };
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            Linking.getInitialURL().then((url) => {
                const result = URLUtils.parseQueryString(url);
                InteractionManager.runAfterInteractions(() => {
                    this.setState({
                        loaded: true,
                        listId: result.listId,
                        listType: result.listType,
                        from: result.from,
                    });
                });
            }).catch(err => console.error('An error occurred', err));
        }else{
            InteractionManager.runAfterInteractions(() => {
                this.setState({loaded: true});
            });
        }
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
        if (this.discountList && isConnected) {
            this.discountList.refresh();
        }
    };

    onFetch = async (page = 1, startFetch, abortFetch) => {
        let url;
        if (this.state.listId) {//获取可用优惠券
            url = APIService.getDiscountList
            this.requestParams = {
                openid: this.state.openid,
                listId: this.state.listId,
                pageNo: page + '',
                pageSize: PAGE_SIZE + ''
            };
        } else { //获取全部优惠券
            url = APIService.getAllDiscount;
            this.requestParams = {
                openid: this.state.openid,
                pageNo: page + '',
                pageSize: PAGE_SIZE + ''
            };
        }

        HttpUtils.doPost(url, this.requestParams)
            .then(({data}) => {
                if (data) {
                    if (data.ret === 0) {
                        startFetch(data.cards, PAGE_SIZE);
                        this.setDataSource(data.cards);
                    } else {
                        this.toast.show(data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('获取数据失败', DURATION.LENGTH_SHORT);
                    abortFetch();
                }
            });
    };

    setDataSource(data = []) {
        if (!this.dataSource) this.dataSource = data;
        this.dataSource.concat(data);
    }


    /**
     * 渲染FlatList 的单个item
     * @param item
     * @returns {XML}
     * @private
     */
    renderItemComponent = (item) => {
        return (
            <DiscountItem
                cardName={item.cardName}
                cardValue={item.cardValue}
                validEndTime={item.validEndTime}
                discountSelected={() => {
                    if (!this.state.listId)return;
                    CommonModule.goBack();
                    CommonModule.showPurchaseBottomDialog(this.state.listId, this.state.listType + '', '', '', '0', item.cardId, item.cardValue + '', this.state.from + '');
                }}
            />
        );
    };

    /**
     * 自定义列表为空显示的视图
     */
    renderEmptyView = () => {
        return <EmptyView tips="暂无可用阅读券"/>;
    };

    renderCustomHeader() {
        return (
            <View style={styles.headerContainer}>
                <TouchableOpacity
                    style={styles.leftTouchableArea}
                    activeOpacity={theme.btnActiveOpacity}
                    onPress={() => {
                        if (Platform.OS === 'ios') {
                            CommonModule.showPurchaseBottomDialog(this.state.listId, this.state.listType + '',
                                '', '', '', '', '0', this.state.from + '');
                        }
                        CommonModule.goBack();
                    }}
                >
                    <Image
                        style={styles.backImg}
                        source={require('../image/icon_back.png')}
                    />
                </TouchableOpacity>
                <Text style={styles.titleText}>{'阅读券'}</Text>
                <TouchableOpacity
                    style={styles.rightTouchableArea}
                    activeOpacity={theme.btnActiveOpacity}
                    onPress={() => {
                        IntentFromJsModule.openPageFromJS('kanjian://MainApp/webPage?title=使用规则&url='+APIService.HTTP_BASE_URL+APIService.discountUseRule);
                    }}
                >
                    <Text style={styles.rightText}>使用规则</Text>
                </TouchableOpacity>
            </View>
        );
    }

    render() {
        return (
            <View style={styles.container}>
                {this.renderCustomHeader()}
                <DividingLine/>
                {this.state.loaded ?
                    <CCCFlatList
                        ref={(ref) => this.discountList = ref}
                        onFetch={this.onFetch}
                        item={this.renderItemComponent}
                        paginationAllLoadedView={this.renderInviteButton}
                        emptyView={this.renderEmptyView}
                        hasAllLoadedTips={false}
                    />
                    :<FirstLoadingView/>
                }
                <Toast ref={(ref) => this.toast = ref}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor,
    },
    headerContainer: {
        backgroundColor: 'white',
        flexDirection: 'row',
        height: theme.actionBar.height,
        width: ScreenUtils.width,
        alignItems: 'center',
        paddingTop: (Platform.OS === 'ios' ? px2dp(20) : 0),
    },
    leftTouchableArea: {
        paddingLeft: px2dp(15),
        height: px2dp(44),
        width: 40,
        justifyContent: 'center',
    },
    rightTouchableArea: {
        top:(Platform.OS === 'ios' ? px2dp(20) : 0),
        height: px2dp(44),
        position: 'absolute',
        right: px2dp(15),
        justifyContent: 'center',
        alignItems: 'center',
    },
    backImg: {
        width: px2dp(12),
        height: px2dp(20),
    },
    titleText: {
        width: ScreenUtils.width - 80,
        textAlign: 'center',
        fontSize: px2dp(17),
        color: '#444444',
    },
    rightText: {
        textAlign: 'center',
        color: '#FF5252',
        fontSize: px2dp(14)
    },
});
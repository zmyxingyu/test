/**
 * 草稿箱页面
 * Created by yf on 2017/8/29.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Platform,NetInfo,
    NativeEventEmitter,DeviceEventEmitter,
    TouchableOpacity,AsyncStorage,
    NativeModules,
    Image,Text
} from 'react-native';
import DividingLine from '../component/DividingLine';
import CCCFlatList from '../component/CCCFlatList';
import CommonHeader from '../component/CommonHeader';
import Constants from '../config/Constants';
import APIService from '../config/APIService';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import HttpUtils from '../utils/HttpUtils';
import DraftArticleItem from '../component/DraftArticleItem';
import Toast,{DURATION} from 'react-native-easy-toast';
const {DraftManager} = NativeModules;
const DraftManagerEmitter = new NativeEventEmitter(DraftManager);
import DialogConfirm from '../component/DialogConfirm';
import NetworkErrorView from '../component/NetworkErrorView';

const {CommonModule} = NativeModules;
export default class DraftArticlePage extends Component{

    constructor(props){
        super(props);
        this.state={
            dataBlob:[],
            firstLoader:true,
            openid:this.props.openid,
            index:-1,
            noNet:false,
            noData:false,
            deleteArticleId:'',
            deleteIndex:-1
        };
    }


    render(){
        if(this.state.openid==''){
            return(
                <View style={styles.container}>
                    <CommonHeader
                        title={'草稿'}
                        onBack={() => {
                            NativeModules.CommonModule.goBack();
                        }
                        }
                    />
                    <DividingLine/>
                    <Toast ref={'toast'}/>
                </View>
            )
        }else{
            return(
                <View style={styles.container}>
                    <CommonHeader
                        title={'草稿'}
                        onBack={() => {
                            NativeModules.CommonModule.goBack();
                        }
                        }
                    />
                    <DividingLine/>
                    {
                        this.state.noNet?
                            <NetworkErrorView  ref={'errorView'} onPress={this._handleItemClick.bind(this,1)}/>
                            :
                            (this.state.noData?
                                <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(70)}}>
                                    <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                                    <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>暂无草稿</Text>
                                    <Text style={{color: '#999', fontSize: px2dp(14),marginTop:px2dp(8)}}>让更多的好友订阅你的好文章吧</Text>
                                    <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity}
                                                      style={{justifyContent:'center',alignItems:'center'}}>
                                        <View style={{marginTop:px2dp(60),borderRadius:px2dp(4),justifyContent:'center',alignItems:'center',borderColor:'#ff5252',borderWidth:px2dp(1),height:px2dp(44),width:px2dp(138)}}>
                                            <Text style={{color: '#ff5252',textAlign:'center',fontSize: px2dp(17)}}>添加文章</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            :
                            <CCCFlatList
                                ref={(ref) => this.draftList = ref}
                                onFetch={this.onFetch.bind(this)}
                                firstLoader={this.state.firstLoader}
                                item={this.renderItemComponent.bind(this)}
                            />)
                    }
                    <Toast ref={'toast'}/>
                    {this.renderConfirmDialog()}
                </View>
            )
        }
    }

    _handleItemClick(position){
        switch (position){
            case 0:
                NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?isEditArticle=1");
                break;
            case 1:
                this.setState({noNet:false,noData:false});
                //this.draftList.refresh();
                break;
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            NetInfo.isConnected.addEventListener('change', this.handleFirstConnectivityChange);
        } else {
            NetInfo.isConnected.fetch().then((isConnected) => {
                if (!isConnected) {
                    this.setState({noNet:true});
                }else{
                    this.setState({noNet:false});
                }
            });
        }
        if (Platform.OS === 'ios') {
            this.refreshEvent = DraftManagerEmitter.addListener('saveDraft', (response) => {
                if(response.result==2 || response.result==1)
                    this.setState({noData:false});
                else if (response.result==0  && this.draftList){
                    this.draftList.refresh();
                }
            });
        }else{
            this.refreshEvent = DeviceEventEmitter.addListener('saveDraft', (response) => {
                if(response.result==2 || response.result==1)
                    this.setState({noData:false});
                else if (response.result==0 && this.draftList){
                    this.draftList.refresh();
                }
            });
        }
    }

    componentWillUnmount(){
        this.refreshEvent.remove();
    };

    renderItemComponent = (item, index) => {
        return (
            <DraftArticleItem
                ref={(ref) => this.deleteItem = ref}
                rowData={item}
                deletePress={this.deleteData.bind(this, item.id,index,1)}
                onItemClick={
                    (rowData) => {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?isEditArticle=1&draftId="+rowData.id);
                    }
                }
            />
        );
    };

    renderConfirmDialog() {
        return (
            <DialogConfirm
                ref={(ref) => {
                    this.confirmDialog = ref;
                }}
                content="确定将该草稿删除吗？"
                onConfirm={() => {
                    this.confirmDialog.popupDialog.dismiss();
                    this.postDeleteData();
                }}
            />
        )
    }

    postDeleteData(){
        let context = this;
        var url = APIService.deleteArticle;
        let par = {
            'openid' : this.state.openid,
            'flag' : "-1",
            'articleId' : this.state.deleteArticleId
        };
        NativeModules.CommonModule.showRNLoadingProgress("正在删除数据，请稍后...");
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            if(data.ret === 0){
                AsyncStorage.getItem(Constants.MINEINFO, (error, result) => {
                    if (!error) {
                        if (result !== '' && result !== null) {
                            let data = JSON.parse((result));
                            data.articles.length>0?
                                (data.articles[0].total=data.articles[0].total-1):null;
                            if(data.articles.length>0 && data.articles[0].total==0){
                                context.setState({noData:true});
                            }
                            AsyncStorage.setItem(Constants.MINEINFO, JSON.stringify(data), (error) => {
                                if (!error) {
                                    if (Platform.OS === 'ios') {
                                        CommonModule.refreshMinePage();
                                    } else {
                                        DeviceEventEmitter.emit('refreshMine');
                                    }
                                }
                            });
                        }
                    }
                })
                context.draftList.deleteAndUpdateDataSource(context.state.deleteIndex);
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    deleteData(id,index,position) {
        if(position == 0){//编辑
            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?isEditArticle=1&draftId="+id);
        }else{
            this.confirmDialog.popupDialog.show();
            this.setState({deleteArticleId:id,deleteIndex:index});
        }
    }

    handleFirstConnectivityChange=(isConnected)=>{
        if (!isConnected) {
            this.setState({noNet:true});
        }else{
            this.setState({noNet:false});
        }
        NetInfo.isConnected.removeEventListener('change', this.handleFirstConnectivityChange);
    }

    onFetch = async (page, startFetch, abortFetch) => {
        if(page>1){
            startFetch('', 20);
            return;
        }
        let par = {
            'openid' : this.state.openid,
            'flag' : "-1",
            'pageNo':page+'',
            'pageSize':"20"
        };
        if(this.state.openid !== ''){
            let context = this;
            HttpUtils.doPost(APIService.getDraftArticleList, par)
                .then(({data, error}) => {
                    if (data) {
                        if(data.list.length==0 && page == 1){
                            context.setState({noData:true});
                        }else{
                            startFetch(data.list, 20);
                        }
                    } else {
                        this.setState({noNet: true});
                        context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                        abortFetch();
                    }
                });
        }
    };

}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    circleInviteLayout: {
        marginTop: px2dp(15),
        marginBottom: px2dp(32),
        height: 56,
        flexDirection: 'row',
        width: ScreenUtils.width,
        backgroundColor: 'white',
        alignItems: 'center',
    },

    circleInviteItem: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    invitePeopleImg: {
        width: px2dp(16),
        height: px2dp(16),
    },
    circleInviteText: {
        fontSize: px2dp(16),
        color: '#879DAC',
        marginLeft: px2dp(6),
    },
});
/**
 * 修改清单圈子/清单名称页面
 * Created by lizhj on 2017/9/25.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    TextInput,
    Image,
    TouchableOpacity,
    NativeModules,
    NetInfo,
    Platform,
    Keyboard
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import CommonHeader from '../component/CommonHeader';
import px2dp from '../utils/px2dp';
import UserInfoUtils from '../utils/UserInfoUtils';
import APIService from '../config/APIService';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import getStringLen from '../utils/CommonUtils';
import theme from '../utils/theme';

const {CommonModule} = NativeModules;
export default class EditCircleNamePage extends Component {
    constructor(props) {
        super(props);
        const {openid, listId, listName, listType} = this.props.navigation.state.params;
        this.state = {
            openid,
            listId,
            listName,
            listType,
            valueChange: false,
            isNetworkAvailable: true,
        };
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
    };

    goBack = (isNeedToSave) => {
        Keyboard.dismiss();
        const {goBack, state} = this.props.navigation;
        if (isNeedToSave) {
            this.updateCircleNameRequest(goBack, state);
        } else {
            goBack();
        }
    };

    /**
     * 提交修改昵称请求
     * @param goBack
     * @param state
     */
    updateCircleNameRequest(goBack, state) {
        if (this.state.isNetworkAvailable) {
            const title = this.state.listType === Constants.LIST_TYPE.LISTING ? '清单' : '圈子';
            if (!this.state.listName || this.state.listName === '') {
                this.toast.show(`${title}名称不能为空！`, DURATION.LENGTH_SHORT);
                return;
            } else if (!Constants.NAME_REGEX.test(this.state.listName)) {
                this.toast.show('名称应为中英文、数字和下划线', DURATION.LENGTH_LONG);
                return;
            } else if (getStringLen(this.state.listName) < 4 || getStringLen(this.state.listName) > 40) {
                this.toast.show('名称应为2-20个汉字或4-40个字母', DURATION.LENGTH_LONG);
                return;
            }
            const params = {
                openid: this.state.openid,
                listId: this.state.listId,
                listName: this.state.listName,
            };
            HttpUtils.doPost(APIService.updateInfo, params, Constants.waitInfo).then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.toast.show(`${title}名称修改成功!`, DURATION.LENGTH_SHORT);
                        //提交成功，参数回传
                        state.params.callback(this.state);
                        if (this.state.listType === Constants.LIST_TYPE.CIRCLE) {
                            UserInfoUtils.updateMineInfoCache(
                                Constants.UPDATE_MINEINFO_TYPE.UPDATE_CIRCLE_NAME,
                                this.state.listId, this.state.listName);
                        } else {
                            UserInfoUtils.updateMineInfoCache(
                                Constants.UPDATE_MINEINFO_TYPE.UPDATE_LISTING_NAME,
                                this.state.listId, this.state.listName);
                        }
                        //刷新清单／圈子列表页
                        CommonModule.sendUpdateCircleInfoEvent();
                        goBack();
                    } else {
                        this.toast.show(`${title}名称修改失败：${data.msg}`, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show(`${title}名称修改失败,请稍后再试`, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    render() {
        const title = this.state.listType === Constants.LIST_TYPE.LISTING ? '清单' : '圈子';
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={`${title}名称`}
                    onBack={() => {
                        this.goBack(false);
                    }}
                    rightText={'保存'}
                    showRightButton
                    onRight={() => {
                        this.goBack(true);
                    }}
                    clickable={this.state.valueChange && this.state.listName !== ''}
                />
                <View style={{
                    flexDirection: 'row',
                    marginTop: px2dp(15),
                    paddingRight: px2dp(15),
                    backgroundColor: 'white'
                }}>
                    <TextInput
                        underlineColorAndroid={'transparent'}
                        style={styles.circleNameInput}
                        numberOfLines={1}
                        onChangeText={(text) => {
                            this.setState({listName: text, valueChange: true});
                        }}
                        value={this.state.listName}
                        placeholder={'名称（不超过20个字）'}
                    />
                    {
                        this.state.listName === null || this.state.listName === '' ? null :
                            <TouchableOpacity
                                onPress={()=>{
                                    this.setState({listName: ''});
                                }}
                                activeOpacity={theme.btnActiveOpacity}
                            >
                                <Image
                                    source={require('../image/icon_delete.png')}
                                    style={styles.clearTextIcon}
                                />
                            </TouchableOpacity>
                    }
                </View>
                <Toast ref={(ref) => this.toast = ref} position={'center'}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F1F1F1',
    },
    circleNameInput: {
        flex: 1,
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        backgroundColor: 'white',
        height: px2dp(56),
        fontSize: px2dp(16),
        color: '#444444',
    },
    clearTouchableArea: {
        width: px2dp(40),
        height: px2dp(56),
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
    },
    clearTextIcon: {
        width: 20,
        height: px2dp(56),
        backgroundColor: 'white',
        resizeMode: 'contain',
    }
});
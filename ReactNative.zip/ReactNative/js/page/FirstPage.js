/**
 * 首页
 * Created by yf on 2017/11/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    NetInfo,Text, View, StyleSheet,Image,NativeEventEmitter,RefreshControl, ListView,NativeModules,Platform,DeviceEventEmitter, PixelRatio, TouchableOpacity, InteractionManager,ScrollView,AsyncStorage
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import Toast,{DURATION} from 'react-native-easy-toast';
import Constants from '../config/Constants';
import APIService from '../config/APIService';
import HttpUtils from '../utils/HttpUtils';
import CCCImage from '../component/CCCImage';
import DividingLine from  '../component/DividingLine';
import NetworkErrorView from '../component/NetworkErrorView';
import FormatDateUtil from '../utils/FormatDateUtil';
const {MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
var oldData;//缓存的上一次数据
export default class FirstPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLogin: this.props.isLogin,
            refreshing: true,
            latestTip:null,
            noNet:false,
            total:0,
            openid:this.props.openid,
            tops: new ListView.DataSource({
                rowHasChanged: (r1, r2) => r1 !== r2
            }),
            lists: new ListView.DataSource({
                rowHasChanged: (r3, r4) => r3 !== r4
            }),
        }
    };

    _handleItemClick(position){
        switch (position){
            case 0://发现内容
                NativeModules.UxSDKModule.trackCustomKVEvent('home_findTopicsofInterest_click');
                NativeModules.CommonModule.postMainTabEvent(1);
                break;
            case 1:
                this.setState({noNet:false});
                InteractionManager.runAfterInteractions(() => {
                    this._fetchData();
                });
                break;
            case 2://发现好友
                NativeModules.UxSDKModule.trackCustomKVEvent('home_discoverFriendContent_click');
                InteractionManager.runAfterInteractions(() => {
                    if(Platform.OS === 'android'){
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/myFollowPage?listType=1");
                    }else{
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/myContactFriendPage");
                    }
                });
                break;
            case 3://查看更多
                InteractionManager.runAfterInteractions(() => {
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/homeFollowPage");
                });
                break;
        }
    }

    render() {
        if(!this.state.isLogin||(this.state.lists._cachedRowCount == 0 && !this.state.refreshing)){
            return(
                <View style={styles.container}>
                    <View style={styles.actionBar}>
                        <Text style={{
                            flex: 1,
                            color: '#444',
                            fontSize: theme.actionBar.fontSize,
                            textAlign: 'center'
                        }}>首页</Text>
                    </View>
                    <DividingLine/>
                    <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',
                        backgroundColor: theme.backgroundColor,marginTop:px2dp(70)}}>
                        <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                        <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>还没有关注内容</Text>
                        <Text style={{color: '#999', fontSize: px2dp(14),marginTop:px2dp(8)}}>通过以下方式发现你感兴趣的内容吧</Text>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity}
                                          style={{justifyContent:'center',alignItems:'center'}}>
                            <View style={{marginTop:px2dp(60),borderRadius:px2dp(4),justifyContent:'center',alignItems:'center',borderColor:'#ff5252',borderWidth:px2dp(1),height:px2dp(44),width:px2dp(138)}}>
                                <Text style={{color: '#ff5252',textAlign:'center',fontSize: px2dp(17)}}>发现内容</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,2)} activeOpacity={theme.btnActiveOpacity}
                                          style={{justifyContent:'center',alignItems:'center'}}>
                            <View style={{marginTop:px2dp(15),borderRadius:px2dp(4),justifyContent:'center',alignItems:'center',borderColor:'#ff5252',borderWidth:px2dp(1),height:px2dp(44),width:px2dp(138)}}>
                                <Text style={{color: '#ff5252',textAlign:'center',fontSize: px2dp(17)}}>发现好友</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <Toast ref={'toast'}/>
                </View>
            )
        }else{
            return (
                <View style={styles.container}>
                    <View style={styles.actionBar}>
                        <Text style={{
                            flex: 1,
                            color: '#444',
                            fontSize: theme.actionBar.fontSize,
                            textAlign: 'center'
                        }}>首页</Text>
                    </View>
                    {
                        (this.state.noNet && (!oldData || oldData==null))?
                            <NetworkErrorView ref={'errorView'} onPress={this._handleItemClick.bind(this, 1)}/>
                            :
                            <ScrollView
                                refreshControl={
                                    <RefreshControl
                                        refreshing={this.state.refreshing}
                                        onRefresh={this._onRefresh.bind(this)}
                                        colors={['red', '#ffd500', '#0080ff', '#99e600']}
                                    />
                                }>
                                {
                                    this.state.tops._cachedRowCount != 0 ?
                                        <ListView
                                            style={{marginBottom:px2dp(15)}}
                                            dataSource={this.state.tops}
                                            renderRow={this.topRenderItem.bind(this)}/> : null
                                }
                                {
                                    this.state.latestTip?
                                        <Text style={{fontSize: px2dp(14), padding: px2dp(15), color: '#444444',backgroundColor:'#fff'}}
                                              numberOfLines={1}>{this.state.latestTip}</Text>
                                        :null
                                }
                                {
                                    this.state.lists._cachedRowCount != 0 ?
                                        <ListView
                                            dataSource={this.state.lists}
                                            renderRow={this.listRenderItem.bind(this)}/> : null
                                }
                                {
                                    this.state.total>20?
                                        <TouchableOpacity onPress={this._handleItemClick.bind(this,3)} activeOpacity={theme.btnActiveOpacity}>
                                            <Text style={{fontSize: px2dp(16), padding: px2dp(15),textAlign:'center', color: '#879dac',backgroundColor:'#fff'}}
                                                  numberOfLines={1}>显示全部({this.state.total})</Text>
                                        </TouchableOpacity>: null
                                }
                            </ScrollView>
                    }
                    <Toast ref={'toast'}/>
                </View>
            )
        }
    };

    _onTopClick(item,rowId){
        item.showRedPoint = false;
        this.setState({isLogin:true});
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS(item.action);
        });
    }

    _onListClick(item,rowId){
        //解决listview列表不刷新的问题
        let newData = this.state.lists._dataBlob.s1;
        let _item = Object.assign({}, newData[rowId], {'showRedPoint': false});
        this.setState({
            lists: this.state.lists.cloneWithRows(Object.assign({}, newData, {[rowId]:_item})),
        });
        if(item.listType==0){
            InteractionManager.runAfterInteractions(() => {
                NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/inventoryListPage?listId=" + item.listId + "&listType=0");
            });
        }else{
            InteractionManager.runAfterInteractions(() => {
                NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/circleListPage?listId=" + item.listId + "&listType=1");
            });
        }
    }

    listRenderItem(item,sectionID,rowId,highlignt){
        return (
            <TouchableOpacity key={item.listName} onPress={this._onListClick.bind(this, item,rowId)}
                              activeOpacity={theme.btnActiveOpacity}>
                <View style={{flexDirection: 'column'}}>
                    <View style={styles.item}>
                        <View style={{width: px2dp(50),height: px2dp(50),paddingTop:px2dp(5),backgroundColor:'#fff'}} >
                            <CCCImage source={{uri:item.imgUrl}} style={styles.avatar} />
                            {
                                item.showRedPoint?
                                    <Image source={require('../image/redpoint.png')} style={{
                                        position: 'absolute',
                                        width: px2dp(10),
                                        marginLeft:px2dp(35),
                                        height: px2dp(10)
                                    }}/>
                                    :null
                            }
                        </View>
                        <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                            <View style={styles.midLayout}>
                                <View style={{flexDirection: 'row',justifyContent:'center',alignItems:'center'}}>
                                    <Text style={styles.nameText} numberOfLines={1}>{item.listName}</Text>
                                    {
                                        item.payType!=0?
                                            <Image source={require('../image/icon_pay.png')} style={{width:px2dp(30),height:px2dp(17),marginLeft:px2dp(6),marginRight:px2dp(30),resizeMode:'contain'}} />
                                            :null
                                    }
                                </View>
                                <Text style={styles.contributeText} numberOfLines={1}>{item.markNum+"篇，"+FormatDateUtil('MM-dd',item.lastUpdateTime)+"更新"}</Text>
                            </View>
                            <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16),marginLeft: px2dp(10),marginRight: px2dp(10)}}/>
                        </View>
                    </View>
                    <DividingLine/>
                </View>
            </TouchableOpacity>
        )
    }

    topRenderItem(item,sectionID,rowId,highlignt){
        return (
            <TouchableOpacity key={item.title} onPress={this._onTopClick.bind(this, item,rowId)}
                              activeOpacity={theme.btnActiveOpacity}>
                <View style={{flexDirection: 'column'}}>
                    <View style={styles.item}>
                        <View style={{width: px2dp(50),height: px2dp(50),paddingTop:px2dp(5)}} >
                            <CCCImage source={{uri:item.imgUrl}} style={styles.avatar} />
                            {
                                item.showRedPoint?
                                    <Image source={require('../image/redpoint.png')} style={{
                                        position: 'absolute',
                                        width: px2dp(10),
                                        marginLeft:px2dp(35),
                                        height: px2dp(10)
                                    }}/>
                                    :null
                            }
                        </View>
                        <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                            <View style={styles.midLayout}>
                                <Text style={styles.nameText} numberOfLines={1}>{item.title}</Text>
                                <Text style={styles.contributeText} numberOfLines={1}>{item.memo}</Text>
                            </View>
                            <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16),marginLeft: px2dp(10),marginRight: px2dp(10)}}/>
                        </View>
                    </View>
                    <DividingLine/>
                </View>
            </TouchableOpacity>
        )
    }

    handleFirstConnectivityChange=(isConnected)=> {
        if (!isConnected) {
            this.setState({noNet:true});
        }else{
            this.setState({noNet:false});
        }
        NetInfo.isConnected.removeEventListener('change', this.handleFirstConnectivityChange);
    }

    componentDidMount() {
        InteractionManager.runAfterInteractions(() => {
            this.asQuery(Constants.FIRSTINFO);
            this._fetchData();
        });
        if (Platform.OS === 'ios') {
            this.refreshFirstEvent = MineManagerEmitter.addListener('refreshHomeFromNet', () => {
                InteractionManager.runAfterInteractions(() => {
                    this._fetchData();
                });
            });
            this.subscription = MineManagerEmitter.addListener('loginBack', (response) => {
                this.loginBack(response);
            });
            this.logout = MineManagerEmitter.addListener('logout', () => {
                this._logout();
            });
        }else{
            this.refreshFirstEvent = DeviceEventEmitter.addListener('refreshHomeFromNet', () => {
                InteractionManager.runAfterInteractions(() => {
                    this._fetchData();
                });
            });
            this.subscription = DeviceEventEmitter.addListener('loginBack', (response) => {
                this.loginBack(response);
            });
            this.logout = DeviceEventEmitter.addListener('logout', () => {
                this._logout();
            });
        }
        if (Platform.OS === 'ios') {
            NetInfo.isConnected.addEventListener('change', this.handleFirstConnectivityChange);
        } else {
            NetInfo.isConnected.fetch().then((isConnected) => {
                if (!isConnected) {
                    this.setState({noNet:true});
                }else{
                    this.setState({noNet:false});
                }
            });
        }
    }

    componentWillUnmount() {
        this.subscription.remove();
        this.logout.remove();
        this.refreshFirstEvent.remove();
        oldData = null;
    };

    _logout() {
        AsyncStorage.setItem(Constants.FIRSTINFO, '', (error) => {
            if (!error) {
            }
        });
        oldData = null;
        this.setState({isLogin: false});
    }

    loginBack(response) {
        if (response && response.login_state == 1) {//成功
            if (response.userInfoJson) {
                let data = JSON.parse(response.userInfoJson);
                Constants.openid = data.openid;
                this.setState({isLogin: true,openid:data.openid});
            }else
                this.setState({isLogin: true});
            InteractionManager.runAfterInteractions(() => {
                this._fetchData();
            });
        } else {
            this.setState({isLogin: false});
        }
    }

    //查询保存的数据
    asQuery(key) {
        AsyncStorage.getItem(key, (error, result) => {
            if (!error) {
                if (result) {
                    oldData=result;
                    let data = JSON.parse((result));
                    if(data){
                        this.setResponse(this,data,false);
                    }
                }
            }
        });
    }

    _onRefresh() {
        this.setState({refreshing: true});
        this._fetchData();
    }

    setResponse(context,data,fromNet){
        if (data.ret === 0) {
            if(fromNet){
                AsyncStorage.setItem(Constants.FIRSTINFO, JSON.stringify(data), (error) => {
                    if (!error) {
                    }
                });
            }
            var topBolb=[];
            let cacheData;
            if(oldData && oldData != null){
                cacheData = JSON.parse(oldData);
            }
            for(let j in data.top){
                let flag=false;
                if(cacheData){
                    if(j<cacheData.top.length && cacheData.top[j].lastUpdateTime  <  data.top[j].lastUpdateTime){
                        flag=true;
                    }
                }
                let info={
                    imgUrl:data.top[j].imgUrl,
                    memo:data.top[j].memo,
                    title:data.top[j].title,
                    action:data.top[j].action,
                    showRedPoint:flag
                };
                topBolb.push(info);
            };
            var listBolb=[];
            for(let i in data.list){
                let showRedPoint=false;
                if(cacheData && cacheData.list){
                    for(let n in cacheData.list){
                        if(cacheData.list[n] != null && data.list[i] != null && cacheData.list[n].listId == data.list[i].listId){
                            if(cacheData.list[n].lastUpdateTime  <  data.list[i].lastUpdateTime){
                                showRedPoint=true;
                                break;
                            }
                        }
                    }
                }
                let info={
                    distributionType:data.list[i].distributionType,
                    openid:data.list[i].openid,
                    description:data.list[i].description,
                    isPrivate:data.list[i].isPrivate,
                    isSubscribe:data.list[i].isSubscribe,
                    listType:data.list[i].listType,
                    weeklySubscribe:data.list[i].weeklySubscribe,
                    imgUrl:data.list[i].imgUrl,
                    listId:data.list[i].listId,
                    payType:data.list[i].payType,
                    subscribeNum:data.list[i].subscribeNum,
                    payPrice:data.list[i].payPrice,
                    pushSwitch:data.list[i].pushSwitch,
                    auditStatus:data.list[i].auditStatus,
                    listName:data.list[i].listName,
                    markNum:data.list[i].markNum,
                    lastUpdateTime:data.list[i].lastUpdateTime,
                    showRedPoint:showRedPoint
                };
                listBolb.push(info);
            };
            context.setState({
                tops: context.state.tops.cloneWithRows(topBolb),
                lists: context.state.lists.cloneWithRows(listBolb),
                total:data.total,
                isLogin:true,
                latestTip:'最近更新',
                noNet:false
            });
            oldData=JSON.stringify(data);
        } else {
            context.refs.toast.show(data.msg, DURATION.LENGTH_SHORT);
        }
    }

    _fetchData() {
        let context = this;
        var url = APIService.firstIndex;
        if (!this.state.isLogin) {
            context.setState({refreshing:false});
            return;
        }
        let par = {
            'openid': this.state.openid
        };
        HttpUtils.postForm(url, par, (data) => {
            if(data){
                context.setState({refreshing:false});
                if(!oldData || oldData == null)
                    oldData = JSON.stringify(data);
                context.setResponse(context,data,true);
            }else{
                context.setState({noNet: true,refreshing:false});
            }
        });

    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    midLayout: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    nameText: {
        fontSize: px2dp(16),
        marginLeft: px2dp(5),
        color: '#444444',
    },
    redText: {
        fontSize: px2dp(16),
        marginLeft: px2dp(5),
        color: '#ff5252',
    },
    avatar: {
        width: px2dp(40),
        height: px2dp(40),
        borderRadius:px2dp(4),
        backgroundColor:'#fff'
    },
    contributeText: {
        fontSize: px2dp(12),
        color: '#999999',
        marginLeft: px2dp(5),
        marginTop:px2dp(3),
        textAlign: 'right',
    },
    item: {
        flexDirection: 'row',
        height: px2dp(62),
        paddingLeft:px2dp(15),
        alignItems: 'center',
        backgroundColor: 'white',
    },
    actionBar: {
        flexDirection: 'row',
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        justifyContent: 'center',
        borderBottomColor: '#ececec',
        borderBottomWidth: 1 / PixelRatio.get(),
        paddingTop: (Platform.OS == 'ios' ? px2dp(20) : 0)
    }
});
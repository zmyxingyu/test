/**
 * 关注页面
 * Created by yf on 2017/8/29.
 */
import React, {Component} from 'react';
import {
    Linking,Text, View, StyleSheet,RefreshControl,Image, StatusBar,Platform,DeviceEventEmitter, PixelRatio,TouchableOpacity,Dimensions, ScrollView,NativeModules,NetInfo,InteractionManager
} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';
import URLUtils from '../utils/URLUtils';
import HttpUtils from '../utils/HttpUtils';
import ScreenUtils from '../utils/ScreenUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import CCCImage from '../component/CCCImage';
import GridView from 'rn-grid-view';
import APIService from '../config/APIService';
import UserInfoUtils from '../utils/UserInfoUtils';
import DialogMessageConfim from '../component/DialogMessageConfim';
import DialogTitleConfrim from '../component/DialogTitleConfrim';
import NetworkErrorView from '../component/NetworkErrorView';
import ParallaxScrollView from 'react-native-parallax-scroll-view';

var tipMessgae="确定不再关注该用户了吗？";
export default class FollowPage extends Component{
    constructor(props){
        super(props);
        this.state = {
            openid:this.props.screenProps.openid,
            isNetworkAvailable: true,
            dataBlob: null,
            communities:[],
            marklists:[],
            isTop:true,
            targetOpenid:this.props.screenProps.targetOpenId,
            refreshing:true,
            isLogin:false,
            closeTopAd:false,
            nickName:'',
            isSpecialConcern:1,//是否打开推送开关   1打开  0关闭
            remarkName:'',
            signature:'',
            occupation:'',
            iconUrl:'',
            memo:'',
            sex:1,
            fansCount:0,
            totalCredit:0,
            roles:'',
            opacity:0,
            hasChatPermission:0,//0不显示私聊按钮  1显示
            isConcern:0,
            bgImgUrl:''//背景图
        };
    }

    dialogConfirm(){
        return (
            <DialogMessageConfim
                ref={(ref) => {
                    this.confirmDialog = ref;
                }}
                content="请允许推送"
                message="只有打开了推送选项，才能第一时间收到最新的消息通知"
                onConfirm={() => {
                    this.confirmDialog.popupDialog.dismiss();
                    InteractionManager.runAfterInteractions(() => {
                        this.setState({isSpecialConcern:1});
                        this.fetchPush(1);
                    });
                }}
                onCancel={() => {
                    this.confirmDialog.popupDialog.dismiss();
                    InteractionManager.runAfterInteractions(() => {
                        this.setState({isSpecialConcern:0});
                        this.fetchPush(0);
                    });
                }}
            />
        );
    }

    fetchPush(pushSwitch) {
        let context = this;
        var url = APIService.pushSwitch;
        let par = {
            'targetOpenid' : this.state.targetOpenid,
            'openid' : this.state.openid,
            'pushSwitch' : pushSwitch+'',
        };
        HttpUtils.postForm(url,par,function (data) {
            if(data.ret === 0){
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                this.setState({isSpecialConcern:(pushSwitch==1?0:1)});
            }
        });
    }

    _onPressCallback(position){
        switch (position){
            case 0:
                NativeModules.CommonModule.goBack();
                break;
            case 1://接受消息通知
                if(this.state.isSpecialConcern==1){
                    this.confirmDialog.popupDialog.show();
                }else{
                    this.fetchPush(1);
                    this.setState({isSpecialConcern:1});
                }
                break;
            case 2://私信
                NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/chatPage?fromOpenid="+this.state.targetOpenid+"&nickName="+((this.state.remarkName==''||this.state.remarkName==null)?this.state.nickName:this.state.remarkName));
                break;
            case 3://资料
                this.props.navigation.navigate('OtherUserInfoPage', {openid:this.state.openid,'nickName':this.state.nickName,'isConcern':this.state.isConcern,'signature':this.state.signature,'occupation':this.state.occupation,'job':this.state.job,'memo':this.state.memo,'remarkName':this.state.remarkName,'targetOpenid':this.state.targetOpenid});
                break;
            case 4://关注
                if(this.state.isConcern==1){
                    this.confirmConcernDialog.popupDialog.show();
                }else{
                    this.postConcernData(1,0);
                }
                break;
            case 5://个人资料页
                NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/userInfoPage');
                break;
        }
    }

    postConcernData(opType,isUnsubscribeMarklist) {
        let context = this;
        var url = APIService.updateConcern;
        let par = {
            'openid' : this.state.openid,
            'targetOpenid' : this.state.targetOpenid,
            'opType' : opType+"",
            'timestamp':new Date().getTime(),
            'isUnsubscribeMarklist':isUnsubscribeMarklist+''
        };
        HttpUtils.postForm(url,par,function (data) {
            if(data){
                if(data.ret === 0){
                    if(isUnsubscribeMarklist!=1){
                        if(context.state.isConcern==1){
                            context.setState({isConcern:0,fansCount:--context.state.fansCount});
                        }else{
                            NativeModules.CommonModule.sendConcernEvent(context.state.targetOpenid,1);
                            context.setState({isConcern:1,fansCount:++context.state.fansCount});
                        }
                    }else{
                        NativeModules.CommonModule.sendConcernEvent(context.state.targetOpenid,0);
                    }
                }else{
                    context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                }
            }
        });
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentDidMount(){
        if (Platform.OS === 'ios') {
            Linking.getInitialURL().then((url) => {
                const result = URLUtils.parseQueryString(url);
                InteractionManager.runAfterInteractions(() => {
                    this.setState({targetOpenid: result.otherOpenid});
                    if (result.otherOpenid == this.state.openid) {
                        this._fetchMineData();
                    } else
                        this._fetchData(result.otherOpenid);
                });
            }).catch(err => console.error('An error occurred', err));
        }else{
            InteractionManager.runAfterInteractions(() => {
                if (this.state.targetOpenid === this.state.openid) {
                    this._fetchMineData();
                } else
                    this._fetchData(this.state.targetOpenid);
            });
        }
        this.refreshEvent = DeviceEventEmitter.addListener('setRemark',(remarkName)=>{
            this.setState({remarkName});
        });
    }

    componentWillUnmount(){
        this.refreshEvent.remove();
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
    };

    handleConnectivityChange = (isConnected)=> {
        this.setState({isNetworkAvailable: isConnected});
    };

    userHeadView(){
        return (
            <View style={{flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center',backgroundColor:'#4444'}}>
                <View>
                    {
                        this.state.iconUrl==''?<Image
                                source={require('../image/default_header_img.png')}
                                style={{width:px2dp(60),height:px2dp(60),borderRadius:px2dp(30),marginTop:px2dp(67)}}/>
                            :
                            <CCCImage
                                placeholderErrorSource={require('../image/default_header_img.png')}
                                source={{uri: this.state.iconUrl.replace('/o/','/s240x240/')}}
                                style={{width:px2dp(60),height:px2dp(60),borderRadius:px2dp(30),marginTop:px2dp(67)}}>
                            </CCCImage>
                    }
                    {
                        UserInfoUtils.getRoleFlag(this.state.roles) == 1 ?
                            <Image source={require('../image/v_s_blue.png')} style={{position:'absolute',
                                width: px2dp(17),height: px2dp(17),marginLeft: px2dp(45),marginTop: px2dp(110)
                            }}/>
                            : (UserInfoUtils.getRoleFlag(this.state.roles)==2?
                            <Image source={require('../image/v_s_orage.png')} style={{position:'absolute',width:px2dp(17),height:px2dp(17),marginLeft:px2dp(45),marginTop:px2dp(110)}}/>
                            :null)
                    }
                </View>
                <Text style={{color: '#fff', backgroundColor:'#0000',fontSize: px2dp(20),marginTop:px2dp(10)}}>{(this.state.remarkName==''||this.state.remarkName==null)?this.state.nickName:this.state.remarkName}</Text>
                <Text style={{color: '#fff',backgroundColor:'#0000', fontSize: px2dp(16)}}>{this.state.fansCount}人关注</Text>
                <Text style={{color: '#fff',backgroundColor:'#0000', fontSize: px2dp(12),marginTop:px2dp(3),marginLeft:px2dp(30),marginRight:px2dp(30)}} numberOfLines={3}>{(this.state.memo==''||this.state.memo==null)?((this.state.signature==null||this.state.signature=='')?'':("简介："+this.state.signature)):"认证："+this.state.memo}</Text>
            </View>
        )
    }

    onScroll(e){
        if(e.nativeEvent.contentOffset.y>px2dp(10)){
            if(e.nativeEvent.contentOffset.y<px2dp(200)){
                this.setState({isTop:false,opacity:e.nativeEvent.contentOffset.y/200});
            }else{
                this.setState({isTop:false,opacity:1});
            }
        }else {
            this.setState({isTop:true});
        }
    }

    _onRefresh() {
        this.setState({refreshing: true});
        if(this.state.targetOpenid==this.state.openid){
            this._fetchMineData();
        }else
            this._fetchData(this.state.targetOpenid);
    }

    render() {
        return (
            <View style={styles.container}>
                {
                    Platform.OS == 'ios'?
                        <StatusBar backgroundColor="#000"/>:null
                }
                {this.state.isNetworkAvailable?
                    (
                        Platform.OS == 'ios'?
                            <ParallaxScrollView
                                ref={'scrollView'} style={styles.container} scrollEventThrottle={5} alwaysBounceVertical={true}  onScroll={this.onScroll.bind(this)} automaticallyAdjustContentInsets={false}
                                refreshControl={
                                    <RefreshControl
                                        refreshing={this.state.refreshing}
                                        onRefresh={this._onRefresh.bind(this)}
                                        colors={['red','#ffd500','#0080ff','#99e600']}
                                    />
                                }
                                backgroundScrollSpeed={(Platform.OS === 'android')?2:3}
                                contentBackgroundColor={theme.pageBackgroundColor}
                                backgroundColor={theme.pageBackgroundColor}
                                renderBackground={() =>
                                    (this.state.bgImgUrl==''||this.state.bgImgUrl=='null')?
                                        <Image source={require('../image/user_info_bg.jpg')} style={{height:px2dp(250),width:Dimensions.get('window').width}} resizeMode={Image.resizeMode.stretch}>
                                            {this.userHeadView()}
                                        </Image>
                                        :
                                        <Image source={{uri:this.state.bgImgUrl.replace('/o/','/s240x120/')}} style={{height:px2dp(250),width:Dimensions.get('window').width}} resizeMode={Image.resizeMode.stretch}>
                                            {this.userHeadView()}
                                        </Image>
                                }
                                parallaxHeaderHeight={250}>
                                {this.renderContent()}
                            </ParallaxScrollView>
                            :
                            <ScrollView
                                ref={'scrollView'} style={styles.container} scrollEventThrottle={5} alwaysBounceVertical={true}  onScroll={this.onScroll.bind(this)} automaticallyAdjustContentInsets={false}
                                refreshControl={
                                    <RefreshControl
                                        refreshing={this.state.refreshing}
                                        onRefresh={this._onRefresh.bind(this)}
                                        colors={['red','#ffd500','#0080ff','#99e600']}
                                    />
                                }>
                                {
                                    (this.state.bgImgUrl==''||this.state.bgImgUrl=='null')?
                                        <Image source={require('../image/user_info_bg.jpg')} style={{height:px2dp(250),width:Dimensions.get('window').width}} resizeMode={Image.resizeMode.stretch}>
                                            {this.userHeadView()}
                                        </Image>
                                        :
                                        <Image source={{uri:this.state.bgImgUrl.replace('/o/','/s240x120/')}} style={{height:px2dp(250),width:Dimensions.get('window').width}} resizeMode={Image.resizeMode.stretch}>
                                            {this.userHeadView()}
                                        </Image>
                                }
                                {this.renderContent()}
                            </ScrollView>
                    )
                    :
                    <NetworkErrorView onPress={()=>{
                        this.setState({isNetworkAvailable:true});
                        InteractionManager.runAfterInteractions(() => {
                            this._fetchData(this.state.targetOpenid);
                        });
                    }}/>
                }
                {
                    this.state.isTop?
                        <View style={styles.actionBar}>
                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 0)} style={{width:px2dp(40)}}
                                              activeOpacity={theme.btnActiveOpacity}>
                                <Image
                                    style={{width: px2dp(12),height: px2dp(20),marginLeft:px2dp(15)}}
                                    source={require('../image/white_left_back.png')}
                                />
                            </TouchableOpacity>
                            <View style={{width:ScreenUtils.width-px2dp(40),flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center'}}>
                                {
                                    this.state.targetOpenid==this.state.openid?
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 5)} activeOpacity={theme.btnActiveOpacity}>
                                            <Text style={{color: '#fff', fontSize: px2dp(16),marginRight:px2dp(15)}}>资料</Text>
                                        </TouchableOpacity>
                                        :
                                        <View  style={{width:ScreenUtils.width-px2dp(40),flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center'}}>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 4)} activeOpacity={theme.btnActiveOpacity}>
                                                {
                                                    this.state.isConcern==1?<Text style={{color: '#ff5252', fontSize: px2dp(16),marginRight:px2dp(20)}}>已关注</Text>
                                                        :<Text style={{color: '#fff', fontSize: px2dp(16),marginRight:px2dp(20)}}>关注</Text>
                                                }
                                            </TouchableOpacity>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 2)} activeOpacity={theme.btnActiveOpacity}>
                                                {
                                                    this.state.hasChatPermission==0?null:
                                                        <Text style={{color: '#fff', fontSize: px2dp(16),marginRight:px2dp(20)}}>私信</Text>
                                                }
                                            </TouchableOpacity>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 3)} activeOpacity={theme.btnActiveOpacity}>
                                                <Text style={{color: '#fff', fontSize: px2dp(16),marginRight:px2dp(15)}}>资料</Text>
                                            </TouchableOpacity>
                                        </View>
                                }
                            </View>
                        </View>
                        :
                        <View style={{position:'absolute',
                            flexDirection: 'row',
                            flex:1,
                            height: theme.actionBar.height,
                            backgroundColor: 'rgba(255,255,255,'+this.state.opacity+')',
                            alignItems: 'center',
                            justifyContent: 'center',
                            paddingTop:(Platform.OS == 'ios'?px2dp(20):0)}}>
                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 0)} style={{width:px2dp(40)}}
                                              activeOpacity={theme.btnActiveOpacity}>
                                <Image
                                    style={{width: px2dp(12),height: px2dp(20),marginLeft:px2dp(15)}}
                                    source={require('../image/icon_back.png')}
                                />
                            </TouchableOpacity>
                            <View style={{width:ScreenUtils.width-px2dp(40),flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center'}}>
                                {
                                    this.state.targetOpenid==this.state.openid?
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 5)} activeOpacity={theme.btnActiveOpacity}>
                                            <Text style={{color: 'rgba(0,0,0,'+this.state.opacity+')', fontSize: px2dp(16),marginRight:px2dp(15)}}>资料</Text>
                                        </TouchableOpacity>
                                        :
                                        <View  style={{width:ScreenUtils.width-px2dp(40),flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center'}}>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 4)} activeOpacity={theme.btnActiveOpacity}>
                                                {
                                                    this.state.isConcern==1?<Text style={{marginRight:px2dp(20),color: '#ff5252', fontSize: px2dp(16),marginRight:px2dp(20)}}>已关注</Text>
                                                        :<Text style={{color: 'rgba(0,0,0,'+this.state.opacity+')', fontSize: px2dp(16),marginRight:px2dp(20)}}>关注</Text>
                                                }
                                            </TouchableOpacity>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 2)} activeOpacity={theme.btnActiveOpacity}>
                                                {
                                                    this.state.hasChatPermission==0?null:
                                                        <Text style={{color: 'rgba(0,0,0,'+this.state.opacity+')', fontSize: px2dp(16),marginRight:px2dp(20)}}>私信</Text>
                                                }
                                            </TouchableOpacity>
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 3)} activeOpacity={theme.btnActiveOpacity}>
                                                <Text style={{color: 'rgba(0,0,0,'+this.state.opacity+')', fontSize: px2dp(16),marginRight:px2dp(15)}}>资料</Text>
                                            </TouchableOpacity>
                                        </View>
                                }
                            </View>
                        </View>
                }
                <Toast ref={'toast'}/>
                {this.dialogConfirm()}
                {this.dialogConcernConfirm()}
                {this.dialogExitConfirm()}
            </View>
        )
    }

    renderContent(){
        return (
            <View  style={styles.container}>
                {
                    this.state.isConcern == 1?
                        <View style={{height: px2dp(50),flexDirection:'row',alignItems:'center',backgroundColor:'white'}}>
                            <Text style={{fontSize:px2dp(15),color:'#000',flex:1,paddingLeft:px2dp(10)}}>接收消息通知</Text>
                            <TouchableOpacity onPress={this._onPressCallback.bind(this,1)} activeOpacity={theme.btnActiveOpacity}>
                                {
                                    this.state.isSpecialConcern==1?<Image source={require('../image/switch_on.png')} style={{width: px2dp(51),height: px2dp(31),resizeMode: 'contain'}}/>
                                        :<Image source={require('../image/switch_off.png')} style={{width: px2dp(51),height: px2dp(31),resizeMode: 'contain'}}/>
                                }
                            </TouchableOpacity>
                        </View>
                        :null
                }
                {
                    (this.state.marklists.length == 0 && this.state.communities.length == 0)?
                        <View style={{flex:1,flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(70)}}>
                            <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                            <Text style={{color: '#6F6F6F', fontSize: px2dp(17),marginTop:px2dp(20)}}>暂无清单和圈子</Text>
                        </View>
                        :
                        <View>
                            {
                                this.state.marklists.length>0?
                                    <View>
                                        <View style={{flex:1,flexDirection:'row',paddingLeft:px2dp(15),paddingRight:px2dp(15),marginTop:px2dp(40)}}>
                                            <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>{/*{this.state.otherOpenid==this.state.openid?'我':(this.state.sex=='2'?'她':'他')}的*/}清单</Text>
                                        </View>
                                        <View  style={{marginTop: px2dp(10),marginLeft:px2dp(15),marginRight:px2dp(7)}}>
                                            <GridView
                                                itemsPerRow={3}
                                                renderFooter={null}
                                                onEndReached={null}
                                                scrollEnabled={false}
                                                renderSeparator={null}
                                                items={this.state.marklists}
                                                fillIncompleteRow={false}
                                                renderItem={this._renderMark.bind(this)}
                                                automaticallyAdjustContentInsets={false} />
                                        </View>
                                    </View>
                                    :<View style={{height:px2dp(25)}}/>
                            }
                            {
                                this.state.communities.length>0?
                                    <View>
                                        <View style={{flex:1,flexDirection:'row',paddingLeft:px2dp(15),paddingRight:px2dp(15),marginTop:px2dp(15)}}>
                                            <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>创建及加入的圈子</Text>
                                        </View>
                                        <View  style={{marginTop: px2dp(10),marginLeft:px2dp(15),marginRight:px2dp(7),marginBottom:px2dp(15)}}>
                                            <GridView
                                                itemsPerRow={3}
                                                renderFooter={null}
                                                onEndReached={null}
                                                scrollEnabled={false}
                                                renderSeparator={null}
                                                items={this.state.communities}
                                                fillIncompleteRow={false}
                                                renderItem={this._renderCircle.bind(this)}
                                                automaticallyAdjustContentInsets={false} />
                                        </View>
                                    </View>
                                    :<View style={{height:px2dp(40)}}/>
                            }
                        </View>
                }
            </View>
            )
    }

    dialogExitConfirm(){
        return (
            <DialogTitleConfrim
                ref={(ref) => {
                    this.confirmExitDialog = ref;
                }}
                content="是否同时退订该用户的圈子和清单？"
                cancelText="否"
                confirmText="是"
                onConfirm={() => {
                    this.confirmExitDialog.popupDialog.dismiss();
                    InteractionManager.runAfterInteractions(() => {
                        this.postConcernData(0,1);
                    });
                }}
                onCancel={() => {
                    this.confirmExitDialog.popupDialog.dismiss();
                }}
            />
        );
    }

    dialogConcernConfirm(){
        return (
            <DialogTitleConfrim
                ref={(ref) => {
                    this.confirmConcernDialog = ref;
                }}
                content={tipMessgae}
                cancelText="取消"
                confirmText="确定"
                onConfirm={() => {
                    this.confirmConcernDialog.popupDialog.dismiss();
                    this.confirmExitDialog.popupDialog.show();
                    InteractionManager.runAfterInteractions(() => {
                        this.postConcernData(0,0);
                    });
                }}
                onCancel={() => {
                    this.confirmConcernDialog.popupDialog.dismiss();
                }}
            />
        );
    }

    _onCircleClick(item){
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/circleListPage?listId="+item.listId+"&listType=1");
        });
    }

    _renderCircle(item){
        return (
            <TouchableOpacity key={item.listId} onPress={this._onCircleClick.bind(this, item)} activeOpacity={theme.btnActiveOpacity} >
                <View style={styles.gridviewItem}>
                    <CCCImage source={{uri:item.imgUrl.replace('/o/','/s240x240/')}} style={{width:(Dimensions.get('window').width-px2dp(46))/3,height:(Dimensions.get('window').width - px2dp(46)) / 3,resizeMode:'cover'}} />
                    <Text numberOfLines={1} style={{color: '#444', backgroundColor:'#0000',fontSize: px2dp(14),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(10),paddingLeft:px2dp(6),paddingRight:px2dp(6)}}>{item.listName}</Text>
                    {
                        item.isPrivate===1?
                            <Text numberOfLines={1} style={{color: '#999',backgroundColor:'#0000', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft:px2dp(6),paddingRight:px2dp(6),marginBottom:px2dp(10)}}>私密</Text>
                            :
                            <Text numberOfLines={1} style={{color: '#999',backgroundColor:'#0000', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft:px2dp(6),paddingRight:px2dp(6),marginBottom:px2dp(10)}}>{item.subscribeNum}订阅</Text>
                    }
                </View>
            </TouchableOpacity>
        )
    }

    _onMarkClick(item){
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/inventoryListPage?listId="+item.listId+"&listType=0");
        });
    }

    _renderMark(item){
        return (
            <TouchableOpacity key={item.listId} onPress={this._onMarkClick.bind(this, item)} activeOpacity={theme.btnActiveOpacity} >
                <View  style={styles.gridviewItem}>
                    <CCCImage source={{uri:item.imgUrl.replace('/o/','/s240x240/')}} style={{width:(Dimensions.get('window').width-px2dp(46))/3,height:(Dimensions.get('window').width - px2dp(46)) / 3,resizeMode:'cover'}} />
                    <Text numberOfLines={1} style={{backgroundColor:'#0000',color: '#444', fontSize: px2dp(14),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(10),paddingLeft:px2dp(6),paddingRight:px2dp(6)}}>{item.listName}</Text>
                    {
                        item.isPrivate===1?
                            <Text numberOfLines={1} style={{backgroundColor:'#0000',color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft:px2dp(6),paddingRight:px2dp(6),marginBottom:px2dp(10)}}>私密</Text>
                            :
                            <Text numberOfLines={1} style={{backgroundColor:'#0000',color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft:px2dp(6),paddingRight:px2dp(6),marginBottom:px2dp(10)}}>{item.subscribeNum}订阅</Text>
                    }
                </View>
            </TouchableOpacity>
        )
    }

    _fetchMineData() {
        let context = this;
        var url = APIService.myIndex;
        let par = {
            'openid' : this.state.openid
        };
        HttpUtils.doPost(url, par)
            .then(({data, error}) => {
                context.setState({refreshing:false});
                if (data) {
                    if(data != ''){
                        context.setState({
                            dataBlob:data,
                            memo:data.user.memo,
                            signature:data.user.signature,
                            nickName:data.user.nickName,
                            iconUrl:data.user.iconUrl,
                            roles:data.user.roles,
                            fansCount:data.user.fansCount,
                            communities:data.communities,
                            marklists:data.marklists,
                            sex:data.user.sex,
                            totalCredit:data.user.totalCredit,
                            bgImgUrl:data.user.bgImgUrl,
                            isConcern:data.user.isConcern,
                            occupation:data.user.occupation,
                            remarkName:data.user.remarkName,
                            targetOpenid:data.user.openid,
                            isSpecialConcern:data.user.isSpecConcern
                        });
                    }else{
                        context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                    }
                } else {
                    context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                }
            });
    }

    _fetchData(otherOpenid) {
        let context = this;
        var url = APIService.otherIndex;
        let par = {
            'openid' : this.state.openid,
            'targetOpenid':otherOpenid
        };
        HttpUtils.doPost(url, par)
            .then(({data, error}) => {
                context.setState({refreshing:false});
                if (data) {
                    if(data != ''){
                        tipMessgae="确定不再关注"+(data.user.remarkName?data.user.remarkName:data.user.nickName)+"了吗？"
                        context.setState({
                            dataBlob:data,
                            memo:data.user.memo,
                            signature:data.user.signature,
                            nickName:data.user.nickName,
                            iconUrl:data.user.iconUrl,
                            roles:data.user.roles,
                            fansCount:data.user.fansCount,
                            communities:data.communities,
                            marklists:data.marklists,
                            hasChatPermission:data.hasChatPermission,
                            sex:data.user.sex,
                            totalCredit:data.user.totalCredit,
                            bgImgUrl:data.user.bgImgUrl,
                            isConcern:data.user.isConcern,
                            occupation:data.user.occupation,
                            remarkName:data.user.remarkName,
                            targetOpenid:data.user.openid,
                            isSpecialConcern:data.user.isSpecConcern
                        });
                    }else{
                        context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                    }
                } else {
                    context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                }
            });
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    addImg: {
        width: px2dp(100), height: px2dp(100), marginTop: px2dp(10),marginLeft:px2dp(15),marginBottom:px2dp(25)
    },
    actionBar: {
        position:'absolute',
        flexDirection: 'row',
        flex:1,
        height: theme.actionBar.height,
        backgroundColor: '#0000',
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop:(Platform.OS == 'ios'?px2dp(20):0)
    },
    gridviewItem: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        width:(Dimensions.get('window').width-px2dp(46))/3,
        marginRight:px2dp(8),
        marginBottom:px2dp(25)
    },
    intro: {
        height: px2dp(100),
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: px2dp(20),
        borderBottomColor: '#c4c4c4',
        borderTopColor: '#e4e4e4',
    },
    list:{
        flex: 1,
        borderTopWidth: 1/PixelRatio.get(),
        borderTopColor: '#e4e4e4',
        marginTop: px2dp(15)
    },
    listItem: {
        flex: 1,
        height: px2dp(47),
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: px2dp(25),
        paddingRight: px2dp(25),
        borderBottomColor: '#c4c4c4',
        borderBottomWidth: 1/PixelRatio.get()
    }
});
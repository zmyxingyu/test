/**
 * 累计收入页面
 * Created by lizhj on 2017/8/21.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Image,
    Text,
    NetInfo,
    Platform,
    BackHandler
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import CommonHeader from '../component/CommonHeader';
import px2dp from '../utils/px2dp';
import DividingLine from '../component/DividingLine';
import CustomCommonItem from '../component/CustomCommonItem';
import CCCSwitch from '../component/CCCSwitch';
import HttpUtils from '../utils/HttpUtils';
import APIService from '../config/APIService';
import Constants from '../config/Constants';

export default class IncomePage extends Component {
    constructor(props) {
        super(props);
        const {openid, listId, listType, totalRevenue, dueRevenue, distributionType} = this.props.navigation.state.params;
        this.state = {
            openid,
            listId,
            listType,
            totalIncome: totalRevenue,
            receiveIncome: dueRevenue,
            distributionSwitch: distributionType === 1,
            isNetworkAvailable: true,
        };
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentDidMount(){
        this.backPress=BackHandler.addEventListener('hardwareBackPress',this.backToLastPage);
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        this.backPress.remove();
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
    };

    backToLastPage = () => {
        const {goBack,state} = this.props.navigation;
        if (this.state.listType === Constants.LIST_TYPE.CIRCLE) {
            state.params.callback({distributionType: this.state.distributionSwitch ? 1 : 0});
        }
        goBack();
        return true;
    };

    /**
     * 提交开关状态
     */
    updateSwitch(switchValue) {
        if (this.state.isNetworkAvailable) {
            const params = {
                openid: this.state.openid,
                listId: this.state.listId,
                distributionType: switchValue ? '1' : '0',
            };
            HttpUtils.doPost(APIService.updateInfo, params).then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.setState({distributionSwitch: switchValue});
                        this.toast.show('修改成功', DURATION.LENGTH_SHORT);
                    } else {
                        this.toast.show('开关更新失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('开关更新失败:' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 渲染按贡献度结算给成员开关
     */
    renderSwitch() {
        if (this.state.listType === Constants.LIST_TYPE.LISTING) return null;
        return (
            <CustomCommonItem
                title={'按贡献值结算给成员'}
                clickable={false}
                renderRight={() => {
                    return (
                        <CCCSwitch
                            on={this.state.distributionSwitch}
                            onValueChange={(value) => {
                                this.updateSwitch(value);
                            }}
                        />
                    );
                }}
            />
        );
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'累计收入'}
                    onBack={this.backToLastPage}
                />
                <DividingLine/>
                <View
                    style={{backgroundColor: 'white', marginBottom: px2dp(15)}}>
                    <Image
                        style={styles.coinImg}
                        source={require('../image/icon_balance.png')}
                    />
                    <View style={styles.incomeContainer}>
                        <View style={styles.incomeItem}>
                            <Text style={styles.incomeCount} numberOfLines={1}>
                                {this.state.totalIncome === 0 ? 0 : this.state.totalIncome / 100.0}
                            </Text>
                            <Text style={styles.incomeTipText}>累计收入 (元)</Text>
                        </View>
                        <View style={{width: 1, height: 58, backgroundColor: '#F5F5F5'}}/>
                        <View style={styles.incomeItem}>
                            <Text style={styles.incomeCount} numberOfLines={1}>
                                {this.state.receiveIncome === 0 ? 0 : this.state.receiveIncome / 100.0}
                            </Text>
                            <Text style={styles.incomeTipText}>已到账收入 (元)</Text>
                        </View>
                    </View>
                </View>
                {this.renderSwitch()}
                <Toast ref={(ref) => this.toast = ref}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F1F1F1',
    },
    coinImg: {
        width: px2dp(100),
        height: px2dp(100),
        alignSelf: 'center',
        marginTop: px2dp(50),
        borderRadius: px2dp(100) / 2,
    },
    incomeContainer: {
        justifyContent: 'center',
        flexDirection: 'row',
        marginTop: px2dp(30),
    },
    incomeItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: px2dp(50),
    },
    incomeCount: {
        fontSize: px2dp(28),
        color: '#444444',
    },
    incomeTipText: {
        marginTop: 8,
        fontSize: px2dp(12),
        color: '#A9A9A9',
    },

});
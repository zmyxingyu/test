/**
 * 圈子／清单加入方式设置页面
 * Created by lizhj on 2017/8/28.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    Image,
    TouchableOpacity,
    TextInput,
    NetInfo,
    Platform,
    NativeModules,
    DeviceEventEmitter
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import HttpUtils from '../utils/HttpUtils';
import CommonHeader from '../component/CommonHeader';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import UserInfoUtils from '../utils/UserInfoUtils';
import Constants from '../config/Constants';
import APIService from '../config/APIService';
import DividingLine from '../component/DividingLine';
import CustomCommonItem from '../component/CustomCommonItem';
import DialogAlert from '../component/DialogAlert';
import CCCSwitch from '../component/CCCSwitch';

const {CommonModule} = NativeModules;
const GOBACK_TYPE = {back: 0, post: 1};
export default class JoinSettingPage extends Component {
    constructor(props) {
        super(props);
        const {openid, listId, listType, payType, payPrice, isPrivate,subscribeNum,listName} = this.props.navigation.state.params;
        this.state = {
            openid,
            listId,
            payPrice,
            payType,
            subscribeNum,
            listType,
            listName,
            isPrivate,
            oldPayType:payType,
            valueChange: false, //记录页面值是否有改变，如果无改变则回传空值给上一个页面
            isNetworkAvailable: true,
        };
        //记录最初的私密开关状态
        this.privateSwitch = {isPrivate};
    }

    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
    };


    goBack = (type) => {
        const {goBack, state} = this.props.navigation;
        if (this.state.valueChange && type === GOBACK_TYPE.post) {
            this.postCircleInfo(goBack, state);
        } else {
            goBack();
        }
    };

    resetRNCache(){
        UserInfoUtils.updateMineInfoCache(Constants.UPDATE_MINEINFO_TYPE.UPDATE_PRIVATE_STATE,this.state.listId,
        this.state.isPrivate,this.state.listType);
    }

    /**
     * 更新清单／圈子信息
     */
    async postCircleInfo(goBack, state) {
        if(this.state.oldPayType == Constants.PAY_TYPE.FREE && this.state.payType !== Constants.PAY_TYPE.FREE && this.state.subscribeNum>0){
            let chooseType = await NativeModules.CommonModule.showChoosePayMethodDialog(this.state.subscribeNum+'');
            //1 按月付费 2 按年付费 0 免费
            this.postData(goBack, state,chooseType);
        }else{
            this.postData(goBack, state,-1);
        }
    }

    postData(goBack, state,oldUserSetting){
        if (this.state.isNetworkAvailable) {
            if (this.state.isPrivate !== Constants.IS_PRIVATE.YES && this.state.payType !== Constants.PAY_TYPE.FREE &&
                (this.state.payPrice > 200 || this.state.payPrice < 1)
            ) {
                this.toast.show('定价必须在1-200之间', DURATION.LENGTH_SHORT);
                return;
            }
            let params = {
                oldUserSetting:oldUserSetting!=-1?(oldUserSetting + ''):(0+''),
                openid: this.state.openid,
                listId: this.state.listId,
                payType: this.state.payType + '',
                payPrice: this.state.payPrice + '',
                isPrivate: this.state.isPrivate + '',
            };
            let context=this;
            HttpUtils.doPost(APIService.updateInfo, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        //提交成功，参数回传
                        state.params.callback(context.state);
                        if (context.privateSwitch.isPrivate !== context.state.isPrivate){
                            context.resetRNCache(context.state.isPrivate)
                            //如果圈子私密状态需要刷新我的页面
                            if (Platform.OS === 'ios') {
                                CommonModule.refreshMinePage();
                            } else {
                                DeviceEventEmitter.emit('refreshMine');
                            }
                        }
                        if(oldUserSetting==-1)
                            goBack();
                        else{
                            context.props.navigation.navigate('ReviewPage',
                                {
                                    listName:context.state.listName,
                                    listType:context.state.listType,
                                });
                            //NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/reviewPage?listName=" + this.state.listName + '&listType=' + this.state.listType+ '&listId=' + this.state.listId);
                        }
                    } else {
                        context.toast.show(`数据提交失败：${data.msg}`, DURATION.LENGTH_SHORT);
                    }
                } else {
                    context.toast.show('数据提交失败,请稍后再试', DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    postSetPrivateRequest(value){
        let params = {
            openid: this.state.openid,
            listId: this.state.listId,
            isPrivate: value + '',
        };
        HttpUtils.doPost(APIService.updateInfo, params, '正在提交数据，请稍后').then(({data, error}) => {
            if (data) {
                if (data.ret === 0) {
                    this.setState({isPrivate: value ? 1 : 0,valueChange: true});
                } else {
                    this.alertDialog.alertDialog.show();
                }
            } else {
                this.toast.show('数据提交失败,请稍后再试', DURATION.LENGTH_SHORT);
            }
        });
    }

    renderRightTick() {
        return (
            <View style={styles.rightLayout}>
                <Image style={styles.tickImg} source={require('../image/icon_tick.png')}/>
            </View>
        );
    }

    /**
     * 渲染通用条目
     */
    renderCommonItem(title, show, onPress) {
        return (
            <TouchableOpacity onPress={onPress} activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.commonItem}>
                    <Text style={styles.commonContentText}>{title}</Text>
                    {show ? this.renderRightTick() : null}
                </View>
            </TouchableOpacity>
        );
    }

    renderPayType() {
        const selectMonth = this.state.payType === Constants.PAY_TYPE.MONTH;
        const selectYear = this.state.payType === Constants.PAY_TYPE.YEAR;
        const selectPermanent = this.state.payType === Constants.PAY_TYPE.PERMANENT;
        return (
            <View>
                <Text style={styles.tipsText}>付费金额</Text>
                <View style={styles.costNumberLayout}>
                    <TextInput
                        underlineColorAndroid={'transparent'}
                        style={styles.costNumberText}
                        numberOfLines={1}
                        onChangeText={(text) => {
                            this.setState({payPrice: text, valueChange: true});
                        }}
                        maxLength={3}
                        value={this.state.payPrice + ''}
                        keyboardType="numeric"
                        placeholder={'价格必须在1～200之间'}
                    />
                    <Text style={styles.costNumberUnit}>阅读币</Text>
                </View>
                <Text style={styles.tipsText}>付款方式</Text>
                {this.renderCommonItem('按月付费', selectMonth, () => {
                    this.setState({payType: Constants.PAY_TYPE.MONTH, valueChange: true});
                })}
                <DividingLine />
                {this.renderCommonItem('按年付费', selectYear, () => {
                    this.setState({payType: Constants.PAY_TYPE.YEAR, valueChange: true});
                })}
                <DividingLine />
                {this.renderCommonItem('永久有效', selectPermanent, () => {
                    this.setState({payType: Constants.PAY_TYPE.PERMANENT, valueChange: true});
                })}
            </View>
        );
    }

    renderPrivateSwitch() {
        const listTypeText = this.state.listType === Constants.LIST_TYPE.LISTING ? '清单' : '圈子';
        return (
            <View style={styles.switchLayout}>
                <CustomCommonItem
                    style={styles.messageSwitchLayout}
                    title={`私密${listTypeText}`}
                    clickable={false}
                    renderRight={() => {
                        return (
                            <CCCSwitch
                                on={this.state.isPrivate === Constants.IS_PRIVATE.YES}
                                onValueChange={(value) => {
                                    this.postSetPrivateRequest(value);
                                }}
                            />
                        );
                    }}
                />
                <Text
                    style={[styles.tipsText, {
                        marginTop: px2dp(8),
                        marginBottom: 0
                    }]}>{`开启私密${listTypeText}后只有自己能够查看此${listTypeText}。`}</Text>
            </View>
        );
    }

    /**
     * 渲染提醒话框
     */
    renderAlertDialog() {
        return (
            <DialogAlert
                ref={(ref) => {
                    this.alertDialog = ref;
                }}
                title="已有人付费的清单不能设为私密"
                subTitle={this.state.quitFailReason}
                onConfirm={() => this.alertDialog.alertDialog.dismiss()}
            />
        );
    }

    render() {
        const show = this.state.payType === Constants.PAY_TYPE.FREE;
        const isListing = this.state.listType === Constants.LIST_TYPE.LISTING;
        return (
            <View style={styles.container}>
                {this.renderAlertDialog()}
                <CommonHeader
                    title={ isListing ? '订阅方式' : '加入方式'}
                    onBack={() => {
                        this.goBack(GOBACK_TYPE.back);
                    }}
                    showRightButton
                    onRight={() => {
                        this.goBack(GOBACK_TYPE.post);
                    }}
                    clickable={this.state.valueChange}
                />
                <ScrollView>
                    <View style={styles.container}>
                        {this.renderPrivateSwitch()}
                        {this.state.isPrivate === 1 ? null :
                            <View>
                                <Text style={styles.tipsText}>
                                    {this.state.listType === Constants.LIST_TYPE.LISTING ? '订阅方式' : '加入方式' }
                                </Text>
                                {this.renderCommonItem('免费订阅', show, () => {
                                    this.setState({
                                        payType: Constants.PAY_TYPE.FREE,
                                        valueChange: true
                                    });
                                })}
                                <DividingLine />
                                {this.renderCommonItem('付费订阅', !show, () => {
                                    this.setState({
                                        payType: Constants.PAY_TYPE.MONTH,
                                        valueChange: true
                                    });
                                })}
                                {show ? null : this.renderPayType()}
                            </View>
                        }
                    </View>
                </ScrollView>
                <Toast ref={(ref) => this.toast = ref} position={'center'}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F1F1F1',
    },
    switchLayout: {
        marginTop: px2dp(15),
    },
    commonItem: {
        flexDirection: 'row',
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        height: px2dp(56),
        alignItems: 'center',
        backgroundColor: 'white',
    },
    rightLayout: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    tickImg: {
        width: px2dp(16),
        height: px2dp(10.5),
    },
    tipsText: {
        marginLeft: px2dp(15),
        marginTop: px2dp(30),
        marginBottom: px2dp(8),
        fontSize: px2dp(14),
        color: '#999999',
    },
    commonContentText: {
        color: '#444444',
        fontSize: px2dp(16),
    },
    costNumberLayout: {
        alignItems: 'center',
        flexDirection: 'row',
        backgroundColor: 'white',
        height: px2dp(56),
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
    },
    costNumberText: {
        flex: 1,
        backgroundColor: 'white',
        fontSize: px2dp(16),
        color: '#444444',
    },
    costNumberUnit: {
        textAlign: 'center',
        fontSize: px2dp(16),
    }
});
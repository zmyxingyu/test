/**
 * 清单详情页面
 * Created by lizhj on 2017/8/25.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    ScrollView,
    View,
    Text,
    Image,
    TouchableOpacity,
    NativeModules,
    InteractionManager,
    Linking,
    NetInfo,
    Platform,
    DeviceEventEmitter,
    NativeEventEmitter,
} from 'react-native';
import Toast, {DURATION} from 'react-native-easy-toast';
import ScreenUtils from '../utils/ScreenUtils';
import HttpUtils from '../utils/HttpUtils';
import URLUtils from '../utils/URLUtils';
import UserInfoUtils from '../utils/UserInfoUtils';
import DividingLine from '../component/DividingLine';
import CommonHeader from '../component/CommonHeader';
import CommonContentItem from '../component/CommonContentItem';
import CCCImage from '../component/CCCImage';
import Constants from '../config/Constants';
import APIService from '../config/APIService';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import CustomCommonItem from '../component/CustomCommonItem';
import DialogAlert from '../component/DialogAlert';
import DialogConfirm from '../component/DialogConfirm';
import DialogMessageConfirm from '../component/DialogMessageConfim';
import CCCSwitch from '../component/CCCSwitch';
import FirstLoadingView from '../component/FirstLoadingView';
import NetworkErrorView from '../component/NetworkErrorView';
import {dateFormat, getNextMonth, getNextYear} from '../utils/FormatDateUtil';

const {CommonModule, IntentFromJsModule} = NativeModules;
const {RNPurchaseManager} = NativeModules;
const PurchaseEventEmitter = new NativeEventEmitter(RNPurchaseManager);
const {MarkManager, MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
const MarkManagerEmitter = new NativeEventEmitter(MarkManager);

export default class ListingInfoPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loaded: false,
            isNetworkAvailable: true, //网络可用状况，默认可用
            isLogin: this.props.screenProps.isLogin,
            openid: this.props.screenProps.openid,
            listId: this.props.screenProps.listId,
            subscribeNum: 0, //累计订阅人数
            weeklySubscribe: 0, //七天新增订阅
            totalRevenue: 0, //累计收入
            dueRevenue: 0, //已到账收入
            members: [], //成员
            listName: '', //清单名称
            description: '', //清单简介
            payType: 0,
            payPrice: 0,
            listType: -1, //类型, 0-清单, 1-圈子
            permission: 0,//0-订阅用户,2-清单创建者
            expireDate: '',
            pushSwitch: false,
            creator: {openid: '', nickName: '', iconUrl: ''},
            quitFailReason: '',
            distributionType: 0, //收益分配方式
            isSubscribe: Constants.HAS_SUBSCRIBE.NO,
            isPrivate: Constants.IS_PRIVATE.NO,
            imgUrl: '',
        };
    }


    componentWillMount() {
        NetInfo.isConnected.addEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        if (Platform.OS === 'android') {
            NetInfo.isConnected.fetch().then((isConnected) => {
                this.setState({isNetworkAvailable: isConnected});
            });
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            Linking.getInitialURL().then((url) => {
                const result = URLUtils.parseQueryString(url);
                this.params = {
                    openid: this.state.openid,
                    listId: result.listId,
                };
                InteractionManager.runAfterInteractions(() => {
                    this.requestData(this.params);
                });
            }).catch(err => console.error('url获取参数出错', err));
        } else {
            this.params = {
                openid: this.state.openid,
                listId: this.state.listId,
            };
            InteractionManager.runAfterInteractions(() => {
                this.requestData(this.params);
            });
        }

        if (Platform.OS === 'ios') {
            this.saveDraftEvent = PurchaseEventEmitter.addListener('purchaseListingSuccess', () => {
                this.receivePurchaseSuceess();
            });
            this.saveMarkProfile = MarkManagerEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({description: response.content});
                this.postMarkInfo();
            });
            this.refreshEvent = MineManagerEmitter.addListener('refreshListingPage', (openid) => {
                this.setState({
                    openid
                }, this.requestData);
            });
        } else {
            this.saveDraftEvent = DeviceEventEmitter.addListener('purchaseListingSuccess', () => {
                this.receivePurchaseSuceess();
            });
            this.saveMarkProfile = DeviceEventEmitter.addListener('saveMarkProfile', (response) => {
                this.setState({description: response.content});
                this.postMarkInfo();
            });
            this.refreshEvent = DeviceEventEmitter.addListener('refreshListingPage', (openid) => {
                this.setState({
                    openid
                }, this.requestData);
            });
        }
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener(
            'connectionChange',
            this.handleConnectivityChange
        );
        this.refreshEvent.remove();
        this.saveMarkProfile.remove();
    }

    handleConnectivityChange = (isConnected) => {
        this.setState({isNetworkAvailable: isConnected});
        if (!this.state.loaded) {
            setTimeout(this.requestData, 300);
        }
    };


    postMarkInfo() {
        let params = {
            openid: this.state.openid,
            listId: this.params.listId,
            listName: this.state.listName,
            description: this.state.description,
        };
        HttpUtils.doPost(APIService.updateInfo, params, '').then(({data, error}) => {
            if (data) {
                if (data.ret === 0) {
                } else {
                    console.warn(data.msg);
                }
            } else {
                console.warn(error);
            }
        });
    }

    /**
     * 接收清单购买成功事件
     */
    receivePurchaseSuceess() {
        this.setState({
            permission: Constants.CIRCLE_IDENTITY_TYPE.SUBSCRIBER,
            isSubscribe: Constants.HAS_SUBSCRIBE.YES,
            expireDate: this.updateSubscribeExprieDate(),
        });
    }


    /**
     * 设置圈子加入方式
     * @param payType
     * @returns {*}
     */
    setJoinType(payType) {
        if (this.state.isPrivate === Constants.IS_PRIVATE.YES) {
            return '私密';
        }
        if (payType === Constants.PAY_TYPE.FREE) {
            return '免费';
        } else if (payType === Constants.PAY_TYPE.MONTH) {
            return `${this.state.payPrice}阅读币 /月`;
        } else if (payType === Constants.PAY_TYPE.YEAR) {
            return `${this.state.payPrice}阅读币 /年`;
        } else if (payType === Constants.PAY_TYPE.PERMANENT) {
            return `${this.state.payPrice}阅读币 /永久`;
        }
        return '';
    }

    updateSubscribeExprieDate() {
        if (this.state.payType === Constants.PAY_TYPE.MONTH) {
            return getNextMonth();
        } else if (this.state.payType === Constants.PAY_TYPE.YEAR) {
            return getNextYear();
        } else {
            return '永久';
        }
    }

    requestData = () => {
        if (!this.params || !this.params.listId) return;
        if (this.state.isNetworkAvailable) {
            HttpUtils.doPost(APIService.getListingDetail, {
                openid: this.state.openid,
                listId: this.params.listId
            }).then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.initPage(data);
                    } else {
                        this.toast.show('获取清单数据失败:' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('获取清单数据失败:' + error, DURATION.LENGTH_SHORT);
                }
            });
        }
    };

    /**
     * 将清单转成圈子
     */
    postTransmissionRequest() {
        if (this.state.isNetworkAvailable) {
            let params = {
                openid: this.params.openid,
                listId: this.params.listId,
                listType: Constants.LIST_TYPE.CIRCLE + '',
            };
            HttpUtils.doPost(APIService.updateInfo, params).then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        const newCircle = {
                            auditStatus: 1,
                            imgUrl: this.state.imgUrl,
                            isPrivate: this.state.isPrivate,
                            listId: this.params.listId,
                            listName: this.state.listName,
                            listType: Constants.LIST_TYPE.CIRCLE,
                            subscribeNum: this.state.subscribeNum,
                        }
                        //提交成功,改为圈子信息页面
                        CommonModule.goBack();
                        // IntentFromJsModule.openPageFromJS('kanjian://RNApp/circlePage?listId=' + this.params.listId);
                        //更新RN缓存并刷新MinePage
                        UserInfoUtils.updateMineInfoCache(
                            Constants.UPDATE_MINEINFO_TYPE.TRANSFORM_LISTING, this.params.listId,
                            newCircle);
                        CommonModule.sendUpdateCircleInfoEvent();
                    } else {
                        this.toast.show('转换失败:' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('转换失败:' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 提交订阅清单请求
     */
    postSubscribeRequest() {
        if (this.state.isNetworkAvailable) {
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
            };
            HttpUtils.doPost(APIService.subscribeMarkList, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.toast.show('订阅成功', DURATION.LENGTH_SHORT);
                        this.setState({
                            permission: Constants.CIRCLE_IDENTITY_TYPE.SUBSCRIBER,
                            isSubscribe: Constants.HAS_SUBSCRIBE.YES,
                        });
                        CommonModule.sendUpdateCircleInfoEvent(); //通知原生刷新圈子/清单以及首页
                    } else {
                        this.toast.show('订阅失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('订阅失败：' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 删除/退出圈子请求
     */
    postQuitRequest() {
        if (this.state.isNetworkAvailable) {
            const isCreator = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER
            const uri = isCreator ? APIService.deleteMarkList : APIService.unSubscribeMarkList;
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
            };
            HttpUtils.doPost(uri, params, '正在提交数据，请稍后').then(({data, error}) => {
                if ( this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
                    this.deleteConfirmDialog.popupDialog.dismiss();
                }else{
                    this.unSubscribeConfirmDialog.popupDialog.dismiss();
                }

                if (data) {
                    if (data.ret === 0) {
                        //如果是清单创建者，则同时发送原生通知事件，圈子/清单已删除,回退时回到正确的上一级,否则回退到清单首页
                        if (isCreator) {
                            CommonModule.sendDeleteCircleEvent({isCreator: true});
                        } else {
                            CommonModule.sendDeleteCircleEvent({isCreator: false});
                        }
                        CommonModule.goBack();
                        UserInfoUtils.updateMineInfoCache(
                            Constants.UPDATE_MINEINFO_TYPE.DELETE_LISTING,
                            this.params.listId);
                    } else {
                        this.setState({quitFailReason: data.msg});
                        this.alertDialog.alertDialog.show();
                    }
                } else {
                    this.toast.show('删除/退订失败：' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 提交开关状态
     */
    updatePushSwitch(value) {
        if (this.state.isNetworkAvailable) {
            const params = {
                openid: this.state.openid,
                listId: this.params.listId,
                pushSwitch: value ? '1' : '0',
            };
            HttpUtils.doPost(APIService.changePushSwitch, params, '正在提交数据，请稍后').then(({data, error}) => {
                if (data) {
                    if (data.ret === 0) {
                        this.setState({pushSwitch: value});
                        this.toast.show('修改成功', DURATION.LENGTH_SHORT);
                        CommonModule.sendUpdateCircleInfoEvent();
                    } else {
                        this.toast.show('修改失败：' + data.msg, DURATION.LENGTH_SHORT);
                    }
                } else {
                    this.toast.show('修改失败：' + error, DURATION.LENGTH_SHORT);
                }
            });
        } else {
            this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
        }
    }

    /**
     * 根据请求返回结果初始化页面数据
     * @param data
     */
    initPage(data) {
        this.setState({
            loaded: true,
            nickName: data.obj.nickName ? data.obj.nickName : '未设置',
            permission: data.obj.permission,
            listName: data.obj.listName,
            listType: data.obj.listType,
            description: data.obj.description,
            subscribeNum: data.obj.subscribeNum,
            totalRevenue: data.obj.totalRevenue,
            dueRevenue: data.obj.dueRevenue,
            weeklySubscribe: data.obj.weeklySubscribe,
            pushSwitch: data.obj.pushSwitch === Constants.SWITCH.ON,
            payType: data.obj.payType,
            payPrice: data.obj.payPrice,
            expireDate: data.obj.expireDate ? data.obj.expireDate : '永久',
            members: data.members,
            creator: {
                openid: data.obj.creator.openid,
                nickName: data.obj.creator.nickName,
                iconUrl: data.obj.creator.iconUrl,
            },
            distributionType: data.obj.distributionType,
            isSubscribe: data.obj.isSubscribe,
            isPrivate: data.obj.isPrivate,
            imgUrl: data.obj.imgUrl
        });
    }


    /**
     * 判断退出按钮显示内容
     * @returns {string}
     */
    judgeQuitBtnText() {
        if (this.state.permission !== undefined) {
            if (this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER) {
                return '删除清单';
            } else {
                return '取消订阅';
            }
        } else {
            if (this.state.payType === 0) {
                return '订阅清单';
            } else {
                return `立即购买 ${this.setJoinType(this.state.payType)}`;
            }
        }
    }

    _handleItemClick(position){
        InteractionManager.runAfterInteractions(() => {
            switch (position){
                case 0:
                    this.props.navigation.navigate('TotalSubscriptPage',
                        {
                            openid:this.state.openid,
                            listId:this.state.listId,
                        });
                    break;
            }
        });
    }

    renderSubscribeLayoutAndIncome() {
        const {navigate} = this.props.navigation;
        return (
            <View key={0}>
                <View style={styles.subscribeContainer}>
                    <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity} style={styles.subscribeItem}>
                        <View style={styles.subscribeItem}>
                            <Text style={styles.subscribeCount}>{this.state.subscribeNum}</Text>
                            <Text style={styles.increaseTipText}>累计订阅人数</Text>
                        </View>
                    </TouchableOpacity>
                    <View style={{width: 1, height: 58, backgroundColor: '#F5F5F5'}}/>
                    <View style={styles.subscribeItem}>
                        <Text style={styles.subscribeCount}>{this.state.weeklySubscribe}</Text>
                        <Text style={styles.increaseTipText}>新增订阅</Text>
                    </View>
                </View>
                <DividingLine/>
                <CommonContentItem
                    item={{
                        title: '累计收入 (仅自己可见)',
                        content: `¥ ${this.state.totalRevenue !== 0 ? this.state.totalRevenue / 100.0 : 0}`
                    }}
                    onClick={() => {
                        navigate('IncomePage', {
                            openid: this.state.openid,
                            listId: this.params.listId,
                            listType: this.state.listType,
                            totalRevenue: this.state.totalRevenue,
                            dueRevenue: this.state.dueRevenue,
                            distributionType: this.state.distributionType,
                        });
                    }}
                />
            </View>
        );
    }

    renderShareItem() {
        return (
            <CustomCommonItem
                title={'分享清单'}
                onClick={() => {
                    IntentFromJsModule.openPageFromJS('kanjian://MainApp/commonSharePage?title=分享清单&url=' +
                        APIService.HTTP_BASE_URL+ APIService.shareCircleURL + this.params.listId + '&QrCodeType=3' + '&listId=' + this.params.listId);
                }}
                renderRight={() => {
                    return (
                        <View style={styles.touchableLayout}>
                            <Image
                                style={styles.qrcodeImage}
                                source={require('../image/my_qrcode.png')}
                            />
                            <Image
                                style={styles.rightArrowImg}
                                source={require('../image/more_icon.png')}
                            />
                        </View>
                    );
                }}
            />
        );
    }

    /**
     * 渲染清单创建者可见选项
     */
    renderOwnerOptions() {
        const {navigate} = this.props.navigation;
        return (
            <View key={1} style={styles.otherLayout}>
                <CommonContentItem
                    item={{
                        title: '清单名称',
                        content: `${this.state.listName}`
                    }}
                    onClick={() => {
                        navigate('EditCircleNamePage', {
                            openid: this.state.openid,
                            listId: this.params.listId,
                            listName: this.state.listName,
                            listType: Constants.LIST_TYPE.LISTING,
                            callback: (data) => {
                                if (data) this.setState(data);
                            },
                        });
                    }}
                />
                <DividingLine/>
                <TouchableOpacity
                    style={styles.touchableLayout} activeOpacity={theme.btnActiveOpacity}
                    onPress={() => {
                        let description = this.state.description ? this.state.description : '';
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://MainApp/addArticlePage?listType=0&isEditArticle=0&markContent=' + description);
                    }}
                >
                    <View style={{flexDirection: 'row'}}>

                        <View style={styles.circleIntroduceTipView}>
                            <Text style={styles.circleIntroduceTipText}>清单介绍</Text>
                        </View>

                        <View style={styles.rightLayout}>
                            <View style={[styles.touchableLayout, {marginRight: px2dp(15)}]}>
                                <Text style={styles.content}>编辑</Text>
                                <Image
                                    style={styles.rightArrowImg}
                                    source={require('../image/more_icon.png')}
                                />
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
                <DividingLine/>
                <CommonContentItem
                    item={{
                        title: '订阅方式',
                        content: this.setJoinType(this.state.payType)
                    }}
                    onClick={() => {
                        navigate('JoinSettingPage', {
                            listName:this.state.listName,
                            subscribeNum :this.state.subscribeNum,
                            openid: this.params.openid,
                            listId: this.params.listId,
                            payType: this.state.payType,
                            payPrice: this.state.payPrice,
                            listType: Constants.LIST_TYPE.LISTING,
                            isPrivate: this.state.isPrivate,
                            callback: (data) => {
                                if (data) this.setState(data);
                            }
                        });
                    }}
                />
                <DividingLine/>
                {this.renderShareItem()}
            </View>
        );
    }

    /**
     * 渲染订阅用户可见的圈子基本信息
     */
    renderCircleBasicInfo() {
        return (
            <View style={styles.circleBasicInfoContainer}>
                <DividingLine/>
                <TouchableOpacity
                    style={styles.touchableLayout} activeOpacity={theme.btnActiveOpacity}
                    onPress={() => {
                        let description = this.state.description ? this.state.description : '';
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://MainApp/webPage?title=清单介绍&url=' + description + '&isLoadContent=true');
                    }}
                >
                    <View style={{flexDirection: 'row'}}>
                        <View style={styles.circleIntroduceTipView}>
                            <Text style={styles.circleIntroduceTipText}>清单介绍</Text>
                        </View>
                        <View style={styles.rightLayout}>
                            <View style={[styles.touchableLayout, {marginRight: px2dp(15)}]}>
                                <Text style={styles.content}>查看</Text>
                                <Image
                                    style={styles.rightArrowImg}
                                    source={require('../image/more_icon.png')}
                                />
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
                <DividingLine/>
                <CustomCommonItem
                    title="清单主"
                    onClick={() => {
                        IntentFromJsModule.openPageFromJS('kanjian://RNApp/followPage?otherOpenid=' + this.state.creator.openid);
                    }}
                    renderRight={() => {
                        return (
                            <View style={{flexDirection: 'row', alignItems: 'center'}}>
                                <CCCImage
                                    isRound
                                    placeholderSource={require('../image/default_header_img.png')}
                                    placeholderErrorSource={require('../image/default_header_img.png')}
                                    style={styles.circleInfoImg}
                                    source={{uri: this.state.creator.iconUrl}}
                                />
                                <Text style={styles.circleInfoText}>
                                    {this.state.creator.nickName}
                                </Text>
                                <Image
                                    style={styles.rightArrowImg}
                                    source={require('../image/more_icon.png')}
                                />
                            </View>
                        );
                    }}
                />
            </View>
        );
    }

    /**
     * 渲染消息接收开关
     */
    renderMessageSwitch() {
        return (
            <CustomCommonItem
                key={10}
                style={styles.messageSwitchLayout}
                title={'接收消息通知'}
                clickable={false}
                renderRight={() => {
                    return (
                        <CCCSwitch
                            on={this.state.pushSwitch}
                            onValueChange={(value) => {
                                this.updatePushSwitch(value);
                            }}
                        />
                    );
                }}
            />
        );
    }

    /**
     * 渲染非清单创建者可见选项
     */
    renderSubscriberOptions() {
        return (
            <View key={1}>
                <CommonContentItem
                    item={{
                        title: '清单名称',
                        content: `${this.state.listName}`
                    }}
                    style={{marginTop: px2dp(15)}}
                    rightArrowShow={false}
                    onClick={() => {
                    }}
                />
                {this.renderCircleBasicInfo()}
                {
                    this.state.isSubscribe === Constants.HAS_SUBSCRIBE.YES &&
                    this.state.payType !== Constants.PAY_TYPE.FREE ?
                        <CommonContentItem
                            key={1}
                            item={{
                                title: '付费有效期至',
                                content: this.state.expireDate === '永久' ? this.state.expireDate : `${dateFormat(this.state.expireDate)}`
                            }}
                            onClick={() => {
                            }}
                        /> : null
                }
                {
                    this.state.isSubscribe === Constants.HAS_SUBSCRIBE.YES ? this.renderMessageSwitch() : null
                }
                {this.renderShareItem()}
            </View>
        );
    }

    /**
     * 将清单转为圈子
     * @returns {XML}
     */
    renderTurnButton() {
        return (
            <TouchableOpacity
                key={2} activeOpacity={theme.btnActiveOpacity}
                style={styles.quitButton}
                onPress={() => {
                    this.postTransmissionRequest();
                }}
            >
                <Text style={styles.turnButtonText}>将此清单转换为圈子</Text>
            </TouchableOpacity>
        );
    }

    renderQuitButton() {
        const isCreator = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        return (
            <TouchableOpacity
                key={3}
                activeOpacity={theme.btnActiveOpacity}
                style={styles.quitButton}
                onPress={() => {
                    if (this.state.isLogin) {
                        if (this.state.isSubscribe === Constants.HAS_SUBSCRIBE.YES) {
                            if (isCreator) {
                                this.deleteConfirmDialog.popupDialog.show();
                            } else {
                                this.unSubscribeConfirmDialog.popupDialog.show();
                            }
                        } else {
                            if (this.state.payType === Constants.PAY_TYPE.FREE) {//免费
                                this.postSubscribeRequest();
                            } else {
                                //需要付费则调用支付
                                CommonModule.showPurchaseBottomDialog(this.params.listId, this.state.listType + '',
                                    this.state.listName, this.state.imgUrl, this.state.payPrice + '', '', '0', '1');
                            }
                        }
                    } else {
                        IntentFromJsModule.openPageFromJS('kanjian://MainApp/loginPage?to=kanjian://RNApp/listingPage');
                    }
                }}
            >
                <Text style={styles.quitButtonText}>{this.judgeQuitBtnText()}</Text>
            </TouchableOpacity>
        );
    }

    /**
     * 渲染提醒话框
     */
    renderAlertDialog() {
        return (
            <DialogAlert
                ref={(ref) => {
                    this.alertDialog = ref;
                }}
                title="已有人付费的清单不能删除"
                subTitle={this.state.quitFailReason}
                onConfirm={() => this.alertDialog.alertDialog.dismiss()}
            />
        );
    }

    /**
     * 二次确认是否删除清单对话框
     */
    renderConfirmDeleteDialog() {
        return (
            <DialogConfirm
                ref={(ref) => {
                    this.deleteConfirmDialog = ref;
                }}
                content="确认删除该清单吗？"
                onConfirm={() => {
                    this.postQuitRequest();
                }}
            />
        );
    }

    /**
     * 二次确认是否退订清单对话框
     */
    renderConfirmUnsubscribeDialog() {
        let content;
        if (this.state.payType !== Constants.PAY_TYPE.FREE) {
            content = '取消付费订阅后，再次订阅需重新付费，确定要取消订阅吗？';
        } else {
            content = '确认退订该清单吗？';
        }
        return (
            <DialogMessageConfirm
                ref={(ref) => {
                    this.unSubscribeConfirmDialog = ref;
                }}
                content="温馨提示"
                message={content}
                onConfirm={() => {
                    this.postQuitRequest();
                }}
            />
        );
    }

    render() {
        const canShowData = this.state.permission === Constants.CIRCLE_IDENTITY_TYPE.OWNER;
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'清单信息'}
                    onBack={() => {
                        CommonModule.goBack();
                    }}
                />
                <DividingLine/>
                { this.state.loaded ?
                    <ScrollView>
                        <View style={styles.infoContainer}>
                            {
                                canShowData ?
                                    [
                                        this.renderSubscribeLayoutAndIncome(),
                                        this.renderOwnerOptions(),
                                        this.renderTurnButton(),
                                        this.renderQuitButton()
                                    ]
                                    :
                                    [this.renderSubscriberOptions(),
                                        this.renderQuitButton()]
                            }
                        </View>
                    </ScrollView>
                    :
                    this.state.isNetworkAvailable ? <FirstLoadingView/> :
                        <NetworkErrorView onPress={() => {
                            if (this.state.isNetworkAvailable) {
                                this.requestData()
                            } else {
                                this.toast.show('网络不给力...', DURATION.LENGTH_SHORT);
                            }
                        }}
                        />
                }
                {this.renderAlertDialog()}
                {this.renderConfirmDeleteDialog()}
                {this.renderConfirmUnsubscribeDialog()}
                <Toast ref={(ref) => this.toast = ref} position={'center'}/>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f2f2f2',
    },
    infoContainer: {
        flex: 1,
        paddingBottom: 15,
    },
    subscribeContainer: {
        height: px2dp(122),
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
    },
    subscribeItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    subscribeTitle: {
        fontSize: 14,
    },
    subscribeCount: {
        marginTop: 10,
        fontSize: px2dp(28),
        color: '#FF5252',
    },
    increaseTipText: {
        fontSize: px2dp(12),
        color: '#A9A9A9',
    },
    rightArrowImg: {
        width: px2dp(16),
        height: px2dp(16),
        resizeMode: 'contain',
        marginLeft: px2dp(6),
    },
    otherLayout: {
        marginTop: px2dp(15),
        backgroundColor: 'white',
    },
    touchableLayout: {
        height: px2dp(56),
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    qrcodeImage: {
        width: px2dp(20),
        height: px2dp(20),
    },
    circleBasicInfoContainer: {
        backgroundColor: 'white',
    },
    circleIntroduceTipView: {
        height: px2dp(56),
        justifyContent: 'center',
    },
    circleIntroduceTipText: {
        paddingLeft: px2dp(15),
        fontSize: px2dp(16),
        color: '#444444',
    },
    circleIntroduceText2: {
        fontSize: px2dp(16),
        color: '#999999',
        marginLeft: px2dp(15),
        paddingBottom: px2dp(18),
    },
    messageSwitchLayout: {
        marginTop: px2dp(15),
        marginBottom: px2dp(15),
    },
    quitButton: {
        height: 56,
        width: ScreenUtils.width,
        backgroundColor: 'white',
        marginTop: px2dp(15),
        justifyContent: 'center',
        alignItems: 'center',
    },
    turnButtonText: {
        color: '#444444',
        fontSize: px2dp(16),
    },
    quitButtonText: {
        color: '#FF5252',
        fontSize: px2dp(16),
    },
    circleInfoText: {
        marginLeft: px2dp(7),
        fontSize: px2dp(14),
        marginRight: px2dp(9),
    },
    circleInfoImg: {
        width: px2dp(30),
        height: px2dp(30),
        borderRadius: px2dp(30) / 2,
    },
    rightLayout: {
        flex: 1,
        height: px2dp(56),
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    content: {
        fontSize: px2dp(14),
        color: '#999999'
    },
    p: {
        fontSize: px2dp(16),
        color: '#999999',
    },
});
/**
 * 我的页面
 * Created by yf on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    AsyncStorage,
    Text,RefreshControl,
    View,
    StyleSheet,
    Image,
    NativeEventEmitter,
    DeviceEventEmitter,
    Platform,
    PixelRatio,
    TouchableOpacity,
    Dimensions,
    ScrollView,
    NativeModules,
    InteractionManager
} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import Toast, {DURATION} from 'react-native-easy-toast';
import UserInfoUtils from "../utils/UserInfoUtils";
import CCCImage from '../component/CCCImage';
import GridView from 'rn-grid-view';
import APIService from '../config/APIService';
import NativeCacheUtils from "../utils/NativeCacheUtils";

const {MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
const {DraftManager} = NativeModules;
const DraftManagerEmitter = new NativeEventEmitter(DraftManager);
export default class MinePage extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dataBlob: null,
            articles: [],
            communities: [],
            marklists: [],
            refreshing: true,
            isLogin: this.props.isLogin,
            showTopAd: false,
            nickName: '',
            iconUrl: '',
            signature: '',//简介
            memo: '',//认证
            profit: 0,
            marklistSubscribeNum:0,//订阅数
            fansCount: 0,
            totalCredit: 0,
            kcoin: 0,
            roles: '',
            isRed:0,//1标红  其他不标红
            adContent: '', //广告内容
            linkUrl: '', //广告链接
        };
    }

    _onPressCallback(position) {
        InteractionManager.runAfterInteractions(() => {
            switch (position) {
                case 0://扫一扫
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/capturePage");
                    break;
                case 1://设置
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/settingPage");
                    break;
                case 3://我的收入
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://MainApp/myProfitPage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/myProfitPage");
                    }

                    break;
                case 4://我的阅读币
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://RNApp/myKCoinPage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/myKCoinPage');
                    }
                    break;
                case 5://积分
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://MainApp/webPage?title=兑换中心&url=" + APIService.HTTP_BASE_URL + APIService.credit);
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/webPage?title=兑换中心&url=" + APIService.HTTP_BASE_URL + APIService.credit);
                    }
                    break;
                case 6:
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://MainApp/myFollowPage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/myFollowPage?searchType=5&userId=" + Constants.openid);
                    }
                    break;
                case 7://顶部广告叉
                    this.setState({
                        showTopAd: false
                    });
                    AsyncStorage.getItem("topAdInfo", (error, result) => {
                        if (!error) {
                            if (result !== '' && result !== null) {
                                let json = JSON.parse(result);
                                if(json.popupNum>0){
                                    json.popupNum=0;
                                    AsyncStorage.setItem("topAdInfo", JSON.stringify(json), (error) => {
                                    });
                                }
                            }
                        }
                    });
                    break;
                case 2://进入我的详情页面
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/userInfoPage');
                    }
                    break;
                case 8://添加清单
                    NativeModules.UxSDKModule.trackCustomKVEvent('me_createList_click');
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://RNApp/addMarkPage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/addMarkPage');
                    }
                    break;
                case 9://添加圈子
                    NativeModules.UxSDKModule.trackCustomKVEvent('me_createCircles_click');
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://RNApp/addCirclePage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/addCirclePage');
                    }
                    break;
                case 10://添加文章
                    NativeModules.UxSDKModule.trackCustomKVEvent('me_createArticle_click');
                    if (!this.state.isLogin) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/loginPage?to=kanjian://MainApp/addArticlePage");
                    } else {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/addArticlePage?isEditArticle=1");
                    }
                    break;
                case 11:
                    const shareUrl = APIService.HTTP_BASE_URL + APIService.sharePersonalURL + Constants.openid;
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/commonSharePage?title=我的二维码&url=" + shareUrl + '&listId=' + Constants.openid);
                    break;
            }
        })

    }

    _onRefresh() {
        this.setState({refreshing: true});
        this._fetchData();
    }

    _fetchAdData(){
        const requestParams = {
            openid: Constants.openid,
            type: '2',//类型功能通知，固定为2
            showPlace: '3',
        };
        let context = this;
        HttpUtils.doPost(APIService.getOperatingAd, requestParams).then(({data}) => {
            if (data) {
                if (data.ret === 0) {
                    this.setState({
                        adContent: data.content,
                        linkUrl: data.linkUrl,
                        isRed: data.isRed
                    });
                    data.popupNum--;
                    AsyncStorage.getItem("topAdInfo", (error, result) => {
                        if (!error) {
                            if (result !== '' && result !== null) {
                                let json = JSON.parse(result);
                                if(json.id == data.id){
                                    if(json.popupNum<=0){
                                        context.setState({showTopAd: false});
                                    }else{
                                        json.popupNum--;
                                        context.setState({showTopAd: true});
                                        AsyncStorage.setItem("topAdInfo", JSON.stringify(json), (error) => {
                                        })
                                    }
                                }else{
                                    context.setState({showTopAd: true});
                                    AsyncStorage.setItem("topAdInfo", JSON.stringify(data), (error) => {
                                    })
                                }
                            }else {
                                context.setState({showTopAd: true});
                                AsyncStorage.setItem("topAdInfo", JSON.stringify(data), (error) => {
                                })
                            }
                        }
                    });
                }
            }
        });
    }

    async componentDidMount() {
        InteractionManager.runAfterInteractions(() => {
            this.asQuery(Constants.MINEINFO);
            this._fetchData();
            this._fetchAdData();
        });
        if (Platform.OS === 'ios') {
            this.refreshNetEvent = MineManagerEmitter.addListener('refreshMineFromNet', () => {
                InteractionManager.runAfterInteractions(() => {
                    this._fetchData();
                });
            });
            this.saveDraftEvent = DraftManagerEmitter.addListener('saveDraft', (response) => {
                this.saveDraft(response);
            });
            this.subscription = MineManagerEmitter.addListener('loginBack', (response) => {
                this.loginBack(response);
            });
            this.changeIdentityEvent = MineManagerEmitter.addListener('identityResult', (response) => {
                this._userInfoUpdate(response);
            });
            this.logout = MineManagerEmitter.addListener('logout', () => {
                this._logout();
            });
            this.userInfoUpdate = MineManagerEmitter.addListener('userInfoUpdate', (response) => {
                this._userInfoUpdate(response);
            });
            this.userInfoUpdate = MineManagerEmitter.addListener('refreshMine', () => {
                this.asQuery(Constants.MINEINFO);
            });
            this.changeMarkBg=MineManagerEmitter.addListener('changeMarkBg',(response)=>{
             this._changeMarkBg(response);
             });
        } else {
            this.refreshNetEvent = DeviceEventEmitter.addListener('refreshMineFromNet', () => {
                InteractionManager.runAfterInteractions(() => {
                    this._fetchData();
                });
            });
            this.saveDraftEvent = DeviceEventEmitter.addListener('saveDraft', (response) => {
                this.saveDraft(response);
            });
            this.subscription = DeviceEventEmitter.addListener('loginBack', (response) => {
                this.loginBack(response);
            });
            this.logout = DeviceEventEmitter.addListener('logout', () => {
                this._logout();
            });
            this.userInfoUpdate = DeviceEventEmitter.addListener('userInfoUpdate', (response) => {
                this._userInfoUpdate(response);
            });
            this.changeMarkBg = DeviceEventEmitter.addListener('changeMarkBg', (response) => {
                this._changeMarkBg(response);
            });
            this.changeIdentityEvent = DeviceEventEmitter.addListener('identityResult', (response) => {
                this._userInfoUpdate(response);
            });
        }
        //仅在Android端生效
        this.refreshEvent = DeviceEventEmitter.addListener('refreshMine', () => {
            this.asQuery(Constants.MINEINFO);
        });
    }

    componentWillUnmount() {
        this.refreshNetEvent.remove();
        this.subscription.remove();
        this.refreshEvent.remove();
        this.logout.remove();
        this.saveDraftEvent.remove();
        this.userInfoUpdate.remove();
        this.changeMarkBg.remove();
        this.changeIdentityEvent.remove();
    };

    _changeMarkBg(response) {
        let context = this;
        AsyncStorage.getItem(Constants.MINEINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    if (response.listType == 1) {
                        for (let i in data.communities) {
                            if (response.listId == data.communities[i].listId) {
                                data.communities[i].imgUrl = response.newBgImg;
                                break;
                            }
                        }
                    } else {
                        for (let i in data.marklists) {
                            if (response.listId == data.marklists[i].listId) {
                                data.marklists[i].imgUrl = response.newBgImg;
                                break;
                            }
                        }
                    }
                    AsyncStorage.setItem(Constants.MINEINFO, JSON.stringify(data), (error) => {
                        if (!error) {
                            context.asQuery(Constants.MINEINFO);
                        }
                    });
                }
            }
        })
    }

    _userInfoUpdate(response) {
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    for (const key in response) {
                        if ([key] == 'kcoin')
                            data.kcoin = response[key];
                        else if ([key] == 'profit') {
                            data.profit = response[key];
                        }
                        else if ([key] == 'totalCredit') {
                            data.totalCredit = response[key];
                        }
                        else if ([key] == 'nickName') {
                            data.nickName = response[key];
                        }
                        else if ([key] == 'signature') {
                            data.signature = response[key];
                        }
                        else if ([key] == 'memo') {
                            data.memo = response[key];
                        }
                        else if ([key] == 'identityResult'){
                            data.identityStatus = response[key];
                        }
                        else if ([key] == 'iconUrl'){
                            data.iconUrl = response[key];
                        }
                    }
                    //更新缓存
                    AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data), (error) => {
                        if (!error) {

                        }
                    });
                }
            }
        });
        for (const key in response) {
            this.setState({[key]: response[key]});
        }
    }

    _logout() {
        AsyncStorage.setItem(Constants.MINEINFO, '', (error) => {
            if (!error) {
            }
        })
        AsyncStorage.setItem(Constants.USERINFO, '', (error) => {
            if (!error) {
            }
        })
        Constants.openid = '';
        this.setState({isLogin: false});
        this.asQuery(Constants.MINEINFO);
    }

    loginBack(response) {
        if (response.login_state == 1) {//成功
            if (response.userInfoJson) {
                let data = JSON.parse(response.userInfoJson);
                Constants.openid = data.openid;
                this.setState({
                    isLogin: true,
                    refreshing:true,
                    signature: data.signature,
                    memo: data.memo,
                    nickName: data.nickName,
                    iconUrl: data.iconUrl,
                    roles: data.roles,
                    profit: data.profit,
                    kcoin: data.kcoin,
                    fansCount: data.fansCount,
                    totalCredit: data.totalCredit,
                    marklistSubscribeNum:data.marklistSubscribeNum
                });
            }else{
                this.setState({refreshing:true,isLogin: true});
            }
            AsyncStorage.setItem(Constants.USERINFO, response.userInfoJson);
            if (response.login_to){
                if (response.login_to.indexOf('circlePage') !== -1) {
                    //发送事件刷新圈子信息页
                    const openid = JSON.parse(response.userInfoJson).openid;
                    DeviceEventEmitter.emit('refreshCirclePage', openid);
                } else if (response.login_to.indexOf('listingPage') !== -1) {
                    //发送事件刷新清单信息页
                    const openid = JSON.parse(response.userInfoJson).openid;
                    DeviceEventEmitter.emit('refreshListingPage', openid);
                } else {
                    NativeModules.IntentFromJsModule.openPageFromJS(response.login_to);
                }
            }
            InteractionManager.runAfterInteractions(() => {
                this._fetchData();
            });
        } else {
            this.setState({refreshing:false,isLogin: false});
        }
    }

    saveDraft(response) {
        if (response.result == 1) {
            //保存草稿成功
            AsyncStorage.getItem(Constants.MINEINFO, (error, result) => {
                if (!error) {
                    if (result !== '' && result !== null) {
                        let data = JSON.parse((result));
                        data.articles.length > 0 ?
                            (data.articles[0].total = data.articles[0].total + 1) : null;
                        AsyncStorage.setItem(Constants.MINEINFO, JSON.stringify(data), (error) => {
                            if (!error) {
                                this.asQuery(Constants.MINEINFO);
                            }
                        });
                    }
                }
            })
        } else {
            //发布成功
            AsyncStorage.getItem(Constants.MINEINFO, (error, result) => {
                if (!error) {
                    if (result !== '' && result !== null) {
                        let data = JSON.parse((result));
                        data.articles.length > 1 ?
                            (data.articles[1].total = data.articles[1].total + 1) : null;
                        if (response.isDraftPublish) {
                            data.articles[0].total -= 1;
                        }
                        AsyncStorage.setItem(Constants.MINEINFO, JSON.stringify(data), (error) => {
                            if (!error) {
                                this.asQuery(Constants.MINEINFO);
                            }
                        });
                    }
                }
            })
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.actionBar}>
                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 0)}
                                      activeOpacity={theme.btnActiveOpacity}>
                        <Image source={require('../image/saomiao.png')}
                               style={{width: px2dp(20), height: px2dp(20), marginLeft: px2dp(15)}}/>
                    </TouchableOpacity>
                    <Text style={{
                        flex: 1,
                        color: '#444',
                        fontSize: theme.actionBar.fontSize,
                        textAlign: 'center'
                    }}>我</Text>
                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 1)}
                                      activeOpacity={theme.btnActiveOpacity}>
                        <View style={{flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                            <Image source={require('../image/setting.png')}
                                   style={{width: px2dp(24), height: px2dp(24), marginRight: px2dp(15)}}/>
                        </View>
                    </TouchableOpacity>
                </View>
                <ScrollView
                    refreshControl={
                        <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={this._onRefresh.bind(this)}
                            colors={['red','#ffd500','#0080ff','#99e600']}
                        />
                    }>
                    {
                        (this.state.showTopAd) ?
                            <View style={{
                                backgroundColor: 'white', flexDirection: 'row', alignItems: 'center',
                                borderBottomColor: '#ececec', borderBottomWidth: 1 / PixelRatio.get(), height: px2dp(40)
                            }}>
                                <TouchableOpacity
                                    activeOpacity={theme.btnActiveOpacity}
                                    onPress={() => {
                                        if(this.state.linkUrl)
                                            NativeModules.IntentFromJsModule.openPageFromJS(`kanjian://MainApp/webPage?title=${this.state.adContent}&url=${this.state.linkUrl}`);
                                    }}
                                    style={{ flex: 1}}
                                >
                                    <View style={{flexDirection: 'row', flex: 1,alignItems:'center'}}>
                                        <Image
                                            source={require('../image/icon_tip.png')}
                                            style={{
                                                width: px2dp(20),
                                                height: px2dp(20),
                                                marginLeft: px2dp(18),
                                                marginRight: px2dp(6)
                                            }}
                                        />
                                        <Text style={{
                                            color: this.state.isRed === 1 ? '#ff5252' : '#999',
                                            fontSize: px2dp(14),
                                            flex: 1
                                        }}>
                                            {this.state.adContent}
                                        </Text>
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this._onPressCallback.bind(this, 7)}
                                                  activeOpacity={theme.btnActiveOpacity}>
                                    <Image source={require('../image/icon_close.png')}
                                           style={{
                                               width: px2dp(12),
                                               height: px2dp(12),
                                               marginLeft: px2dp(10),
                                               marginRight: px2dp(20)
                                           }}/>
                                </TouchableOpacity>
                            </View>
                            : null
                    }
                    {
                        this.state.isLogin ?
                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 2)}
                                              activeOpacity={theme.btnActiveOpacity}>
                                <View style={styles.intro}>
                                    {
                                        this.state.iconUrl == '' ? <Image
                                                source={require('../image/default_header_img.png')}
                                                style={{width: px2dp(60), height: px2dp(60)}}/>
                                            :
                                            <View>
                                                {
                                                    this.state.iconUrl?
                                                        <Image
                                                            source={{uri: (this.state.iconUrl?this.state.iconUrl.replace('/o/','/s240x240/'):this.state.iconUrl)}}
                                                            style={{
                                                                width: px2dp(60),
                                                                height: px2dp(60),
                                                                borderRadius: px2dp(30)
                                                            }}>
                                                        </Image>
                                                        :
                                                        <Image
                                                            source={require('../image/default_header_img.png')}
                                                            style={{width: px2dp(60), height: px2dp(60)}}>
                                                        </Image>
                                                }
                                                {
                                                    UserInfoUtils.getRoleFlag(this.state.roles) == 1 ?
                                                        <Image source={require('../image/v_s_blue.png')} style={{
                                                            position: 'absolute',
                                                            width: px2dp(17),
                                                            height: px2dp(17),
                                                            marginLeft: px2dp(45),
                                                            marginTop: px2dp(45)
                                                        }}/>
                                                        : (UserInfoUtils.getRoleFlag(this.state.roles) == 2 ?
                                                        <Image source={require('../image/v_s_orage.png')} style={{
                                                            position: 'absolute',
                                                            width: px2dp(17),
                                                            height: px2dp(17),
                                                            marginLeft: px2dp(45),
                                                            marginTop: px2dp(45)
                                                        }}/>
                                                        : null)
                                                }
                                            </View>

                                    }
                                    <View style={{marginLeft: px2dp(12), flex: 1}}>
                                        <Text style={{
                                            color: theme.text.color,
                                            fontSize: px2dp(22)
                                        }} numberOfLines={1}>{this.state.nickName}</Text>
                                        <Text style={{color: "#999", fontSize: px2dp(12), marginTop: 5}}
                                              numberOfLines={1}>{(this.state.signature == '' || this.state.signature == null) ? ((this.state.memo == '' || this.state.memo == null) ? '' : ("认证：" + this.state.memo)) : "简介：" + this.state.signature}</Text>
                                    </View>
                                    <View style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 11)}
                                                          activeOpacity={theme.btnActiveOpacity}>
                                            <Image source={require('../image/my_qrcode.png')}
                                                   style={{width: px2dp(20), height: px2dp(20)}}/>
                                        </TouchableOpacity>
                                        <Image source={require('../image/more_icon.png')}
                                               style={{width: px2dp(16), height: px2dp(16), marginLeft: px2dp(5)}}/>
                                    </View>
                                </View>
                            </TouchableOpacity>
                            :
                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 2)}
                                              activeOpacity={theme.btnActiveOpacity}>
                                <View style={styles.intro}>
                                    <Image
                                        source={require('../image/default_header_img.png')}
                                        style={{width: px2dp(60), height: px2dp(60)}}>
                                    </Image>
                                    <View style={{marginLeft: px2dp(12)}}>
                                        <Text style={{color: theme.text.color, fontSize: px2dp(22)}}>立即登录</Text>
                                        <Text style={{color: "#999", fontSize: px2dp(12), marginTop: px2dp(5)}}
                                              numberOfLines={1}>登录后可保存你的摘抄</Text>
                                    </View>
                                    {/*<View style={{flexDirection: 'row', flex: 1, justifyContent: 'flex-end'}}>
                                        <Image source={require('../image/my_qrcode.png')}
                                               style={{width: px2dp(20), height: px2dp(20)}}/>
                                        <Image source={require('../image/more_icon.png')}
                                               style={{width: px2dp(16), height: px2dp(16), marginLeft: px2dp(5)}}/>
                                    </View>*/}
                                </View>
                            </TouchableOpacity>
                    }
                    <View style={{
                        flexDirection: 'row',
                        backgroundColor: 'white',
                        paddingBottom: px2dp(20),
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity style={{flex: 1}} onPress={this._onPressCallback.bind(this, 3)}
                                          activeOpacity={theme.btnActiveOpacity}>
                            <View style={{
                                flexDirection: 'column',
                                flex: 1,
                                backgroundColor: 'white',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                {
                                    this.state.isLogin ?
                                        <Text style={{color: 'black', fontSize: px2dp(18)}}
                                              numberOfLines={1}>{this.state.profit?(this.state.profit  / 100.0):0}</Text>
                                        : <Text
                                            style={{color: 'black', fontSize: px2dp(18)}}>0</Text>
                                }
                                <Text style={{color: '#999', fontSize: px2dp(12)}}>元</Text>
                            </View>
                        </TouchableOpacity>
                        <Text style={{backgroundColor: '#e4e4e4', width: px2dp(0.8), height: px2dp(30)}}/>
                        <TouchableOpacity style={{flex: 1}} onPress={this._onPressCallback.bind(this, 4)}
                                          activeOpacity={theme.btnActiveOpacity}>
                            <View style={{
                                flexDirection: 'column',
                                flex: 1,
                                backgroundColor: 'white',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                {
                                    this.state.isLogin ?
                                        <Text style={{
                                            color: 'black',
                                            fontSize: px2dp(18)
                                        }}>{this.state.kcoin?this.state.kcoin:0}</Text>
                                        : <Text
                                            style={{color: 'black', fontSize: px2dp(18)}}>0</Text>
                                }
                                <Text style={{color: '#999', fontSize: px2dp(12)}}>币/券</Text>
                            </View>
                        </TouchableOpacity>
                        <Text style={{backgroundColor: '#e4e4e4', width: px2dp(0.8), height: px2dp(30)}}/>
                        <View style={{
                            flexDirection: 'column',
                            flex: 1,
                            backgroundColor: 'white',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            {
                                this.state.isLogin ?
                                    <Text style={{
                                        color: 'black',
                                        fontSize: px2dp(18)
                                    }}>{this.state.marklistSubscribeNum?this.state.marklistSubscribeNum:0}</Text>
                                    : <Text
                                        style={{color: 'black', fontSize: px2dp(18)}}>0</Text>
                            }
                            <Text style={{color: '#999', fontSize: px2dp(12)}}>订阅数</Text>
                        </View>
                        <Text style={{backgroundColor: '#e4e4e4', width: px2dp(0.8), height: px2dp(30)}}/>
                        <TouchableOpacity style={{flex: 1}} onPress={this._onPressCallback.bind(this, 6)}
                                          activeOpacity={theme.btnActiveOpacity}>
                            <View style={{
                                flexDirection: 'column',
                                flex: 1,
                                backgroundColor: 'white',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                {
                                    this.state.isLogin ?
                                        <Text style={{
                                            color: 'black',
                                            fontSize: px2dp(18)
                                        }}>{this.state.fansCount?this.state.fansCount:0}</Text>
                                        : <Text
                                            style={{color: 'black', fontSize: px2dp(18)}}>0</Text>
                                }
                                <Text style={{color: '#999', fontSize: px2dp(12)}}>粉丝</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    {
                        this.state.isLogin ?
                            <View >
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'row',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(40)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的清单</Text>
                                    {
                                        this.state.marklists.length > 0 ?
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 8)}
                                                              activeOpacity={theme.btnActiveOpacity}>
                                                <Text style={{color: '#879dac', fontSize: px2dp(14)}}>+创建清单</Text>
                                            </TouchableOpacity>
                                            : null
                                    }
                                </View>
                                {
                                    this.state.marklists.length > 0 ?
                                        <View style={{
                                            marginTop: px2dp(10),
                                            marginLeft: px2dp(15),
                                            marginRight: px2dp(7)
                                        }}>
                                            <GridView
                                                itemsPerRow={3}
                                                renderFooter={null}
                                                onEndReached={null}
                                                scrollEnabled={false}
                                                renderSeparator={null}
                                                items={this.state.marklists}
                                                fillIncompleteRow={false}
                                                renderItem={this._renderMark.bind(this)}
                                                automaticallyAdjustContentInsets={false}/>
                                        </View>
                                        :
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 8)}
                                                          style={styles.addImg}
                                                          activeOpacity={theme.btnActiveOpacity}>
                                            <Image source={require('../image/add_icon.png')}
                                                   style={{width: px2dp(100), height: px2dp(100)}}/>
                                        </TouchableOpacity>
                                }
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'row',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(15)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的圈子</Text>
                                    {
                                        this.state.communities.length > 0 ?
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 9)}
                                                              activeOpacity={theme.btnActiveOpacity}>
                                                <Text style={{color: '#879dac', fontSize: px2dp(14)}}>+创建圈子</Text>
                                            </TouchableOpacity>
                                            : null
                                    }
                                </View>
                                {
                                    this.state.communities.length > 0 ?
                                        <View style={{
                                            marginTop: px2dp(10),
                                            marginLeft: px2dp(15),
                                            marginRight: px2dp(7)
                                        }}>
                                            <GridView
                                                itemsPerRow={3}
                                                renderFooter={null}
                                                onEndReached={null}
                                                scrollEnabled={false}
                                                renderSeparator={null}
                                                items={this.state.communities}
                                                fillIncompleteRow={false}
                                                renderItem={this._renderCircle.bind(this)}
                                                automaticallyAdjustContentInsets={false}/>
                                        </View>
                                        :
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 9)}
                                                          style={styles.addImg}
                                                          activeOpacity={theme.btnActiveOpacity}>
                                            <Image source={require('../image/add_icon.png')}
                                                   style={{width: px2dp(100), height: px2dp(100)}}/>
                                        </TouchableOpacity>
                                }
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'row',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(15)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的文章</Text>
                                    {
                                        this.state.articles.length > 0 ?
                                            <TouchableOpacity onPress={this._onPressCallback.bind(this, 10)}
                                                              activeOpacity={theme.btnActiveOpacity}>
                                                <Text style={{color: '#879dac', fontSize: px2dp(14)}}>+创建文章</Text>
                                            </TouchableOpacity>
                                            : null
                                    }
                                </View>
                                {
                                    this.state.articles.length > 0 ?
                                        <View style={{
                                            marginTop: px2dp(10),
                                            marginLeft: px2dp(15),
                                            marginRight: px2dp(7),
                                            marginBottom: px2dp(40)
                                        }}>
                                            <GridView
                                                itemsPerRow={3}
                                                renderFooter={null}
                                                onEndReached={null}
                                                scrollEnabled={false}
                                                renderSeparator={null}
                                                items={this.state.articles}
                                                fillIncompleteRow={false}
                                                renderItem={this._renderArticle.bind(this)}
                                                automaticallyAdjustContentInsets={false}/>
                                        </View>
                                        :
                                        <TouchableOpacity onPress={this._onPressCallback.bind(this, 10)} style={{
                                            width: px2dp(100),
                                            height: px2dp(100),
                                            marginTop: px2dp(10),
                                            marginLeft: px2dp(15),
                                            marginBottom: px2dp(40)
                                        }}
                                                          activeOpacity={theme.btnActiveOpacity}>
                                            <Image source={require('../image/add_icon.png')}
                                                   style={{width: px2dp(100), height: px2dp(100)}}/>
                                        </TouchableOpacity>

                                }
                            </View>
                            :
                            <View >
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'column',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(40)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的清单</Text>
                                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 8)}
                                                      activeOpacity={theme.btnActiveOpacity} style={{
                                        width: px2dp(100),
                                        height: px2dp(100),
                                        marginTop: px2dp(10)
                                    }}>
                                        <Image source={require('../image/add_icon.png')}
                                               style={{width: px2dp(100), height: px2dp(100)}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'column',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(40)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的圈子</Text>
                                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 9)}
                                                      activeOpacity={theme.btnActiveOpacity} style={{
                                        width: px2dp(100),
                                        height: px2dp(100),
                                        marginTop: px2dp(10)
                                    }}>
                                        <Image source={require('../image/add_icon.png')}
                                               style={{width: px2dp(100), height: px2dp(100)}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'column',
                                    paddingLeft: px2dp(15),
                                    paddingRight: px2dp(15),
                                    marginTop: px2dp(40),
                                    marginBottom: px2dp(40)
                                }}>
                                    <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的文章</Text>
                                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 10)}
                                                      activeOpacity={theme.btnActiveOpacity} style={{
                                        width: px2dp(100),
                                        height: px2dp(100),
                                        marginTop: px2dp(10)
                                    }}>
                                        <Image source={require('../image/add_icon.png')}
                                               style={{width: px2dp(100), height: px2dp(100)}}/>
                                    </TouchableOpacity>
                                </View>
                            </View>
                    }

                </ScrollView>
                <Toast ref={'toast'}/>
            </View>
        );
    }

    _onArticleItemClick(item) {
        if ('已发布' !== item.name) {
            NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/draftArticlePage');
            NativeModules.UxSDKModule.trackCustomKVEvent('me_alreadyReleased_click');
        } else {
            NativeModules.UxSDKModule.trackCustomKVEvent('me_draft_click');
            NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/myArticleListPage');
        }
    }

    _renderArticle(item) {
        return (
            <TouchableOpacity key={item.name} onPress={this._onArticleItemClick.bind(this, item)}
                              activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.gridviewItem}>
                    <CCCImage source={{uri: item.imgUrl.replace('/o/','/s240x240/')}} style={{
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        height: (Dimensions.get('window').width - px2dp(46)) / 3,
                        resizeMode: 'cover'
                    }}/>
                    <Text numberOfLines={1} style={{
                        color: '#444',
                        fontSize: px2dp(14),
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        marginTop: px2dp(10),
                        paddingLeft: px2dp(6)
                    }}>{item.name}</Text>
                    <Text numberOfLines={1} style={{
                        color: '#999',
                        fontSize: px2dp(11),
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        marginTop: px2dp(2),
                        paddingLeft: px2dp(6),
                        marginBottom: px2dp(10)
                    }}>{item.total<=0?0:item.total}篇</Text>
                </View>
            </TouchableOpacity>
        )
    }

    _onCircleClick(item) {
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/circleListPage?listId=" + item.listId + "&listType=1");
        });
    }

    _renderCircle(item) {
        return (
            <TouchableOpacity key={item.listId} onPress={this._onCircleClick.bind(this, item)}
                              activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.gridviewItem}>
                    <CCCImage
                        source={{uri: item.imgUrl.replace('/o/','/s240x240/')}}
                        style={{
                            width: (Dimensions.get('window').width - px2dp(46)) / 3,
                            height: (Dimensions.get('window').width - px2dp(46)) / 3,
                            resizeMode: 'cover'
                        }}
                    />
                    <Text numberOfLines={1} style={{
                        color: '#444',
                        fontSize: px2dp(14),
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        marginTop: px2dp(10),
                        paddingLeft: px2dp(6),
                        paddingRight: px2dp(6)
                    }}>{item.listName}</Text>
                    {
                        item.isPrivate === 1 ?
                            <Text numberOfLines={1} style={{
                                color: '#999',
                                fontSize: px2dp(11),
                                width: (Dimensions.get('window').width - px2dp(46)) / 3,
                                marginTop: px2dp(2),
                                paddingLeft: px2dp(6),
                                paddingRight: px2dp(6),
                                marginBottom: px2dp(10)
                            }}>私密</Text>
                            :
                            <Text numberOfLines={1} style={{
                                color: '#999',
                                fontSize: px2dp(11),
                                width: (Dimensions.get('window').width - px2dp(46)) / 3,
                                marginTop: px2dp(2),
                                paddingLeft: px2dp(6),
                                paddingRight: px2dp(6),
                                marginBottom: px2dp(10)
                            }}>{item.subscribeNum}订阅</Text>
                    }
                </View>
            </TouchableOpacity>
        )
    }

    _onMarkClick(item) {
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/inventoryListPage?listId=" + item.listId + "&listType=0");
        });
    }

    _renderMark(item) {
        return (
            <TouchableOpacity key={item.listId} onPress={this._onMarkClick.bind(this, item)}
                              activeOpacity={theme.btnActiveOpacity}>
                <View style={styles.gridviewItem}>
                    <CCCImage source={{uri: item.imgUrl.replace('/o/','/s240x240/')}} style={{
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        height: (Dimensions.get('window').width - px2dp(46)) / 3,
                        resizeMode: 'cover'
                    }}/>
                    <Text numberOfLines={1} style={{
                        color: '#444',
                        fontSize: px2dp(14),
                        width: (Dimensions.get('window').width - px2dp(46)) / 3,
                        marginTop: px2dp(10),
                        paddingLeft: px2dp(6),
                        paddingRight: px2dp(6)
                    }}>{item.listName}</Text>
                    {
                        item.isPrivate === 1 ?
                            <Text numberOfLines={1} style={{
                                color: '#999',
                                fontSize: px2dp(11),
                                width: (Dimensions.get('window').width - px2dp(46)) / 3,
                                marginTop: px2dp(2),
                                paddingLeft: px2dp(6),
                                paddingRight: px2dp(6),
                                marginBottom: px2dp(10)
                            }}>私密</Text>
                            :
                            <Text numberOfLines={1} style={{
                                color: '#999',
                                fontSize: px2dp(11),
                                width: (Dimensions.get('window').width - px2dp(46)) / 3,
                                marginTop: px2dp(2),
                                paddingLeft: px2dp(6),
                                paddingRight: px2dp(6),
                                marginBottom: px2dp(10)
                            }}>{item.subscribeNum}订阅</Text>
                    }
                </View>
            </TouchableOpacity>
        )
    }

    _fetchData() {
        let context = this;
        var url = APIService.myIndex;
        if (this.state.isLogin == false) {
            context.setState({refreshing:false});
            return;
        }

        HttpUtils.postForm(url, null, (data) => {
            context.setState({refreshing:false});
            if(data){
                if (data.ret === 0) {
                    Constants.openid = data.user.openid;
                    context.asSave(Constants.MINEINFO, data);
                    AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data.user), (error) => {
                        if (!error) {
                        }
                    });
                    context.setState({
                        dataBlob: data,
                        isLogin: true,
                        signature: data.user.signature,
                        memo: data.user.memo,
                        nickName: data.user.nickName,
                        iconUrl: data.user.iconUrl,
                        roles: data.user.roles,
                        profit: data.user.profit,
                        kcoin: data.user.kcoin,
                        fansCount: data.user.fansCount,
                        articles: data.articles,
                        communities: data.communities,
                        marklists: data.marklists,
                        totalCredit: data.user.totalCredit,
                        marklistSubscribeNum:data.user.marklistSubscribeNum
                    });
                } else {
                    context.refs.toast.show(data.msg, DURATION.LENGTH_SHORT);
                }
            }
        });

    }

    //保存数据
    asSave(key, data) {
        AsyncStorage.setItem(key, JSON.stringify(data), (error) => {
            if (!error) {

            }
        })
        NativeCacheUtils.saveUserInfoToNativeCache(data.user);
    }

    //查询保存的数据
    asQuery(key) {
        AsyncStorage.getItem(key, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    this.setState({
                        dataBlob: data,
                        articles: data.articles,
                        communities: data.communities,
                        marklists: data.marklists
                    });
                } else {
                    this.setState({
                        dataBlob: null,
                        articles: [],
                        communities: [],
                        marklists: [],
                        isRefreshing: false
                    });
                }
            }
        });
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    Constants.openid = data.openid;
                    this.setState({
                        signature: data.signature,
                        memo: data.memo,
                        nickName: data.nickName,
                        iconUrl: data.iconUrl,
                        roles: data.roles,
                        profit: data.profit,
                        kcoin: data.kcoin,
                        fansCount: data.fansCount,
                        totalCredit: data.totalCredit,
                        marklistSubscribeNum:data.marklistSubscribeNum
                    });
                } else {
                    Constants.openid = '';
                    this.setState({
                        nickName: '',
                        iconUrl: '',
                        signature: '',
                        memo: '',
                        profit: 0,
                        fansCount: 0,
                        totalCredit: 0,
                        kcoin: 0,
                        roles: '',
                        marklistSubscribeNum:0
                    });
                }
            }
        });
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    addImg: {
        width: px2dp(100), height: px2dp(100), marginTop: px2dp(10), marginLeft: px2dp(15), marginBottom: px2dp(25)
    },
    actionBar: {
        flexDirection: 'row',
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        justifyContent: 'center',
        borderBottomColor: '#ececec',
        borderBottomWidth: 1 / PixelRatio.get(),
        paddingTop: (Platform.OS == 'ios' ? px2dp(20) : 0)
    },
    gridviewItem: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        width: (Dimensions.get('window').width - px2dp(46)) / 3,
        marginRight: px2dp(8),
        marginBottom: px2dp(25)
    },
    intro: {
        height: px2dp(140),
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: px2dp(20),
        borderTopColor: '#e4e4e4',
    },
    list: {
        flex: 1,
        borderTopWidth: 1 / PixelRatio.get(),
        borderTopColor: '#e4e4e4',
        marginTop: px2dp(15)
    },
    listItem: {
        flex: 1,
        height: px2dp(47),
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: px2dp(25),
        paddingRight: px2dp(25),
        borderBottomColor: '#ececec',
        borderBottomWidth: 1 / PixelRatio.get()
    }
});
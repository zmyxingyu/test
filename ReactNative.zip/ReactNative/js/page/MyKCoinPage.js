/**
 * 我的阅读币页面
 * Created by yf on 2017/8/29.
 */
import React, {Component} from 'react';
import {
    Text,
    View,
    StyleSheet,
    Platform,Image,
    AsyncStorage,
    NativeEventEmitter,
    DeviceEventEmitter,
    PixelRatio,
    TouchableOpacity,
    ListView,
    ScrollView,
    NativeModules,
    Alert,
    InteractionManager
} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';
import DividingLine from  '../component/DividingLine';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import Toast, {DURATION} from 'react-native-easy-toast';
import APIService from '../config/APIService';
import CommonHeader from '../component/CommonHeader';
import FormatDateUtil from '../utils/FormatDateUtil';
const {MyCoinManager} = NativeModules;
const MyCoinManagerEmitter = new NativeEventEmitter(MyCoinManager);
import NativeCacheUtils from "../utils/NativeCacheUtils";

export default class MyKCoinPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataSource: new ListView.DataSource({
                rowHasChanged: (r1, r2) => r1 !== r2
            }),
            extraMoney: 0,
            dataBlob: [],
            quanBlob: [],
            openid: this.props.screenProps.openid,
        }
    }

    _handleClick(position) {
        switch (position) {
            case 0:
                NativeModules.CommonModule.showPayKcoinBottomDialog();
                break;
            case 1://更多
                this.props.navigation.navigate('PayRecordPage', {openid: this.state.openid});
                break;
            case 2://阅读券
                NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/discountPage');
                break;
        }
    }

    componentDidMount() {
        InteractionManager.runAfterInteractions(() => {
            this._fetchData();
            AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
                if (!error) {
                    if (result !== '' && result !== null) {
                        let data = JSON.parse((result));
                        this.setState({extraMoney: data.kcoin});
                    }
                }
            });
        });
        if (Platform.OS === 'ios') {
            this.myCoinEvent = MyCoinManagerEmitter.addListener('payKCoinBack', (response) => {
                if (response.isPaySuccess == 1) {
                    this.saveUserInfo(response.kcoin, response.profit);
                    this._fetchData();
                }
            });
        } else {
            this.myCoinEvent = DeviceEventEmitter.addListener('payKCoinBack', (response) => {
                if (response.isPaySuccess == 1) {
                    this.saveUserInfo(response.kcoin, response.profit);
                    this._fetchData();
                }
            });
        }
    }

    saveUserInfo(infoValue, profit) {
        NativeCacheUtils.saveUserInfoToNativeCache({openid:this.state.openid,kcoin:infoValue,profit:profit});
        this.setState({extraMoney: infoValue});
        //保存K币时会发送userInfoUpdate事件
        // AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
        //     if (!error) {
        //         if (result !== '' && result !== null) {
        //             let data = JSON.parse((result));
        //             let data2={
        //                 ...data,
        //                 kcoin:infoValue,
        //                 profit:profit,
        //             };
        //             // data.kcoin = infoValue;
        //             // data.profit = profit;
        //             AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data2), (error) => {
        //                 if (!error) {
        //                     // if (Platform.OS === 'ios') {
        //                     //     NativeModules.CommonModule.refreshMinePage();
        //                     // } else {
        //                     DeviceEventEmitter.emit('refreshMine');
        //                     // }
        //                     this.props.navigation.goBack();
        //                     AsyncStorage.getItem(Constants.USERINFO, () => {
        //                         console.log('result===>');
        //                         console.log(result);
        //                     });
        //                 }
        //             });
        //         }
        //     }
        // })
    }

    componentWillUnmount() {
        this.myCoinEvent.remove();
    }

    _fetchData() {
        if (this.state.openid !== '') {
            let context = this;
            let par = {
                'openid': this.state.openid,
                //'flag' : "0",
                'pageNo': "1",
                'pageSize': "4"
            };
            HttpUtils.doPost(APIService.coinRecord, par)
                .then(({data, error}) => {
                    if (data) {
                        if (data.ret === 0) {
                            if(data.list != null){
                                context.setState({
                                    dataBlob: data.list,
                                    dataSource: this.state.dataSource.cloneWithRows(data.list)
                                });
                            }
                        } else {
                            context.refs.toast.show(data.msg, DURATION.LENGTH_SHORT);
                        }
                    }
                });
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'充值阅读币'}
                    onBack={() => {
                        NativeModules.CommonModule.goBack();
                    }
                    }
                />
                <ScrollView style={styles.container}>
                    <View style={styles.container}>
                        <View style={{
                            marginTop: px2dp(15),
                            justifyContent: 'center',
                            alignItems: 'center',
                            backgroundColor: '#fff'
                        }}>
                            <Text
                                style={{fontSize: px2dp(14), color: '#999', marginTop: px2dp(20)}}>阅读币余额</Text>
                            <Text style={{
                                fontSize: px2dp(40),
                                color: '#ff5252',
                                marginTop: px2dp(6)
                            }}>{this.state.extraMoney}</Text>
                            <TouchableOpacity onPress={this._handleClick.bind(this, 0)}
                                              activeOpacity={theme.btnActiveOpacity} >
                                <View style={{width: px2dp(95),
                                    backgroundColor: '#fff',
                                    marginTop: px2dp(30),
                                    marginBottom: px2dp(27),
                                    borderRadius: px2dp(4),
                                    paddingTop: px2dp(7),
                                    justifyContent:'center',
                                    alignItems:'center',
                                    backgroundColor: '#ff5252',
                                    paddingBottom: px2dp(7)}}>
                                    <Text
                                        style={{
                                            width: px2dp(95),
                                            textAlign: 'center',
                                            fontSize: px2dp(14),
                                            color: '#fff'
                                        }}>充值阅读币</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleClick.bind(this,2)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#444', fontSize: px2dp(16)}}>阅读券</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Image source={require('../image/icon_right_b.png')} style={{width:px2dp(6),height:px2dp(10)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <View style={{flexDirection: 'row', marginTop: px2dp(30)}}>
                            <Text style={{
                                height: px2dp(20),
                                fontSize: px2dp(14),
                                flex: 1,
                                color: '#999',
                                marginLeft: px2dp(15)
                            }}>交易记录</Text>
                            <TouchableOpacity onPress={this._handleClick.bind(this, 1)}
                                              activeOpacity={theme.btnActiveOpacity}>
                                <View style={{justifyContent:'center',alignItems:'center',flexDirection:'row'}}>
                                    <Text style={{
                                        height: px2dp(20),
                                        fontSize: px2dp(14),
                                        color: '#999'
                                    }}>更多</Text>
                                    <Image source={require('../image/more_right.png')} style={{width:px2dp(6),height:px2dp(10),marginLeft:px2dp(6),marginRight: px2dp(15)}}/>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <ListView
                            style={{marginTop: px2dp(8)}}
                            enableEmptySections={true}
                            dataSource={this.state.dataSource}
                            renderRow={this._renderItem.bind(this)}
                        />
                        {/*<View style={{flexDirection:'row',marginTop:30}}>
                         <Text style={{height: 20,fontSize:px2dp(14),flex:1,color:'#999',marginLeft:15}}>优惠券</Text>
                         <Text style={{height: 20,fontSize:px2dp(14),color:'#999',marginRight:15}}>使用规则 ></Text>
                         </View>
                         <ListView
                         style={{marginTop:8}}
                         dataSource={this.state.dataSource}
                         renderRow={this._renderRoleItem.bind(this)}
                         />*/}
                    </View>
                </ScrollView>
                <Toast ref={'toast'}/>
            </View>
        )
    }

    _renderRoleItem(rowData, sectionID, rowID, highlightRow) {
        return (
            <View style={styles.roleitem}>
                <View style={{flexDirection: 'column', flex: 1}}>
                    <Text style={{fontSize: px2dp(16), color: '#444'}}>购买阅读币</Text>
                    <Text style={{fontSize: px2dp(14), color: '#999', marginTop: px2dp(4)}}>66</Text>
                </View>
                <Text style={{fontSize: px2dp(16), color: '#999'}}>失效</Text>
            </View>
        )
    }

    _renderItem(rowData, sectionID, rowID, highlightRow) {
        return (
            <View style={{flexDirection:'column'}}>
                <View style={styles.item}>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                        <Text style={{fontSize: px2dp(16), color: '#444', flex: 1}}>购买阅读币({rowData.kCoinAmount})</Text>
                        <Text style={{fontSize: px2dp(16), color: '#444'}}>¥{rowData.costMoney / 100.0}</Text>
                    </View>
                    <View style={{flexDirection: 'row', alignItems: 'center', marginTop: px2dp(4)}}>
                        <Text style={{fontSize: px2dp(14), color: '#999', flex: 1}}>付款：完成</Text>
                        <Text style={{
                            fontSize: px2dp(14),
                            color: '#999'
                        }}>{FormatDateUtil('yyyy-MM-dd', rowData.createTime)}</Text>
                    </View>
                </View>
                <DividingLine/>
            </View>
        )
    }

}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item: {
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        paddingTop: px2dp(12),
        paddingBottom: px2dp(12)
    },
    roleitem: {
        flexDirection: 'row',
        borderBottomColor: '#c4c4c4',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
        borderBottomWidth: 1 / PixelRatio.get(),
        paddingTop: px2dp(12),
        paddingBottom: px2dp(12)
    },
    listItem: {
        height: px2dp(55),
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: px2dp(15),
        paddingRight: px2dp(15),
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection: 'row'
    }
});
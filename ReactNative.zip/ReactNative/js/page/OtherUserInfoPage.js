/**
 * 用户资料页面
 * Created by yf on 2017/8/29.
 */
import React, {Component} from 'react';
import {
    Text, View, StyleSheet,TextInput, PixelRatio,ScrollView,NativeModules,TouchableOpacity,Image,DeviceEventEmitter,Keyboard,
} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import CommonHeaderText from '../component/CommonHeaderText';
import DividingLine from  '../component/DividingLine';
import APIService from '../config/APIService';
import getStringLen from '../utils/CommonUtils';

export default class OtherUserInfoPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            nickName:'',
            signature:'TA还没有填写简介',
            occupation:'TA还没有填写行业',
            job:'TA还没有填写职业',
            memo:'TA还没有认证',
            remarkName:'',
            targetOpenid:'',
            clickable:false,
            isConcern:true
        }
    }

    componentDidMount() {
        const {nickName,signature,occupation,job,memo,remarkName,targetOpenid,isConcern} = this.props.navigation.state.params;
        let clickable=false;
        if(remarkName==''||remarkName==null)
            clickable=false;
        else
            clickable=true;
        this.setState({isConcern:isConcern,targetOpenid:targetOpenid,nickName:nickName,signature:signature,occupation:occupation,job:job,memo:memo,remarkName:remarkName,clickable:clickable});
    }

    _handleItemClick(position){
        switch (position){
            case 0:
                if (!this.state.remarkName || this.state.remarkName === '') {
                    this.refs.toast.show('备注名称不能为空！', DURATION.LENGTH_SHORT);
                    return;
                } else if (!Constants.NAME_REGEX.test(this.state.remarkName)) {
                    this.refs.toast.show('备注名称应为中英文、数字和下划线', DURATION.LENGTH_LONG);
                    return;
                } else if (getStringLen(this.state.remarkName) < 4 || getStringLen(this.state.remarkName) > 16) {
                    this.refs.toast.show('备注名称应为2-8个汉字或4-16个字母', DURATION.LENGTH_LONG);
                    return;
                }
                NativeModules.CommonModule.showRNLoadingProgress(Constants.waitInfo);
                let context = this;
                var url = APIService.updateRemarkName;
                let par = {
                    'openid' : this.props.navigation.state.params.openid,
                    'targetOpenid' : this.state.targetOpenid,
                    'remarkName' : this.state.remarkName,
                    'timestamp':new Date().getTime()
                };
                HttpUtils.doPost(url, par)
                    .then(({data, error}) => {
                        NativeModules.CommonModule.dismissRNLoadingProgress();
                        if (data.ret==0) {
                            DeviceEventEmitter.emit('setRemark',context.state.remarkName);
                            this.props.navigation.goBack();
                        } else {
                            context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                        }
                    });
                break;
            case 1:
                this.setState({remarkName:'',clickable:false});
                break;
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeaderText
                    title={'资料'}
                    onBack={() => {
                        Keyboard.dismiss();
                        this.props.navigation.goBack();
                    }
                    }
                    clickable={this.state.clickable}
                    rightName={this.state.isConcern?'确定':''}
                    onSubmit={() => {
                        Keyboard.dismiss();
                        this._handleItemClick(0);
                    }}
                />
                <ScrollView style={styles.container}>
                    <View style={{flexDirection:'row',paddingLeft:px2dp(10),paddingRight:px2dp(10),
                        backgroundColor:'#fff',height:px2dp(50),marginTop:px2dp(15),alignItems:'center'}}>
                        <Text style={{color: '#444', fontSize: px2dp(16)}}>昵称</Text>
                        <Text style={{color: '#444', fontSize: px2dp(16),marginLeft:px2dp(10)}}>{this.state.nickName}</Text>
                    </View>
                    {
                        this.state.isConcern?
                            <View style={{alignItems:'center',height: px2dp(50),marginTop:px2dp(15),flexDirection:'row',backgroundColor:'white',paddingRight:px2dp(10)}}>
                                <TextInput placeholder={'设置备注名'} value={this.state.remarkName} numberOfLines={1} placeholderTextColor={'#999'} underlineColorAndroid={'transparent'}
                                           style={{fontSize:px2dp(16),color:'#444',flex:1,paddingLeft:px2dp(10),paddingRight:px2dp(10),backgroundColor:'white'}}
                                           onChangeText={(text) => {
                                               this.setState({remarkName:text});
                                               if(text != '' && text != null){
                                                   this.setState({clickable:true});
                                               }else{
                                                   this.setState({clickable:false});
                                               }
                                           }}/>
                                {
                                    this.state.clickable?
                                        <TouchableOpacity onPress={this._handleItemClick.bind(this,1)} activeOpacity={theme.btnActiveOpacity}>
                                            <Image source={require('../image/icon_delete.png')} style={{width:px2dp(20),height:px2dp(20)}}/>
                                        </TouchableOpacity>:null
                                }
                            </View>
                            :null
                    }
                    <View style={{marginTop:px2dp(15)}}>
                        <View style={styles.item}>
                            <Text style={{color: '#444', fontSize: px2dp(16)}}>简介</Text>
                            <Text style={{color: '#444', fontSize: px2dp(16),marginLeft:px2dp(10),flex:1}} >{this.state.signature}</Text>
                        </View>
                        <DividingLine/>
                        <View style={styles.item}>
                            <Text style={{color: '#444', fontSize: px2dp(16)}}>行业</Text>
                            <Text style={{color: '#444', fontSize: px2dp(16),marginLeft:px2dp(10),flex:1}}>{this.state.occupation}</Text>
                        </View>
                        <DividingLine/>
                        <View style={styles.item}>
                            <Text style={{color: '#444', fontSize: px2dp(16)}}>职业</Text>
                            <Text style={{color: '#444', fontSize: px2dp(16),marginLeft:px2dp(10),flex:1}}>{this.state.job}</Text>
                        </View>
                        <DividingLine/>
                        <View style={styles.item}>
                            <Text style={{color: '#444', fontSize: px2dp(16)}}>认证</Text>
                            <Text style={{color: '#444', fontSize: px2dp(16),marginLeft:px2dp(10),flex:1}}>{this.state.memo}</Text>
                        </View>
                    </View>
                </ScrollView>
                <Toast ref={'toast'} position={'center'}/>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        flexDirection:'row',
        backgroundColor:'#fff',
        minHeight:px2dp(50),
        padding:px2dp(10),
        paddingRight:px2dp(10),
        alignItems:'center'
    }
});
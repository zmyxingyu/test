/**
 * 我的K币页面
 * Created by yf on 2017/8/29.
 */
import React, {Component} from 'react';
import {
    Text, View, StyleSheet,Platform, Image,DeviceEventEmitter, PixelRatio,TouchableOpacity,ListView, ScrollView,NativeModules,Alert,InteractionManager
} from 'react-native';
import theme from '../utils/theme';
import px2dp from '../utils/px2dp';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import APIService from '../config/APIService';
import CommonHeader from '../component/CommonHeader';
import DividingLine from '../component/DividingLine';
import CCCFlatList from '../component/CCCFlatList';
import FormatDateUtil from '../utils/FormatDateUtil';

export default class PayRecordPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataSource: new ListView.DataSource({
                rowHasChanged: (r1, r2) => r1 !== r2
            }),
            firstLoader: true,
            openid:this.props.navigation.state.params.openid,
            noData:false
        }
    }

    render()
    {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'交易记录'}
                    onBack={() => {
                        this.props.navigation.goBack();
                    }
                    }
                />
                <DividingLine/>
                {
                    this.state.noData?
                        <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(70)}}>
                            <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                            <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(17)}}>暂无交易记录</Text>
                        </View>
                        :
                        <CCCFlatList
                            ref={(ref) => this.recordList = ref}
                            onFetch={this.onFetch.bind(this)}
                            firstLoader={this.state.firstLoader}
                            item={this.renderItemComponent}
                        />
                }
                <Toast ref={'toast'}/>
            </View>
        )
    }

    renderItemComponent = (rowData, index) => {
        return (
            <View>
                <View style={styles.item}>
                    <View style={{flexDirection:'row',alignItems:'center'}}>
                        <Text style={{fontSize:px2dp(16),color:'#444',flex:1}}>购买阅读币({rowData.kCoinAmount})</Text>
                        <Text style={{fontSize:px2dp(16),color:'#444'}}>¥{rowData.costMoney/100.0}</Text>
                    </View>
                    <View style={{flexDirection:'row',alignItems:'center',marginTop:px2dp(4)}}>
                        <Text style={{fontSize:px2dp(14),color:'#999',flex:1}}>付款：完成</Text>
                        <Text style={{fontSize:px2dp(14),color:'#999'}}>{FormatDateUtil('yyyy-MM-dd',rowData.createTime)}</Text>
                    </View>

                </View>
                <DividingLine/>
            </View>
        )
    }

    onFetch = async (page, startFetch, abortFetch) => {
        if(this.state.openid !== ''){
            let context = this;
            let par = {
                'openid' : this.state.openid,
                'pageNo':page+'',
                'pageSize':"20"
            };
            HttpUtils.doPost(APIService.coinRecord, par)
                .then(({data, error}) => {
                    if (data) {
                        if(data.list==null || (data.list.length==0 && page == 1)){
                            context.setState({noData:true});
                        }else{
                            startFetch(data.list, 20);
                        }
                    } else {
                        context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
                        abortFetch();
                    }
                });
        }
    };
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        flexDirection:'column',alignItems:'center',backgroundColor:'white',paddingLeft:px2dp(15),paddingRight:px2dp(15),
        paddingTop:px2dp(12),paddingBottom:px2dp(12)
    },
    roleitem:{
        flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',paddingLeft:px2dp(15),paddingRight:px2dp(15),
        borderBottomWidth: 1/PixelRatio.get(),paddingTop:px2dp(12),paddingBottom:px2dp(12)
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row'
    }
});
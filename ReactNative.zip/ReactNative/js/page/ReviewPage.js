import React, {Component,PropTypes} from 'react';
import {
    StyleSheet,
    View,
    Text,PixelRatio,
    TouchableOpacity,Image,
    NativeModules,AsyncStorage,
    Platform
} from 'react-native';
import CommonHeader from '../component/CommonHeader';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';

export default class ReviewPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listName: '',
            listType:0
        }
    }

    componentDidMount() {
        const {listName,listType} = this.props.navigation.state.params;
        this.setState({listName:listName,listType:listType});
    }

    _handleItemClick(position){
        NativeModules.CommonModule.goBack();
    }

    render()
    {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={''}
                    onBack={() => {
                        this.props.navigation.goBack();
                    }
                    }
                    clickable={false}
                    rightName={''}
                />
                <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(70)}}>
                    <Image source={require('../image/icon_shenhe.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                    <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>添加『{this.state.listName}』{this.state.listType==1?'圈子':'清单'}申请已提交</Text>
                    <Text style={{color: '#999', fontSize: px2dp(14),marginTop:px2dp(8)}}>预计7个工作日完成审核</Text>
                    <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity}
                                      style={{justifyContent:'center',alignItems:'center'}}>
                        <View style={{marginTop:px2dp(60),borderRadius:px2dp(4),justifyContent:'center',alignItems:'center',borderColor:'#ff5252',borderWidth:px2dp(1),height:px2dp(44),width:px2dp(138)}}>
                            <Text style={{color: '#ff5252',textAlign:'center',fontSize: px2dp(17)}}>查看{this.state.listType==1?'圈子':'清单'}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        height: px2dp(50),flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',
        borderBottomWidth: 1/PixelRatio.get(),borderTopColor: '#c4c4c4',borderTopWidth: 1/PixelRatio.get()
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row',
        paddingTop: (Platform.OS === 'ios') ? px2dp(20) : 0,
    }
});
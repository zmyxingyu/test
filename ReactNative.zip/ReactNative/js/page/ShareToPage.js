/**
 * 添加圈子的页面
 * Created by yf on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    Text, View, StyleSheet,Image, RefreshControl,NativeModules,NativeEventEmitter,DeviceEventEmitter,Linking, PixelRatio, TouchableOpacity, Dimensions,InteractionManager,ScrollView,AsyncStorage,
    Platform,
} from 'react-native';
import px2dp from '../utils/px2dp';
import URLUtils from '../utils/URLUtils';
import theme from '../utils/theme';
import CommonHeader from  '../component/CommonHeaderText';
import Constants from '../config/Constants';
import GridView from 'rn-grid-view';
import CCCImage from '../component/CCCImage';
import HttpUtils from '../utils/HttpUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import APIService from "../config/APIService";
const {MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
export default class ShareToPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            articles:[],
            communities:[],
            marklists:[],
            refreshing:true,
            type: this.props.listType,//0清单   1圈子
            listId: this.props.listId,
            listName:'',
            title:'',
            topRightClickable:false,
            markId:this.props.markId//摘抄ID
        }
    }

    _onRefresh() {
        this.setState({refreshing: true});
        this._fetchData(this.state.listId,this.state.type);
    }

    render() {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={this.state.title}
                    onBack={() => {
                        NativeModules.CommonModule.goBack();
                    }
                    }
                    clickable={this.state.topRightClickable}
                    rightName={'确定'}
                    onSubmit={() => {
                        this._onPressCallback(2);
                    }}
                />
                <ScrollView style={styles.container}
                            refreshControl={
                                <RefreshControl
                                    refreshing={this.state.refreshing}
                                    onRefresh={this._onRefresh.bind(this)}
                                    colors={['red', '#ffd500', '#0080ff', '#99e600']}
                                />
                            }>
                    <View >
                        <View style={{flex:1,flexDirection:'row',paddingLeft:px2dp(15),paddingRight:px2dp(15),marginTop:px2dp(15)}}>
                            <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的清单</Text>
                            {
                                this.state.marklists.length>0?
                                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 0)}  activeOpacity={theme.btnActiveOpacity}>
                                        <Text style={{color: '#879dac', fontSize: px2dp(14)}}>+创建清单</Text>
                                    </TouchableOpacity>
                                    :null
                            }
                        </View>
                        {
                            this.state.marklists.length>0?
                                <View  style={{marginTop: px2dp(10),marginLeft:px2dp(15),marginRight:px2dp(7)}}>
                                    <GridView
                                        itemsPerRow={3}
                                        renderFooter={null}
                                        onEndReached={null}
                                        scrollEnabled={false}
                                        renderSeparator={null}
                                        items={this.state.marklists}
                                        fillIncompleteRow={false}
                                        renderItem={this._renderMark.bind(this)}
                                        automaticallyAdjustContentInsets={false} />
                                </View>
                                :
                                <TouchableOpacity onPress={this._onPressCallback.bind(this, 0)}  style={styles.addImg}
                                                  activeOpacity={theme.btnActiveOpacity}>
                                    <Image source={require('../image/add_icon.png')}
                                           style={{width: px2dp(100), height: px2dp(100)}}/>
                                </TouchableOpacity>
                        }
                        <View style={{flex:1,flexDirection:'row',paddingLeft:px2dp(15),paddingRight:px2dp(15),marginTop:px2dp(15)}}>
                            <Text style={{color: '#222', fontSize: px2dp(14), flex: 1}}>我的圈子</Text>
                            {
                                this.state.communities.length>0?
                                    <TouchableOpacity onPress={this._onPressCallback.bind(this, 1)} activeOpacity={theme.btnActiveOpacity}>
                                        <Text style={{color: '#879dac', fontSize: px2dp(14)}}>+创建圈子</Text>
                                    </TouchableOpacity>
                                    :null
                            }
                        </View>
                        {
                            this.state.communities.length>0?
                                <View  style={{marginTop: px2dp(10),marginLeft:px2dp(15),marginRight:px2dp(7)}}>
                                    <GridView
                                        itemsPerRow={3}
                                        renderFooter={null}
                                        onEndReached={null}
                                        scrollEnabled={false}
                                        renderSeparator={null}
                                        items={this.state.communities}
                                        fillIncompleteRow={false}
                                        renderItem={this._renderCircle.bind(this)}
                                        automaticallyAdjustContentInsets={false} />
                                </View>
                                :
                                <TouchableOpacity onPress={this._onPressCallback.bind(this, 1)}  style={styles.addImg}
                                                  activeOpacity={theme.btnActiveOpacity}>
                                    <Image source={require('../image/add_icon.png')}
                                           style={{width: px2dp(100), height: px2dp(100)}}/>
                                </TouchableOpacity>
                        }
                    </View>
                </ScrollView>
                <Toast ref={'toast'} position={'center'}/>
            </View>
        )
    }

    _onCircleClick(item,position){
        switch (position){
            case 0:
                /*InteractionManager.runAfterInteractions(() => {
                 NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/circlePage?listId="+item.listId+"&listType=1");
                 });*/
                break;
            case 1:
                this.setState({type:1,listId:item.listId,listName:item.listName,topRightClickable:true});
                break;
        }
    }

    _renderCircle(item){
        return (
            <View key={item.listId}>
                <TouchableOpacity onPress={this._onCircleClick.bind(this, item,1)} activeOpacity={theme.btnActiveOpacity} >
                    <View style={styles.gridviewItem}>
                        <CCCImage source={{uri:item.imgUrl.replace('/o/','/s240x240/')}} style={{width:(Dimensions.get('window').width-px2dp(46))/3,height:(Dimensions.get('window').width - px2dp(46)) / 3,resizeMode:'cover'}} />
                        <Text numberOfLines={1} style={{color: '#444', fontSize: px2dp(14),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(10),paddingLeft: px2dp(6),
                            paddingRight: px2dp(6)}}>{item.listName}</Text>
                        {
                            item.isPrivate===1?
                                <Text numberOfLines={1} style={{color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft: px2dp(6),
                                    paddingRight: px2dp(6),marginBottom:px2dp(10)}}>私密</Text>
                                :
                                <Text numberOfLines={1} style={{color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft: px2dp(6),
                                    paddingRight: px2dp(6),marginBottom:px2dp(10)}}>{item.subscribeNum}订阅</Text>
                        }
                    </View>
                    <View style={styles.checkBox} >
                        {
                            (this.state.type==1&&this.state.listId==item.listId)?<Image source={require("../image/red_check_box.png")} style={{width:px2dp(26),height:px2dp(26)}}/>
                                :<Image source={require("../image/hint_check_box.png")} style={{width:px2dp(26),height:px2dp(26)}}/>
                        }
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _onMarkClick(item,position){
        switch (position){
            case 0:
                /*InteractionManager.runAfterInteractions(() => {
                 NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/circlePage?listId="+item.listId+"&listType=0");
                 });*/
                break;
            case 1:
                this.setState({type:0,listId:item.listId,listName:item.listName,topRightClickable:true});
                break;
        }
    }

    _renderMark(item){
        return (
            <View key={item.listId} >
                <TouchableOpacity onPress={this._onMarkClick.bind(this, item,1)} activeOpacity={theme.btnActiveOpacity} >
                    <View  style={styles.gridviewItem}>
                        <CCCImage source={{uri:item.imgUrl.replace('/o/','/s240x240/')}} style={{width:(Dimensions.get('window').width-px2dp(46))/3,height:(Dimensions.get('window').width - px2dp(46)) / 3,resizeMode:'cover'}} />
                        <Text numberOfLines={1} style={{color: '#444', fontSize: px2dp(14),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(10),paddingLeft: px2dp(6),
                            paddingRight: px2dp(6)}}>{item.listName}</Text>
                        {
                            item.isPrivate===1?
                                <Text numberOfLines={1} style={{color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft: px2dp(6),
                                    paddingRight: px2dp(6),marginBottom:px2dp(10)}}>私密</Text>
                                :
                                <Text numberOfLines={1} style={{color: '#999', fontSize: px2dp(11),width:(Dimensions.get('window').width-px2dp(46))/3,marginTop:px2dp(2),paddingLeft: px2dp(6),
                                    paddingRight: px2dp(6),marginBottom:px2dp(10)}}>{item.subscribeNum}订阅</Text>
                        }
                    </View>
                    <View style={styles.checkBox} >
                        {
                            (this.state.type==0&&this.state.listId==item.listId)?<Image source={require("../image/red_check_box.png")} style={{width:px2dp(26),height:px2dp(26)}}/>
                                :<Image source={require("../image/hint_check_box.png")} style={{width:px2dp(26),height:px2dp(26)}}/>
                        }
                    </View>
                </TouchableOpacity>
            </View>
        )
    }

    _onPressCallback(position){
        switch (position){
            case 0:
                NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/addMarkPage');
                break;
            case 1:
                NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/addCirclePage');
                break;
            case 2:
                NativeModules.CommonModule.sendChooseMarkEvent(this.state.listId,this.state.listName,this.state.type,this.state.markId);
                NativeModules.CommonModule.goBack();
                break;
        }
    }

    componentDidMount() {
        if (Platform.OS === 'ios') {
            this.refreshEvent = MineManagerEmitter.addListener('refreshMine', () => {
                this.asQuery(Constants.MINEINFO,this.state.listId, this.state.type);
            });
            Linking.getInitialURL().then((url) => {
                const result = URLUtils.parseQueryString(url);
                if (result !== '' && result !== null && result.markList && result.markList !== '') {
                    //this.doResult(result.markList);
                    this._fetchData(-1, -1);
                } else if (result !== '' && result !== null && result.listId) {
                    if (result.markId)
                        this.setState({markId: result.markId});
                    this._fetchData(result.listId, result.listType);
                    //this.asQuery(Constants.MINEINFO,result.listId,result.listType);
                } else {
                    //this.asQuery(Constants.MINEINFO,-1,-1);
                    this._fetchData(-1, -1);
                }
            }).catch(err => console.error('An error occurred', err));
        } else {
            InteractionManager.runAfterInteractions(() => {
                if (this.state.listId && this.state.listId !== '') {
                    this._fetchData(this.state.listId, this.state.type);
                } else {
                    this._fetchData(-1, -1);
                }
            });
        }

        this.refreshEvent = DeviceEventEmitter.addListener('refreshMine',()=>{
            this.asQuery(Constants.MINEINFO,this.state.listId, this.state.type);
        });
    }

    componentWillUnmount(){
        this.refreshEvent.remove();
    };

    _fetchData(mListId,mListType) {
        //NativeModules.CommonModule.showRNLoadingProgress('请稍等...');
        let context = this;
        var url = APIService.markList;
        let par = {
            'openid' : this.props.openid,
            'listOperate' : '1'
        };
        HttpUtils.postForm(url,par,function (result) {
            //NativeModules.CommonModule.dismissRNLoadingProgress();
            if(result.ret === 0){
                context.doResult(result.list,mListId,mListType);
            }else{
                context.setState({refreshing:false});
                context.refs.toast.show(result.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    doResult(data,mListId,mListType){
        let marklists=new Array();
        let communities=new Array();
        let listId='';
        let listName='';
        let title="添加至";
        let type=0;
        for(let i in data){
            if(this.state.markId){
                if(mListType==1){
                    type=1;
                }else if(mListType==0){
                    type=0;
                }
                title="移动摘抄";
            }
            if(mListId==data[i].listId){
                listId=data[i].listId;
                listName=data[i].listName;
                type=data[i].listType;
            }
            if(data[i].listType==1){
                communities.push(data[i]);
            }else{
                marklists.push(data[i]);
            }
        }
        /*默认选中第一个
        if(mListId==-1){
            if(marklists.length>0){
                listId=marklists[0].listId;
                listName=marklists[0].listName;
                type=0;
            }else if(communities.length>0){
                listId=communities[0].listId;
                listName=communities[0].listName;
                type=1;
            }
        }*/
        this.setState({
            title:title,
            type:type,
            refreshing:false,
            listId:listId,
            topRightClickable:listId==''?false:true,
            listName:listName,
            communities:communities,
            marklists:marklists
        });
    }

    //查询保存的数据
    asQuery(key,mListId,listType) {
        AsyncStorage.getItem(key, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    let listId='';
                    let listName='';
                    let title="添加至";
                    let type;
                    if(listType==1){//圈子
                        for(let i in data.communities){
                            if(mListId==data.communities[i].listId){
                                listId=data.communities[i].listId;
                                listName=data.communities[i].listName;
                            }
                        }
                        type=1;
                        title="移动摘抄";
                    }else if(listType==0){//清单
                        for(let i in data.marklists){
                            if(mListId==data.marklists[i].listId){
                                listId=data.marklists[i].listId;
                                listName=data.marklists[i].listName;
                            }
                        }
                        type=0;
                        title="移动摘抄";
                    }else{
                        if(data.marklists.length>0){
                            listId=data.marklists[0].listId;
                            listName=data.marklists[0].listName;
                            type=0;
                        }else if(data.communities.length>0){
                            listId=data.communities[0].listId;
                            listName=data.communities[0].listName;
                            type=1;
                        }
                    }
                    this.setState({
                        type:type,
                        title:title,
                        listId:listId,
                        listName:listName,
                        articles:data.articles,
                        communities:data.communities,
                        marklists:data.marklists
                    });
                }else{
                    this.setState({
                        articles:[],
                        communities:[],
                        marklists:[]
                    });
                }
            }
        });
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    Constants.openid = data.openid;
                }
            }
        });
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        height: px2dp(50),flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',
        borderBottomWidth: 1/PixelRatio.get(),borderTopColor: '#c4c4c4',borderTopWidth: 1/PixelRatio.get()
    },
    checkBox:{
        position:'absolute',marginLeft:((Dimensions.get('window').width-px2dp(46))/3-px2dp(31)),marginTop:px2dp(5)
    },
    gridviewItem: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        width:(Dimensions.get('window').width-px2dp(46))/3,
        marginRight:px2dp(8),
        marginBottom:px2dp(25)
    },
    addImg: {
        width: px2dp(100), height: px2dp(100), marginTop: px2dp(10),marginLeft:px2dp(15),marginBottom:px2dp(25)
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row'
    }
});
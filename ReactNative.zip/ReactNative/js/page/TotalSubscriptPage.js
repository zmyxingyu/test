/**
 * 订阅总数页面
 * Created by yf on 2017/11/17.
 */
import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    Text,
    Image,InteractionManager,
    TouchableOpacity,
    NativeModules
} from 'react-native';
import DividingLine from '../component/DividingLine';
import CCCFlatList from '../component/CCCFlatList';
import CommonHeader from '../component/CommonHeader';
import APIService from '../config/APIService';
import ScreenUtils from '../utils/ScreenUtils';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import HttpUtils from '../utils/HttpUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import CCCImage from '../component/CCCImage';
import NetworkErrorView from '../component/NetworkErrorView';
import FormatDateUtil from '../utils/FormatDateUtil';

export default class TotalSubscriptPage extends Component{

    constructor(props){
        super(props);
        const {openid, listId} = this.props.navigation.state.params;
        this.state={
            dataBlob:[],
            firstLoader:true,
            noNet:false,
            openid:openid,
            listId:listId,
            index:-1,
            noData:false,
        };
    }

    _handleItemClick(position){
        switch (position){
            case 1:
                this.setState({noNet:false,noData:false});
                break;
        }
    }

    render(){
        if(this.state.openid == ''){
            return(
                <View style={styles.container}>
                    <CommonHeader
                        title={'累计订阅人数'}
                        onBack={() => {
                            this.props.navigation.goBack();
                        }
                        }
                    />
                    <DividingLine/>
                </View>
            )
        }else{
            return(
                <View style={styles.container}>
                    <CommonHeader
                        title={'订阅人员列表'}
                        onBack={() => {
                            this.props.navigation.goBack();
                        }
                        }
                    />
                    <DividingLine/>
                    {
                        this.state.noNet?
                            <NetworkErrorView  ref={'errorView'} onPress={this._handleItemClick.bind(this,1)}/>
                            :
                            (this.state.noData?
                                <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',marginTop:px2dp(70)}}>
                                    <Image source={require('../image/icon_null.png')} style={{width: px2dp(140),height: px2dp(140),resizeMode: 'cover'}}/>
                                    <Text style={{color: '#6f6f6f', fontSize: px2dp(17),marginTop:px2dp(20)}}>暂无订阅人数</Text>
                                </View>
                                :
                                <CCCFlatList
                                    ref={(ref) => this.draftList = ref}
                                    onFetch={this.onFetch.bind(this)}
                                    firstLoader={this.state.firstLoader}
                                    item={this.renderItemComponent}
                                />)
                    }
                </View>
            )
        }
    }

    _onItemClick(item){
        InteractionManager.runAfterInteractions(() => {
            NativeModules.IntentFromJsModule.openPageFromJS('kanjian://RNApp/followPage?otherOpenid=' + item.openid);
        });
    }

    renderItemComponent = (item, index) => {
        return (
            <TouchableOpacity key={item.listId} onPress={this._onItemClick.bind(this, item)} activeOpacity={theme.btnActiveOpacity} >
                <View style={{flexDirection: 'column'}}>
                    <View style={styles.item}>
                        <CCCImage source={{uri:item.iconUrl.replace('/o/','/s240x240/')}} style={styles.avatar} />
                        <View style={styles.midLayout}>
                            <Text style={styles.nameText} numberOfLines={1}>{item.nickName}</Text>
                            <Text style={styles.contributeText} numberOfLines={1}>{`订阅时间：${FormatDateUtil('yyyy-MM-dd', item.createTime)}`}</Text>
                        </View>
                    </View>
                    <DividingLine/>
                </View>
            </TouchableOpacity>
        );
    };

    onFetch = async (page, startFetch, abortFetch) => {
        if (this.state.openid !== '') {
            let context = this;
            let par = {
                openid: this.state.openid,
                listId: this.state.listId,
                pageNo: page + '',
                pageSize: 10 + ''
            };
            HttpUtils.doPost(APIService.subscribers, par)
                .then(({data, error}) => {
                    if (data) {
                        if (data.list.length == 0 && page == 1) {
                            context.setState({noData: true});
                        } else {
                            startFetch(data.list, 10);
                        }
                    } else {
                        this.setState({noNet: true});
                        context.refs.toast.show(data.msg, DURATION.LENGTH_SHORT);
                        abortFetch();
                    }
                });
        }
    };

}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    midLayout: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginLeft: px2dp(8),
    },
    nameText: {
        fontSize: px2dp(16),
        marginLeft: px2dp(8),
        color: '#444444',
    },
    item: {
        flexDirection: 'row',
        height: px2dp(62),
        paddingLeft:px2dp(15),
        alignItems: 'center',
        backgroundColor: 'white',
    },
    avatar: {
        width: px2dp(40),
        height: px2dp(40),
        backgroundColor:'#fff',
        borderRadius: px2dp(40) / 2,
    },
    contributeText: {
        fontSize: px2dp(12),
        marginLeft: px2dp(8),
        color: '#999999',
        textAlign: 'right',
    },
    circleInviteItem: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    invitePeopleImg: {
        width: px2dp(16),
        height: px2dp(16),
    },
    circleInviteText: {
        fontSize: px2dp(16),
        color: '#879DAC',
        marginLeft: px2dp(6),
    },
});
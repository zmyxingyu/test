/**
 * 修改行业页面
 * Created by yf on 2017/8/29.
 */
import React, {Component,PropTypes} from 'react';
import {
    StyleSheet,
    View,
    Text,
    ListView,DeviceEventEmitter,PixelRatio,
    TouchableOpacity,Image,
    NativeModules,AsyncStorage,
    Platform
} from 'react-native';
import CommonHeader from '../component/CommonHeader';
import Constants from '../config/Constants';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import HttpUtils from '../utils/HttpUtils';
import APIService from '../config/APIService';
import Toast,{DURATION} from 'react-native-easy-toast';
import NativeCacheUtils from "../utils/NativeCacheUtils";

const {CommonModule} = NativeModules;
export default class UpdateAgePage extends Component{

    constructor(props){
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: (r1, r2) => r1 !== r2
        });
        this.state = {
            dataSource: ds.cloneWithRows([]),
            dataBlob:[]
        }
    }

    saveUserInfo(name,infoValue) {
        const {goBack, state} = this.props.navigation;
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    if(name == 'age'){
                        data.age=infoValue;
                        // NativeModules.CommonModule.saveUserInfoFromRN('age',infoValue);
                        NativeCacheUtils.saveUserInfoToNativeCache({age: infoValue + ''});
                    }
                    AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data), (error) => {
                        if (!error) {
                            // if (Platform.OS === 'ios') {
                            //     CommonModule.refreshMinePage();
                            // } else {
                            //     DeviceEventEmitter.emit('refreshMine');
                            // }
                            //参数回传
                            state.params.callback({age: infoValue});
                            goBack();
                        }
                    });
                }
            }
        })
    }

    componentDidMount() {
        const {content} = this.props.navigation.state.params;
        this.setState({dataSource: this.state.dataSource.cloneWithRows(content),dataBlob:content});
    }

    static propTypes = {
        contents: PropTypes.array
    };

    _fetchData(infoType,infoValue) {
        NativeModules.CommonModule.showRNLoadingProgress(Constants.waitInfo);
        let context = this;
        var url = APIService.updateUserInfo;
        let par = {
            'openid' : this.props.navigation.state.params.openid,
            'infoType' : infoType,
            'infoValue' : infoValue+"",
            'timestamp':new Date().getTime()
        };
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            if(data.ret === 0){
                context.saveUserInfo('age',infoValue);
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    _itemClickCallback(rowData,rowID){
        let occ=[];
        for(let i in this.state.dataBlob){
            if(rowData.title == this.state.dataBlob[i].title){
                this.state.dataBlob[i].isCkecked=true;
            }else
                this.state.dataBlob[i].isCkecked=false;
            let p={
                title:this.state.dataBlob[i].title,
                isCkecked:this.state.dataBlob[i].isCkecked
            }
            occ.push(p);
        }
        this.setState({dataSource: this.state.dataSource.cloneWithRows(occ)});
        this._fetchData('age',rowData.title);
    }

    _renderItem(rowData, sectionID, rowID, highlightRow){
        return (
            <TouchableOpacity
                onPress={this._itemClickCallback.bind(this, rowData,rowID)}
                activeOpacity={theme.btnActiveOpacity}>
                {this._renderItemContent(rowData)}
            </TouchableOpacity>
        )
    }


    _renderItemContent(rowData){
        return(
            <View style={styles.item}>
                <Text style={{fontSize: px2dp(16),flex:1,
                    color: '#444444'}} numberOfLines={1}>{rowData.title}</Text>
                {
                    rowData.isCkecked?<Image source={require('../image/icon_red_check.png')} style={{width:px2dp(20),height:px2dp(12),marginRight:px2dp(10)}}/>
                        :null
                }
            </View>
        )};

    render(){
        return(
            <View style={styles.container}>
                <CommonHeader
                    title={'年龄'}
                    onBack={() => {
                        this.props.navigation.goBack();
                    }
                    }
                />
                <ListView
                    style={{flex:1}}
                    dataSource={this.state.dataSource}
                    enableEmptySections={true}
                    renderRow={this._renderItem.bind(this)}
                />
                <Toast ref={'toast'}/>
            </View>

        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item: {
        flexDirection: 'row',
        width: theme.screenWidth,
        height: px2dp(40),
        justifyContent:'center',
        alignItems:'center',
        backgroundColor: '#fff',
        paddingLeft: px2dp(10),
        paddingRight: px2dp(10),
        borderTopColor: '#d4d4d4',
        borderTopWidth: 1 / PixelRatio.get()
    },
    content: {
        color: '#666',
        fontSize: px2dp(12),
    },
});
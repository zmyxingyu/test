/**
 * 修改个人职业信息的页面
 * Created by yf on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    Text, View, StyleSheet,Image, AsyncStorage,DeviceEventEmitter,NativeModules,Platform, PixelRatio, TouchableOpacity, TextInput,Keyboard,
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import CommonHeader from  '../component/CommonHeaderText';
import Toast,{DURATION} from 'react-native-easy-toast';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import APIService from "../config/APIService";
import NativeCacheUtils from "../utils/NativeCacheUtils";
import getStringLen from '../utils/CommonUtils';

export default class UpdateJobPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            clickable:false,
            content:'',
            title:''
        }
    }

    componentDidMount() {
        const {content} = this.props.navigation.state.params;
        if(content==''||content==null)
            this.setState({content:'',clickable:false});
        else
            this.setState({content:content,clickable:true});
    }

    _handleItemClick(position){
        switch (position){
            case 0:
                if (this.state.content.length > 16) {
                    this.refs.toast.show('职业不能超过16个字');
                    this.setState({content: this.state.content.substring(0, 16)});
                } else if (!Constants.JOB_REGEX.test(this.state.content)) {
                    this.refs.toast.show('职业只能为汉字或英文');
                } else {
                    this._fetchData('job', this.state.content);
                }
                break;
            case 1:
                this.setState({content:'',clickable:false});
                break;
        }
    }

    _fetchData(infoType,infoValue) {
        NativeModules.CommonModule.showRNLoadingProgress(Constants.waitInfo);
        let context = this;
        var url = APIService.updateUserInfo;
        let par = {
            'openid' : Constants.openid,
            'infoType' : infoType,
            'infoValue' : infoValue+"",
            'timestamp':new Date().getTime()
        };
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            if(data.ret === 0){
                context.saveUserInfo('job',infoValue);
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    saveUserInfo(name,infoValue) {
        const {goBack, state} = this.props.navigation;
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    if(name == 'job'){
                        data.job=infoValue;
                        // NativeModules.CommonModule.saveUserInfoFromRN('job',infoValue);
                        NativeCacheUtils.saveUserInfoToNativeCache({job: infoValue + ''});
                    }
                    AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data), (error) => {
                        if (!error) {
                            // if (Platform.OS === 'ios') {
                            //     NativeModules.CommonModule.refreshMinePage();
                            // } else {
                            //     DeviceEventEmitter.emit('refreshMine');
                            // }
                            //参数回传
                            state.params.callback({job: infoValue});
                            goBack();
                        }
                    });
                }
            }
        })
    }

    render()
    {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'职业'}
                    onBack={() => {
                        this.props.navigation.goBack();
                        Keyboard.dismiss()
                    }
                    }
                    clickable={this.state.clickable}
                    rightName={'保存'}
                    onSubmit={() => {
                        Keyboard.dismiss();
                        this._handleItemClick(0);
                    }}
                />
                <View style={{flexDirection:'row',height: px2dp(50),marginTop:px2dp(15),paddingLeft:px2dp(10),paddingRight:px2dp(10),alignItems:'center',backgroundColor:'white',justifyContent:'center'}}>
                    <TextInput placeholder={'请输入职业(不超过16字）'} value={this.state.content} numberOfLines={1} placeholderTextColor={'#999'} underlineColorAndroid={'transparent'}
                               style={{fontSize:px2dp(16),color:'#444',flex:1,paddingRight:px2dp(10),backgroundColor:'white'}}
                               onChangeText={(text) => {
                                   this.setState({content:text});
                                   if(text != '' && text != null){
                                       this.setState({clickable:true});
                                   }else{
                                       this.setState({clickable:false});
                                   }
                               }}/>
                    {
                        this.state.clickable?
                            <TouchableOpacity onPress={this._handleItemClick.bind(this,1)} activeOpacity={theme.btnActiveOpacity}>
                                <Image source={require('../image/icon_delete.png')} style={{width:px2dp(20),height:px2dp(20)}}/>
                            </TouchableOpacity>:null
                    }
                </View>
                <Toast ref={'toast'} position={'center'}/>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        height: px2dp(50),flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',
        borderBottomWidth: 1/PixelRatio.get(),borderTopColor: '#c4c4c4',borderTopWidth: 1/PixelRatio.get()
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row',
        paddingTop: (Platform.OS === 'ios') ? px2dp(20) : 0,
    }
});
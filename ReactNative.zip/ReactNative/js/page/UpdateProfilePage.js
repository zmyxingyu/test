/**
 * 修改个人简介的页面
 * Created by yf on 2017/8/24.
 */
import React, {Component, PropTypes} from 'react';
import {
    Text, View, StyleSheet,Image, AsyncStorage,DeviceEventEmitter,NativeModules,Platform, PixelRatio, TouchableOpacity, TextInput,Keyboard
} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import NativeCacheUtils from '../utils/NativeCacheUtils';
import CommonHeader from  '../component/CommonHeaderText';
import Toast,{DURATION} from 'react-native-easy-toast';
import Constants from '../config/Constants';
import HttpUtils from '../utils/HttpUtils';
import APIService from "../config/APIService";
export default class UpdateProfilePage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            clickable:false,
            content:'',
            title:'',
            number:200
        }
    }

    componentDidMount() {
        const {content} = this.props.navigation.state.params;
        let size=200;
        if(content==''||content==null){
            this.setState({content:content,clickable:false,number:size});
        }
        else{
            size=200-content.length;
            this.setState({content:content,clickable:true,number:size});
        }
    }

    _handleItemClick(position){
        switch (position){
            case 0:
                this._fetchData('signature',this.state.content);
                break;
            case 1:
                this.setState({content:'',clickable:false});
                break;
        }
    }

    _fetchData(infoType,infoValue) {
        NativeModules.CommonModule.showRNLoadingProgress(Constants.waitInfo);
        let context = this;
        var url = APIService.updateUserInfo;
        let par = {
            'openid' : this.props.navigation.state.params.openid,
            'infoType' : infoType,
            'infoValue' : infoValue+"",
            'timestamp':new Date().getTime()
        };
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            if(data.ret === 0){
                context.saveUserInfo(infoValue);
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    saveUserInfo(infoValue) {
        NativeCacheUtils.saveUserInfoToNativeCache({signature: infoValue});
        const {goBack, state} = this.props.navigation;
        //参数回传
        state.params.callback({signature: infoValue});
        goBack();
        // AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
        //     if (!error) {
        //         if (result !== '' && result !== null) {
        //             let data = JSON.parse((result));
        //             if (name === 'signature') {
        //                 data.signature = infoValue;
        //
        //             }
        //             AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data), (error) => {
        //                 if (!error) {
        //                     // if (Platform.OS === 'ios') {
        //                     //     NativeModules.CommonModule.refreshMinePage();
        //                     // } else {
        //                     //     DeviceEventEmitter.emit('refreshMine');
        //                     // }
        //
        //                 }
        //             });
        //         }
        //     }
        // })
    }

    render()
    {
        return (
            <View style={styles.container}>
                <CommonHeader
                    title={'简介'}
                    onBack={() => {
                        Keyboard.dismiss();
                        this.props.navigation.goBack();
                    }
                    }
                    clickable={this.state.clickable}
                    rightName={'保存'}
                    onSubmit={() => {
                        Keyboard.dismiss();
                        this._handleItemClick(0);
                    }}
                />
                <View style={{flexDirection:'row',height: px2dp(146),marginTop:px2dp(15),paddingLeft:px2dp(10),paddingRight:px2dp(10),alignItems:'center',backgroundColor:'white',justifyContent:'center'}}>
                    <TextInput placeholder={'请输入简介'} value={this.state.content} multiline={true} maxLength={200}  placeholderTextColor={'#999'} underlineColorAndroid={'transparent'}
                               style={{height: px2dp(146),fontSize:px2dp(16),color:'#444',flex:1,backgroundColor:'white',textAlignVertical: 'top'}}
                               onChangeText={(text) => {
                                   this.setState({content:text});
                                   if(text != '' && text != null){
                                       let old=200-text.length;
                                       this.setState({clickable:true,number:old});
                                   }else{
                                       let old=200-text.length;
                                       this.setState({clickable:false,number:old});
                                   }
                               }}/>
                </View>
                <View style={{flexDirection:'row',backgroundColor:'white',justifyContent:'flex-end'}}>
                    <Text style={{height:px2dp(30),marginRight:px2dp(10)}}>{this.state.number}</Text>
                </View>
                <Toast ref={'toast'} position={'center'}/>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.pageBackgroundColor
    },
    item:{
        height: 50,flexDirection:'row',borderBottomColor: '#c4c4c4',alignItems:'center',backgroundColor:'white',
        borderBottomWidth: 1/PixelRatio.get(),borderTopColor: '#c4c4c4',borderTopWidth: 1/PixelRatio.get()
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        flexDirection:'row',
        paddingTop: (Platform.OS === 'ios') ? px2dp(20) : 0,
    }
});
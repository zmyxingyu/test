/**
 * 我的信息页面
 * Created by yf on 2017/8/24.
 */
import React, {PropTypes,Component} from 'react';
import {Text,ScrollView,NativeEventEmitter,AsyncStorage,DeviceEventEmitter,InteractionManager,TouchableOpacity, View, StyleSheet,Dimensions, Platform, NativeModules, Image, PixelRatio} from 'react-native';
import px2dp from '../utils/px2dp';
import theme from '../utils/theme';
import NativeCacheUtils from '../utils/NativeCacheUtils';
import CommonHeader from  '../component/CommonHeader';
import DividingLine from  '../component/DividingLine';
import Constants from '../config/Constants';
import UserInfoUtils from '../utils/UserInfoUtils';
import APIService from "../config/APIService";
import HttpUtils from '../utils/HttpUtils';
import Toast,{DURATION} from 'react-native-easy-toast';
import DialogSelectList from "../component/DialogSelectList";
import CCCImage from "../component/CCCImage";
const {MineManager} = NativeModules;
const MineManagerEmitter = new NativeEventEmitter(MineManager);
const {CommonModule} = NativeModules;
export default class UserInfoPage extends Component{
    constructor(props){
        super(props);
        this.state = {
            openid: this.props.screenProps.openid,
            nickName:'未设置',
            iconUrl:'',
            signature:'介绍自己，展示个性', //简介
            memo:'',  //认证
            profit:0,
            fansCount:0,
            totalCredit:0,
            kcoin:0,
            roles:'',
            edu:'未设置',
            job:'未设置',
            occupation:'未设置',
            sex:1,//1 表示男
            identityStatus:0,//1 表示已实名  0  表示未实名
            creditRank:1,
            totalCredit:0,
            age:'未设置'
        };
    }

    componentWillMount() {
        this.asQuery(Constants.USERINFO);
    }

    asQuery(key) {
        AsyncStorage.getItem(key, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    Constants.openid = data.openid;
                    this.setState({
                        memo:data.memo,
                        signature:data.signature,
                        nickName:data.nickName,
                        iconUrl:data.iconUrl,
                        roles:data.roles,
                        profit:data.profit/100.0,
                        kcoin:data.kcoin,
                        fansCount:data.fansCount,
                        identityStatus:data.identityStatus,
                        sex:data.sex,
                        occupation:data.occupation,
                        job:data.job,
                        edu:data.edu,
                        creditRank:data.creditRank,
                        totalCredit:data.totalCredit,
                        age:data.age
                    });
                }
            }
        })
    }

    renderSelectDialog() {
        let items = ['男', '女'];
        return (
            <DialogSelectList
                ref={(ref) => {
                    this.selectDialog = ref;
                }}
                items={items}
                onSelect={(index) => {
                    this.selectDialog.selectDialog.dismiss();
                    if (index === 0) {
                        this._fetchData('sex',1);
                    } else {
                        this._fetchData('sex',2);
                    }
                }}
            />
        );
    }

    _handleItemClick(position){
        InteractionManager.runAfterInteractions(() => {
            switch (position){
                case 0://头像
                    NativeModules.CommonModule.getAvatarFromNative();
                    break;
                case 1://昵称
                    this.props.navigation.navigate('UpdateNickNamePage',
                        {
                            openid:this.state.openid,
                            content:this.state.nickName,
                            callback: (data) => {
                                if (data) this.setState(data);
                            },
                        });
                    break;
                case 2://性别
                    this.selectDialog.selectDialog.show();
                    break;
                case 3://简介
                    this.props.navigation.navigate('UpdateProfilePage', {
                        openid:this.state.openid,
                        content:this.state.signature,
                        callback: (data) => {
                            if (data) this.setState(data);
                        },
                    });
                    break;
                case 4://行业
                    let occ=[{'title':'互联网-软件','isCkecked':false},{'title':'通信-硬件','isCkecked':false},{'title':'文化传媒','isCkecked':false},{'title':'金融类','isCkecked':false},{'title':'消费品','isCkecked':false},{'title':'汽车-机械','isCkecked':false},{'title':'教育-翻译','isCkecked':false},{'title':'贸易-物流','isCkecked':false},{'title':'生物-医生','isCkecked':false},{'title':'能源-化工','isCkecked':false},{'title':'政府机构','isCkecked':false},{'title':'服务业','isCkecked':false},{'title':'其他行业','isCkecked':false}];
                    for(let i in occ){
                        if(occ[i].title == this.state.occupation){
                            occ[i].isCkecked=true;
                        }
                    }
                    this.props.navigation.navigate('UpdateIndustryPage', {
                        openid:this.state.openid,
                        content:occ,
                        callback: (data) => {
                            if (data) this.setState(data);
                        },
                    });
                    break;
                case 5://职业
                    this.props.navigation.navigate('UpdateJobPage', {
                        openid:this.state.openid,
                        content:this.state.job,
                        callback: (data) => {
                            if (data) this.setState(data);
                        },
                    });
                    break;
                case 6://我的二维码
                    const shareUrl=APIService.HTTP_BASE_URL + APIService.sharePersonalURL+this.state.openid;
                    //const typeid= "&typeId="+Constants.openid;
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/commonSharePage?title=我的二维码&url="+shareUrl + '&listId=' + Constants.openid);
                    break;
                case 7://等级
                    let params = {
                        'openid' : this.state.openid,
                        'timestamp':new Date().getTime()
                    };
                    HttpUtils.signParams(params,function (data) {
                        NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/webPage?title=等级&url="+APIService.HTTP_BASE_URL+APIService.rank+'?'+data);
                    });
                    break;
                case 8://实名认证
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/authEntrancePage");
                    break;
                case 10://年龄
                    let age=[{'title':'00 后','isCkecked':false},{'title':'95 后','isCkecked':false},{'title':'90 后','isCkecked':false},{'title':'85 后','isCkecked':false},{'title':'80 后','isCkecked':false},{'title':'75 后','isCkecked':false},{'title':'70 后','isCkecked':false},{'title':'65 后','isCkecked':false},{'title':'60 后','isCkecked':false},{'title':'55 后','isCkecked':false},{'title':'50 后','isCkecked':false}];
                    for(let i in age){
                        if(age[i].title == this.state.age || age[i].title.replace(" ","") == this.state.age){
                            age[i].isCkecked=true;
                        }
                    }
                    this.props.navigation.navigate('UpdateAgePage', {
                        openid:this.state.openid,
                        content:age,
                        callback: (data) => {
                            if (data) this.setState(data);
                        },
                    });
                    break;
                case 11://学历
                    let edu=[{'title':'初中','isCkecked':false},{'title':'高中','isCkecked':false},{'title':'大专','isCkecked':false},{'title':'本科','isCkecked':false},{'title':'硕士','isCkecked':false},{'title':'博士','isCkecked':false}];
                    for(let i in edu){
                        if(edu[i].title == this.state.edu){
                            edu[i].isCkecked=true;
                        }
                    }
                    this.props.navigation.navigate('UpdateEduPage', {
                        openid:this.state.openid,
                        content:edu,
                        callback: (data) => {
                            if (data) this.setState(data);
                        },
                    });
                    break;
                case 12://积分
                    NativeModules.IntentFromJsModule.openPageFromJS("kanjian://MainApp/webPage?title=兑换中心&url=" + APIService.HTTP_BASE_URL + APIService.credit);
                    break;
            }
        });
    }

    componentDidMount(){
        if (Platform.OS === 'ios') {
            this.sexEvent = MineManagerEmitter.addListener('updateUserAvatar',(response)=>{
                this.setState({iconUrl:response.iconUrl});
                this.saveUserInfo('head',response.iconUrl);
            });
            this.changeIdentityEvent = MineManagerEmitter.addListener('identityResult', (response) => {
                this.setState({identityStatus:response.identityResult});
                this.saveUserInfo('identityStatus',response.identityResult);
            });
        }else{
            this.sexEvent = DeviceEventEmitter.addListener('updateUserAvatar', (response) => {
                this.setState({iconUrl:response.picUrl});
                this.saveUserInfo('head',response.picUrl);
            });
            this.changeIdentityEvent = DeviceEventEmitter.addListener('identityResult', (response) => {
                this.setState({identityStatus:response.identityResult});
                this.saveUserInfo('identityStatus',response.identityResult);
            });
        }
        // this.refreshEvent = DeviceEventEmitter.addListener('refreshMine',()=>{
        //     this.asQuery(Constants.USERINFO);
        // });
        // this.refreshUserEvent = DeviceEventEmitter.addListener('refreshUser',()=>{//只刷新用户信息页面
        //     this.asQuery(Constants.USERINFO);
        // });
    }

    componentWillUnmount(){
        // this.refreshUserEvent.remove();
        this.sexEvent.remove();
        this.changeIdentityEvent.remove();
        // this.refreshEvent.remove();
    }

    _fetchData(infoType,infoValue) {
        NativeModules.CommonModule.showRNLoadingProgress("");
        let context = this;
        var url = APIService.updateUserInfo;
        let par = {
            'openid' : this.state.openid,
            'infoType' : infoType,
            'infoValue' : infoValue+"",
            'timestamp':new Date().getTime()
        };
        HttpUtils.postForm(url,par,function (data) {
            NativeModules.CommonModule.dismissRNLoadingProgress();
            if(data.ret === 0){
                context.saveUserInfo('sex',infoValue);
            }else{
                context.refs.toast.show(data.msg,DURATION.LENGTH_SHORT);
            }
        });
    }

    saveUserInfo(name,infoValue) {
        AsyncStorage.getItem(Constants.USERINFO, (error, result) => {
            if (!error) {
                if (result !== '' && result !== null) {
                    let data = JSON.parse((result));
                    if (name == 'sex') {
                        data.sex = infoValue;
                        this.setState({sex: infoValue});
                        // NativeModules.CommonModule.saveUserInfoFromRN('sex',infoValue+"");
                        NativeCacheUtils.saveUserInfoToNativeCache({sex: infoValue + ""})
                    } else if (name == 'head') {
                        data.iconUrl = infoValue;
                    } else if (name === 'identityStatus') {
                        data.identityStatus = infoValue;
                    }
                    AsyncStorage.setItem(Constants.USERINFO, JSON.stringify(data), (error) => {
                        if (!error) {
                            if(name == 'head'){
                                if (Platform.OS === 'ios') {
                                    // CommonModule.refreshMinePage();
                                } else {
                                    DeviceEventEmitter.emit('refreshMine');
                                }
                            }
                        }
                    });
                }
            }
        })
    }

    render(){
        return(
            <View style={styles.container}>
                <CommonHeader
                    title={'个人信息'}
                    onBack={() => {
                        NativeModules.CommonModule.goBack();
                    }}
                />
                <ScrollView>
                    <View style={styles.container}>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,0)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={{height: px2dp(70), backgroundColor: 'white', flexDirection: 'row', alignItems: 'center',
                                paddingLeft: px2dp(10), paddingRight: px2dp(10),marginTop:px2dp(10)}}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>头像</Text>
                                <View style={{
                                    flex: 1,
                                    flexDirection: 'row',
                                    justifyContent: 'flex-end',
                                    alignItems: 'center'
                                }}>
                                    <CCCImage
                                        source={{uri: this.state.iconUrl}}
                                        resizeMode={Image.resizeMode.stretch}
                                        isRound
                                        style={{width: px2dp(55), height: px2dp(55),backgroundColor:'#fff', borderRadius: px2dp(27.5)}}
                                    />
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,1)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>昵称</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{(this.state.nickName==''||this.state.nickName==null)?"未设置":this.state.nickName}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,2)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>性别</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{this.state.sex==1?'男':(this.state.sex==2?'女':'未设置')}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,3)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>简介</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8),flex:1,marginLeft:px2dp(10),textAlign:'right'}} numberOfLines={1}>{(this.state.signature==''||this.state.signature==null)?"介绍自己，展示个性":this.state.signature}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,4)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>行业</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{(this.state.occupation==''||this.state.occupation==null)?"未设置":this.state.occupation}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,5)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>职业</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{(this.state.job==''||this.state.job==null)?"未设置":this.state.job}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,6)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={{height: px2dp(50), backgroundColor: 'white', flexDirection: 'row',marginTop:px2dp(20),
                                alignItems: 'center', paddingLeft: px2dp(10), paddingRight: px2dp(10)}}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>我的二维码</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Image source={require('../image/my_qrcode.png')} style={{width:px2dp(20),height:px2dp(20),marginRight:px2dp(8)}}/>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,7)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>等级</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Image source={UserInfoUtils.getGrade(this.state.creditRank)} style={{width:px2dp(30),height:px2dp(16),marginRight:px2dp(8)}}/>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,12)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>积分</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{this.state.totalCredit}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <View style={{height: px2dp(30), flexDirection: 'row',marginTop:px2dp(20),
                            alignItems: 'center', paddingLeft: px2dp(10), paddingRight: px2dp(10)}}>
                            <Text style={{color: '#777', fontSize: px2dp(13)}}>非公开信息</Text>
                        </View>
                        <View style={{height: px2dp(50), backgroundColor: 'white', flexDirection: 'row',
                            alignItems: 'center', paddingLeft: px2dp(10), paddingRight: px2dp(10)}}>
                            <Text style={{color: '#000', fontSize: px2dp(15)}}>实名认证</Text>
                            {
                                this.state.identityStatus===1?
                                    <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                        <Text style={{color: "#999",marginRight:px2dp(5)}}>已认证</Text>
                                    </View>
                                    :
                                    (this.state.identityStatus===2?
                                        <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                            <Text style={{color: "#999",marginRight:px2dp(5)}}>审核中</Text>
                                        </View>:
                                        (this.state.identityStatus===3?
                                            <TouchableOpacity onPress={this._handleItemClick.bind(this,8)} activeOpacity={theme.btnActiveOpacity} style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                                    <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                                        <Text style={{color: "#f00",marginRight:px2dp(8)}}>未通过</Text>
                                                        <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                                    </View>
                                                </View>
                                            </TouchableOpacity> :
                                            <TouchableOpacity onPress={this._handleItemClick.bind(this,8)} activeOpacity={theme.btnActiveOpacity} style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                                    <Text style={{color: "#f00",marginRight:px2dp(8)}}>未认证</Text>
                                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                                </View>
                                            </TouchableOpacity>
                                        ))
                            }
                        </View>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,10)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>年龄</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{(this.state.age===''||this.state.age==null)?'未设置':this.state.age}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        <TouchableOpacity onPress={this._handleItemClick.bind(this,11)} activeOpacity={theme.btnActiveOpacity}>
                            <View style={styles.listItem}>
                                <Text style={{color: '#000', fontSize: px2dp(15)}}>学历</Text>
                                <View style={{flex:1, flexDirection: 'row', justifyContent: 'flex-end', alignItems:'center'}}>
                                    <Text style={{color: "#999",marginRight:px2dp(8)}}>{(this.state.edu==''||this.state.edu==null)?"未设置":this.state.edu}</Text>
                                    <Image source={require('../image/more_icon.png')} style={{width:px2dp(16),height:px2dp(16)}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                        <DividingLine/>
                        {
                            (this.state.memo==''||this.state.memo==null)?null:
                                <View>
                                    <View style={{height: px2dp(30), flexDirection: 'row',marginTop:px2dp(20),
                                        alignItems: 'center', paddingLeft: px2dp(10), paddingRight: px2dp(10)}}>
                                        <Text style={{color: '#777', fontSize: px2dp(13)}}>认证信息</Text>
                                    </View>
                                    <View style={{height: px2dp(50), backgroundColor: 'white', flexDirection: 'row',
                                        alignItems: 'center', paddingLeft: px2dp(10), paddingRight: px2dp(10), borderBottomColor: '#c4c4c4', borderBottomWidth: 1/PixelRatio.get()}}>
                                        <Text style={{color: '#000', fontSize: px2dp(15)}}>{this.state.memo}</Text>
                                    </View>
                                </View>
                        }
                    </View>
                </ScrollView>
                <Toast ref={'toast'}/>
                {this.renderSelectDialog()}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection:'column',
        backgroundColor: theme.pageBackgroundColor
    },
    image: {
        height: px2dp(200),
        width: Dimensions.get('window').width
    },
    listItem: {
        height: px2dp(50),
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: px2dp(10),
        paddingRight: px2dp(10),
    },
    actionBar: {
        height: theme.actionBar.height,
        backgroundColor: theme.actionBar.backgroundColor,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection:'row',
        paddingTop: (Platform.OS === 'ios') ? px2dp(20) : 0,
    }
});
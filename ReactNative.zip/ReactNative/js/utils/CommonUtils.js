/**
 * 通用工具方法
 * Created by lizhj on 2017/10/26.
 */

/**
 * 获取字符串字符长度，中文字符算2个字符
 * @param str
 * @returns {*}
 */
export default function getStringLen(str) {
    let i, len, code;
    if (str === null || str === '')   return 0;
    len = str.length;
    for (i = 0; i < str.length; i++) {
        code = str.charCodeAt(i);
        if (code > 255) {
            len++;
        }
    }
    return len;
}
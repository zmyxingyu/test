/**
 * Created by yanfei on 2017/7/31.
 */
export default function FormatDateUtil(fmt, time) {
    let date = new Date(time);
    let o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "h+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (let k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

/**
 * 将long类型时间转为 yyyy-MM-dd格式日期
 * @param longTypeDate
 * @returns {string}
 */
export function dateFormat(longTypeDate) {
    let date = new Date(longTypeDate);
    let dateType = date.getFullYear() + '-' + getMonth(date) + '-' + getDay(date);
    return dateType;
}

/**
 * 获取下一个月
 * @returns {string}
 */
export function getNextMonth() {
    let date = new Date();
    let year = date.getFullYear(); //获取当前日期的年份
    let month = date.getMonth(); //获取当前日期的月份
    let day = date.getDate(); //获取当前日期的日
    month += 1;
    if (month === 13) {
        year += 1;
        month = 1;
    }
    let days2 = new Date(year, month, day);
    return days2.getTime();
}

/**
 * 获取下一年
 * @returns {string}
 */
export function getNextYear() {
    let date = new Date();
    let year = date.getFullYear(); //获取当前日期的年份
    let month = date.getMonth(); //获取当前日期的月份
    let day = date.getDate(); //获取当前日期的日
    year += 1;
    let days2 = new Date(year, month, day);
    return days2.getTime();
}

//返回 01-12 的月份值
function getMonth(date) {
    let month = date.getMonth() + 1; //getMonth()得到的月份是0-11
    if (month < 10) {
        month = '0' + month;
    }
    return month;
}
//返回01-30的日期
function getDay(date) {
    let day = date.getDate();
    if (day < 10) {
        day = '0' + day;
    }
    return day;
}
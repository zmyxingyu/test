/**
 * Created by lizhj on 2017/8/17.
 */
import {NativeModules} from 'react-native';
import APIService from '../config/APIService';
import NativeDialogUtils from '../utils/NativeDialogUtils';

/**
 * 发起网络请求
 * @param uri uri路径
 * @param params 需要加密的参数
 * @returns {Promise.<*>}
 */
export default {
    async doGet(uri, params) {
        try {
            //通过原生模块封装和加密请求参数
            let encryptParams = await NativeModules.EncryptModule.encryptParams(params);
            let url = APIService.HTTP_BASE_URL + uri + '?' + encryptParams;
            let response = await
                fetch(url, {
                    method: 'GET',
                });
            let data = await
                response.json();
            return {data};
        } catch (error) {
            console.warn(error);
            return {data: undefined, error};
        }
    },

    /**
     * 提交post请求（ps.因为iOS NetInfo.isConnected API的bug，无法在此处统一判断网络连接状态，需要在各自独立的页面生命周期内注册网络监听变化方法）
     * @param uri 请求地址
     * @param params 请求参数
     * @param loadingTips 发起请求时的对话框提示，为空则不会显示loading对话框
     * @returns {Promise.<*>}
     */
    async doPost(uri, params, loadingTips) {
        if (loadingTips) NativeDialogUtils.showCircleProgressDialog(loadingTips);
        try {
            //通过原生模块封装和加密请求参数
            let encryptParams = await NativeModules.EncryptModule.encryptParams(params);
            let url = APIService.HTTP_BASE_URL + uri;
            //console.log(url + '?' + encryptParams);
            let response = await this.timeout_fetch(fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: encryptParams,
            }));
            let data = await response.json();
            //console.log('RN HTTP RESPONSE==>');
            //console.log(data);
            if (loadingTips) NativeDialogUtils.dismissCircleProgressDialog();
            return {data};
        } catch (error) {
            if (loadingTips) NativeDialogUtils.dismissCircleProgressDialog();
            return {data: undefined, error};
        }
    },

    async postForm(uri, params, callback) {
        let encryptParams = await NativeModules.EncryptModule.encryptParams(params);
        let url = APIService.HTTP_BASE_URL + uri;
        //console.log(url + "?" + encryptParams);
        this.timeout_fetch(fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: encryptParams
        }))
            .then((response) => response.json())
            .then((responseJSON) => {
                //console.log('postForm responseJSON==>');
                //console.log(responseJSON);
                callback(responseJSON)
            })
            .catch((error) => {
                //console.log("error = " + error)
                callback()
            });
    },

    async signParams(params, callback) {
        let encryptParams = await NativeModules.EncryptModule.encryptParams(params);
        callback(encryptParams);
    },

    /**
     * 让fetch也可以timeout
     *  timeout不是请求连接超时的含义，它表示请求的response时间，包括请求的连接、服务器处理及服务器响应回来的时间
     * fetch的timeout即使超时发生了，本次请求也不会被abort丢弃掉，它在后台仍然会发送到服务器端，只是本次请求的响应内容被丢弃而已
     * @param {Promise} fetch_promise    fetch请求返回的Promise
     * @param {number} [timeout=10000]   单位：毫秒，这里设置默认超时时间为10秒
     * @return 返回Promise
     */
    timeout_fetch(fetch_promise, timeout = 10000) {
        let timeout_fn = null;
        //这是一个可以被reject的promise
        let timeout_promise = new Promise(function (resolve, reject) {
            timeout_fn = function () {
                reject('请求超时');
            };
        });

        //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
        let abortable_promise = Promise.race([
            fetch_promise,
            timeout_promise
        ]);

        setTimeout(function () {
            timeout_fn();
        }, timeout);

        return abortable_promise;
    }
}

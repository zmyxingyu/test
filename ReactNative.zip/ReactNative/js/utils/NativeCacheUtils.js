/**
 * Created by lizhj on 2017/9/12.
 */
import {NativeModules} from 'react-native';
const {CommonModule} = NativeModules;

export default {
    /**
     * 从原生缓存获取用户信息
     * @retrun 原生返回用户信息字符串，在此处将json字符串转换成对象
     */
    async getUserInfoFromNativeCache() {
        let userInfo = await CommonModule.getUserInfoFromCache();
        return JSON.parse(userInfo);
    },

    /**
     * 从缓存根据key和类型获取对应的value
     * @param key 缓存的key,需保证key名字和原生的key名相同
     * @param type ：默认 Constant.NATIVE_CACHE_TYPE.string,
     *          Constant.NATIVE_CACHE_TYPE.boolean,
     *          Constant.NATIVE_CACHE_TYPE.int,
     *          Constant.NATIVE_CACHE_TYPE.long,
     *          Constant.NATIVE_CACHE_TYPE.string,
     *          Constant.NATIVE_CACHE_TYPE.float,
     */
    async getDataFromNativeCache(key: string, type = 'string') {
        let cacheData = await CommonModule.getDataFromNativeCache(key, type);
        return cacheData;
    },

    /**
     * 保存用户信息到原生缓存
     */
    saveUserInfoToNativeCache(data) {
        CommonModule.saveUserInfoFromRN(data);
    },

    /**
     * 保存数据到原生缓存通用方法
     * int类型数据传递到原生会变成float类型,long类型数据传递到原生会变成科学计数法数据，因此推荐将int或者long类型数据先转变成string类型，
     * 在原生接口处转回正确到类型
     *
     * @param data 需要缓存的键值对（一次请保存一个键值对，不同类型的键值对请分开保存）,需保证key名字和原生的key名相同
     *              如果需要保存多个不同类型的信息，可以将value转换成json
     * @param type ：默认 Constant.NATIVE_CACHE_TYPE.string,
     *          Constant.NATIVE_CACHE_TYPE.boolean,
     *          Constant.NATIVE_CACHE_TYPE.int,
     *          Constant.NATIVE_CACHE_TYPE.long,
     *          Constant.NATIVE_CACHE_TYPE.string,
     *          Constant.NATIVE_CACHE_TYPE.float,
     */
    saveDataToNativeCache(data, type = 'string') {
        CommonModule.saveDataToNativeCache(data,type);
    }

};
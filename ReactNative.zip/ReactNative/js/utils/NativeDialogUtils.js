/**
 * 封装原生对话框
 * Created by lizhj on 2017/9/6.
 */
import {NativeModules} from 'react-native';
const {CommonModule} = NativeModules;
export default {
    /**
     * 展示原生圆形进度条对话框
     * @param msg 进度条提示内容
     */
    showCircleProgressDialog(msg: string){
        CommonModule.showRNLoadingProgress(msg);
    },

    /**
     * 关闭原生圆形进度条对话框
     */
    dismissCircleProgressDialog(){
        CommonModule.dismissRNLoadingProgress();
    }

};
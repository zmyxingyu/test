/**
 * url参数解析工具
 * Created by lizhj on 2017/9/13.
 */

export default {
    /**
     * 从url字符串中获取参数对象
     * 例如 url为 kanjian://RNApp/circlePage?openid=111&listId=1234
     * 则返回  { openid: '111', listId: '1234' }
     */
    parseQueryString(url) {
        const regUrl = /^[^\?]+\?([\w\W]+)$/;
        const regPara = /([^&=]+)=([\w\W]*?)(&|$|#)/g;
        let arrUrl = regUrl.exec(url);
        let ret = {};
        if (arrUrl && arrUrl[1]) {
            let strPara = arrUrl[1];
            let result;
            while ((result = regPara.exec(strPara)) != null) {
                ret[result[1]] = result[2];
            }
        }
        return ret;
    }

};
/**
 * 用户信息
 * Created by yf on 2017/8/24.
 */
import {AsyncStorage, DeviceEventEmitter,Platform,NativeModules} from 'react-native';
import Constants from '../config/Constants';

export default {
    /**
     *   0 普通  1 蓝色v  2 橙色v
     * @param roles
     * @returns {number}
     */
    getRoleFlag(roles){
        if (!roles) {
            return 0;
        } else {
            let roleArr = roles.split(",");
            if (roleArr) {
                for (let i in roleArr) {
                    if ('gold_pusher' == roleArr[i]) {
                        return 2;
                    }
                    if ('original_author' == roleArr[i] || 'cooperate' == roleArr[i] || 'editor' == roleArr[i]) {
                        return 1;
                    }
                }
            }
            return 0;
        }
    },

    getGrade(grade){
        let level = '';
        switch (grade) {
            case 0:
            case 1:
                level = require('../image/common_grade_level1_white.png');
                break;
            case 2:
                level = require('../image/common_grade_level2_white.png');
                break;
            case 3:
                level = require('../image/common_grade_level3_white.png');
                break;
            case 4:
                level = require('../image/common_grade_level4_white.png');
                break;
            case 5:
                level = require('../image/common_grade_level5_white.png');
                break;
            case 6:
                level = require('../image/common_grade_level6_white.png');
                break;
            case 7:
                level = require('../image/common_grade_level7_white.png');
                break;
            case 8:
                level = require('../image/common_grade_level8_white.png');
                break;
            case 9:
                level = require('../image/common_grade_level9_white.png');
                break;
            case 10:
                level = require('../image/common_grade_level10_white.png');
                break;
            case 11:
                level = require('../image/common_grade_level11_white.png');
                break;
            case 12:
                level = require('../image/common_grade_level12_white.png');
                break;
            case 13:
                level = require('../image/common_grade_level13_white.png');
                break;
            case 14:
                level = require('../image/common_grade_level14_white.png');
                break;
            case 15:
                level = require('../image/common_grade_level15_white.png');
                break;
        }
        return level;
    },

    /**
     * 更新Mineinfo缓存信息
     * @param opType 操作类型，见 {#onstants.UPDATE_MINEINFO_TYPE}
     * @param listId
     * @param value 根据opType不同，value值会有些许不同
     */
    updateMineInfoCache(opType, listId, value,listType) {
        if (Platform.OS === 'ios') {
        } else {
            DeviceEventEmitter.emit('refreshHomeFromNet');
        }
        AsyncStorage.getItem(Constants.MINEINFO, (error, result) => {
            if (!error) {
                if (result && result !== '') {
                    let data = JSON.parse((result));
                    switch (opType) {
                        case Constants.UPDATE_MINEINFO_TYPE.UPDATE_CIRCLE_NAME:
                            let circleArray = data.communities;
                            circleArray.map(item => {
                                if (item.listId === listId) {
                                    item.listName = value;
                                }
                            });
                            break;
                        case Constants.UPDATE_MINEINFO_TYPE.UPDATE_LISTING_NAME:
                            let listingArray = data.marklists;
                            listingArray.map(item => {
                                if (item.listId === listId) {
                                    item.listName = value;
                                }
                            });
                            break;
                        case Constants.UPDATE_MINEINFO_TYPE.DELETE_CIRCLE:
                            this.removeByListId(data.communities, listId);
                            break;
                        case Constants.UPDATE_MINEINFO_TYPE.DELETE_LISTING:
                            this.removeByListId(data.marklists, listId);
                            break;
                        case Constants.UPDATE_MINEINFO_TYPE.TRANSFORM_LISTING:
                            this.removeByListId(data.marklists, listId);
                            data.communities.push(value);
                            break;
                        case Constants.UPDATE_MINEINFO_TYPE.UPDATE_PRIVATE_STATE:
                            if (listType === Constants.LIST_TYPE.CIRCLE) {
                                let circles = data.communities;
                                circles.map(item => {
                                    if (item.listId === listId) {
                                        item.isPrivate = value;
                                    }
                                });
                            } else {
                                let listings= data.marklists;
                                listings.map(item => {
                                    if (item.listId === listId) {
                                        item.isPrivate = value;
                                    }
                                });
                            }
                            break;
                        default:
                            break;
                    }
                    //重新设置缓存
                    AsyncStorage.setItem(Constants.MINEINFO, JSON.stringify(data), (error2, result) => {
                        if (!error2) {
                            if (Platform.OS === 'ios') {
                                NativeModules.CommonModule.refreshMinePage();
                            } else {
                                DeviceEventEmitter.emit('refreshMine');
                                DeviceEventEmitter.emit('refreshHomeFromNet');
                            }
                        }
                    });
                }
            }
        });
    },

    removeByListId(arr, val) {
        for (let i = 0; i < arr.length; i++) {
            if (arr[i].listId === val) {
                arr.splice(i, 1);
                break;
            }
        }
    }

}
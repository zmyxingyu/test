/**
 * Created by yf on 2017/8/24.
 */
import {Dimensions,Platform} from 'react-native';

const deviceHeightDp = Dimensions.get('window').height;
const uiHeightPx = 640;
export default function px2dp(uiElementPx) {
    return   Platform.OS == 'ios' ? uiElementPx : uiElementPx * deviceHeightDp / uiHeightPx;
}
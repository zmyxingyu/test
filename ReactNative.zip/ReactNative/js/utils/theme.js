import {Dimensions, Platform} from 'react-native';

import px2dp from './px2dp';
import ScreenUtils from '../utils/ScreenUtils';

const globalTextColor = '#000';

export default {
    screenWidth: Dimensions.get('window').width,
    screenHeight: Dimensions.get('window').height,
    themeColor: '#fff',
    pageBackgroundColor: '#f4f4f4',
    grayColor: '#c4c4c4',
    btnActiveOpacity: 0.65,
    actionBar: {
        height: (Platform.OS === 'android') ? px2dp(44) : ScreenUtils.isIPhoneX ? px2dp(88) : px2dp(64),
        backgroundColor: '#fff',
        fontSize: px2dp(17),
        fontColor: 'white'
    },
    text: {
        color: globalTextColor,
        fontSize: px2dp(15)
    },
    scrollView: {
        fontSize: px2dp(15),
        underlineStyle: {
            backgroundColor: 'white'
        }
    }
};
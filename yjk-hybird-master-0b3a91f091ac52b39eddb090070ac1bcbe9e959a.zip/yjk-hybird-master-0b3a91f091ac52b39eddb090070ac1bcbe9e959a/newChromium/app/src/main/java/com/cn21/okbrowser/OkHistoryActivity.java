package com.cn21.okbrowser;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import org.chromium.chrome.R;

public class OkHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok_history);
    }
}

package com.cn21.okbrowser.suggestions;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.chromium.base.ApiCompatibilityUtils;
import org.chromium.base.ContextUtils;
import org.chromium.chrome.R;
import org.chromium.chrome.browser.bookmarks.BookmarkBridge;
import org.chromium.chrome.browser.bookmarks.BookmarkModel;
import org.chromium.chrome.browser.bookmarks.BookmarkUtils;
import org.chromium.chrome.browser.favicon.LargeIconBridge;
import org.chromium.chrome.browser.ntp.ContextMenuManager;
import org.chromium.chrome.browser.offlinepages.OfflinePageBridge;
import org.chromium.chrome.browser.profiles.Profile;
import org.chromium.chrome.browser.suggestions.SuggestionsMetrics;
import org.chromium.chrome.browser.suggestions.SuggestionsUiDelegate;
import org.chromium.chrome.browser.suggestions.Tile;
import org.chromium.chrome.browser.suggestions.TileGroup;
import org.chromium.chrome.browser.suggestions.TileSource;
import org.chromium.chrome.browser.suggestions.TileView;
import org.chromium.chrome.browser.widget.RoundedIconGenerator;
import org.chromium.components.bookmarks.BookmarkId;
import org.chromium.ui.mojom.WindowOpenDisposition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhangmy on 2017/12/27.
 */

public class CusSuggestionsManager {
    private String TAG = CusSuggestionsManager.class.getSimpleName();
    public static final String KEY_SUGGESTION_FOLDER_ID = "okbrowser_suggestion_folder_id";
    public static final long NO_SUGGESTION_FOLDER_ID = -1001;

    public static final String MAIL189 = "http://wap.189.cn/wap2/";
    public static final String CLOUD189 = "https://cloud.189.cn/";
    public static final String KJ189 = "http://k.21cn.com/api/activity/kanjianwap/index.html";
    public static final String NB189 = "http://nb.189.cn/portal/info/wapactivitylist/flow/2/v1.1/index";

    public static final String[] CUS_URLS = {MAIL189, CLOUD189, NB189, KJ189};
    public static final String[] CUS_TITLES = {"189邮箱", "天翼云", "流量宝", "看荐"};


    private static CusSuggestionsManager instance = new CusSuggestionsManager();
    private CusSuggestionsManager(){}
    public static CusSuggestionsManager getInstance(){
        return instance;
    }

    private BookmarkModel bookmarkModel;

    private static ArrayList<Tile> pendingTiles = new ArrayList<>();
    private static Tile[] tiles = new Tile[0];
    private BookmarkBridge.BookmarkModelObserver tileViewObserver;

    public void setTileViewObserver(BookmarkBridge.BookmarkModelObserver observer) {
        tileViewObserver = observer;
    }

    public void initSuggestBookmark(final Context context) {
        if (bookmarkModel == null) {
            bookmarkModel = new BookmarkModel();
            bookmarkModel.addObserver(new BookmarkBridge.BookmarkModelObserver() {
                @Override
                public void bookmarkModelChanged() {
                    if (bookmarkModel.isBookmarkModelLoaded()) {
                        reloadSuggestionsBookmark(context,bookmarkModel);
                    }
                    if (tileViewObserver != null) {
                        tileViewObserver.bookmarkModelChanged();
                    }
                }
            });
            bookmarkModel.runAfterBookmarkModelLoaded(new Runnable() {
                @Override
                public void run() {
                    cusSuggestionsBookmarkFolder(context, bookmarkModel);
                }
            });
        }
    }

    private void cusSuggestionsBookmarkFolder(Context context, BookmarkModel model) {
        Log.e(TAG,"cusSuggestionsBookmarkFolder ");
        SharedPreferences preferences = ContextUtils.getAppSharedPreferences();
        String title = context.getResources().getString(R.string.suggestion_bookmark_folder_name);
        long id = preferences.getLong(KEY_SUGGESTION_FOLDER_ID, NO_SUGGESTION_FOLDER_ID);
        if (id == NO_SUGGESTION_FOLDER_ID) {
            BookmarkId newFolder = model.addFolder(model.getMobileFolderId(), 0, title);
            cusSuggestionsBookmarks(newFolder, model);
            preferences.edit().putLong(KEY_SUGGESTION_FOLDER_ID, newFolder.getId()).apply();
        } else {
            Log.e(TAG,"cusSuggestionsBookmarkFolder to reloadSuggestions");
            reloadSuggestionsBookmark(context,model);
        }
    }

    private void cusSuggestionsBookmarks(BookmarkId parent, BookmarkModel model) {
        for (int i = 0; i < CUS_TITLES.length; i++) {
            model.addBookmark(parent, i, CUS_TITLES[i], CUS_URLS[i]);
        }
    }

    private void reloadSuggestionsBookmark(Context context,BookmarkModel model){
        pendingTiles.clear();
        Log.e(TAG,"reloadSuggestionsBookmark begin ");
        try {
            BookmarkId id = BookmarkUtils.getSuggestionBookmark();
            if (id == null) {
                return;
            }
            List<BookmarkBridge.BookmarkItem> list = model.getBookmarksForFolder(id);
            Log.e(TAG,"reloadSuggestionsBookmark end , size : "+list.size());
            int i = 0;
            for (BookmarkBridge.BookmarkItem item : list) {
                Tile tile = new Tile(item.getTitle(), item.getUrl(), null, i++, TileSource.POPULAR);
                Drawable drawable = getPopularSitesIconByUrl(tile.getUrl());
                if (drawable != null) {
                    tile.setIcon(drawable);
                } else {
                }
                pendingTiles.add(tile);
            }
            tiles = pendingTiles.toArray(new Tile[pendingTiles.size()]);
        } catch (Exception e) {
            Log.e(TAG,"reloadSuggestionsBookmark exception : "+e.getMessage());
        }
    }

    private RoundedIconGenerator  mIconGenerator ;
    private Drawable getDefault(Context context, String url) {
        if (mIconGenerator == null
                ) {
            new RoundedIconGenerator(32, 32,
                    6, ApiCompatibilityUtils.getColor(
                    context.getResources(), R.color.default_favicon_background_color), 20);
        }
        Bitmap icon = mIconGenerator.generateIconForUrl(url);
        return new BitmapDrawable(context.getResources(), icon);
    }

    public static Drawable getPopularSitesIconByUrl(String url) {
        int resId = 0;
        if (url != null) {
            switch(url){
                case CLOUD189:
                    resId = R.mipmap.ecloud;
                    break;
                case KJ189:
                    resId = R.mipmap.kj;
                    break;
                case NB189:
                    resId = R.mipmap.llb;
                    break;
                case MAIL189:
                    resId = R.mipmap.mail189;
                    break;
                default:
                    return null;
            }
        }
        return ContextUtils.getApplicationContext().getResources().getDrawable(resId);
    }

    static {
        for (int i = 0; i < CUS_TITLES.length; i++) {
            Tile tile = new Tile(CUS_TITLES[i], CUS_URLS[i], null, i, TileSource.POPULAR);
            tile.setIcon(getPopularSitesIconByUrl(tile.getUrl()));
            pendingTiles.add(tile);
        }
        tiles = pendingTiles.toArray(new Tile[pendingTiles.size()]);
    }

    private static Tile[] getTiles() {
        return Arrays.copyOf(tiles, tiles.length);
    }


    public void renderTileViews(ViewGroup parent, boolean condensed, int titleLinesCount,TileGroup.Delegate tileGroupDelegate) {
        Log.e(TAG, "renderTileViews titleLinesCount : " + titleLinesCount);
        // Map the old tile views by url so they can be reused later.
        Map<String, TileView> oldTileViews = new HashMap<>();
        int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            TileView tileView = (TileView) parent.getChildAt(i);
            oldTileViews.put(tileView.getUrl(), tileView);
        }

        // Remove all views from the layout because even if they are reused later they'll have to be
        // added back in the correct order.
        parent.removeAllViews();

        for (Tile tile : getTiles()) {
            TileView tileView = oldTileViews.get(tile.getUrl());
            if (tileView == null) {
                tileView = buildTileView(tile, parent, condensed,titleLinesCount,tileGroupDelegate);
            } else {
                tileView.updateIfDataChanged(tile);
            }
            parent.addView(tileView);
        }
    }

    static TileView buildTileView(final Tile tile, ViewGroup parentView, boolean condensed, int titleLinesCount, final TileGroup.Delegate tileGroupDelegate) {
        TileView tileView = (TileView) LayoutInflater.from(parentView.getContext())
                .inflate(R.layout.tile_view, parentView, false);
        tileView.initialize(tile, titleLinesCount, condensed);

        // Note: It is important that the callbacks below don't keep a reference to the tile or
        // modify them as there is no guarantee that the same tile would be used to update the view.
//        LargeIconBridge.LargeIconCallback iconCallback = new TileGroup.LargeIconCallbackImpl(tile.getUrl(), isLoadTracked());
//        loadWhitelistIcon(tile, iconCallback);

//
//        TileGroup.TileInteractionDelegate delegate = new TileGroup.TileInteractionDelegate(tile.getUrl());
//        tileView.setOnClickListener(delegate);
//        tileView.setOnCreateContextMenuListener(delegate);
        tileView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tile == null) return;
                SuggestionsMetrics.recordTileTapped();
                tileGroupDelegate.openMostVisitedItem(WindowOpenDisposition.CURRENT_TAB, tile);
            }
        });
        return tileView;
    }

}

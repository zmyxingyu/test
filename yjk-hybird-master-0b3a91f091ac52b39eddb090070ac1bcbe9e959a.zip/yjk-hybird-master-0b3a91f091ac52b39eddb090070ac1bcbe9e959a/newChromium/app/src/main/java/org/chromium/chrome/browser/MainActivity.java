package org.chromium.chrome.browser;

import android.widget.Toast;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.init.AsyncInitializationActivity;

/**
 * Created by Administrator on 2017/11/17.
 */
public class MainActivity extends AsyncInitializationActivity {

    @Override
    public boolean shouldStartGpuProcess() {
        return false;
    }

    @Override
    protected void setContentView() {
        //设置content view
        setContentView(R.layout.main_activity);
    }

    @Override
    public void finishNativeInitialization() {
        super.finishNativeInitialization();
        //初始化界面，比如：findViewById等操作
        Toast.makeText(this, "finishNativeInitialization",
                Toast.LENGTH_SHORT).show();
    }
}

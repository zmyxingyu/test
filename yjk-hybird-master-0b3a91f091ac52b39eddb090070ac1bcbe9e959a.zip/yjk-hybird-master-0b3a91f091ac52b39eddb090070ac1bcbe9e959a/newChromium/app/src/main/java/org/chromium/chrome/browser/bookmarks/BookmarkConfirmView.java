package org.chromium.chrome.browser.bookmarks;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.PopupWindow;
import android.widget.Toast;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.widget.EmptyAlertEditText;
import org.chromium.components.bookmarks.BookmarkId;

/**
 * Created by Administrator on 2018/1/18.
 */
public class BookmarkConfirmView implements View.OnClickListener {
    private PopupWindow mPopWindow;
    private BookmarkActivity mActivity;

    private ConfirmCallback callback;

    /**
     * true表示正在执行退场动画
     **/
    private boolean mIsDismissAnimating;
    private View.OnClickListener mDismissClickListener;


    public BookmarkConfirmView(BookmarkActivity activity, ConfirmCallback callback) {
        mActivity = activity;
        this.callback = callback;
    }

    public boolean isMenuShowing() {
        return mPopWindow != null && mPopWindow.isShowing();
    }

    public void dismissMenu() {
        if (isMenuShowing() && !mIsDismissAnimating) {
            if (mDismissClickListener != null) {
                mDismissClickListener.onClick(null);
            } else {
                mPopWindow.dismiss();
            }
        }
    }

    public void show() {
        if (mPopWindow == null) {
            mPopWindow = new PopupWindow(mActivity);
            mPopWindow.setFocusable(true);
            mPopWindow.setSoftInputMode(PopupWindow.INPUT_METHOD_NEEDED);
            mPopWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // The window layout type affects the z-index of the popup window on M+.
            mPopWindow.setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_SUB_PANEL);
        }
        mPopWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        mPopWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopWindow.setOutsideTouchable(true);

        mPopWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        final ViewGroup root = (ViewGroup) View.inflate(mActivity, R.layout.bookmark_confirm_view, null);
        setupAnimation(root);
        mPopWindow.setContentView(root);
        mPopWindow.showAtLocation(root.findViewById(R.id.bookmark_pop_view), Gravity.BOTTOM | Gravity.LEFT, 0, 0);
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                dismissMenu();
            }
        });
    }

    private void setupAnimation(ViewGroup root) {
        final View content = root;//root.findViewById(R.id.content_layout);
        startSlideInOutAnimation(content, true, null);

        final Animation.AnimationListener dismissAnimationListener = new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mIsDismissAnimating = true;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mIsDismissAnimating = false;
                mDismissClickListener = null;
                mPopWindow.dismiss();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        };
        mDismissClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSlideInOutAnimation(content, false, dismissAnimationListener);
            }
        };
        root.findViewById(R.id.cancel_button).setOnClickListener(this);
        root.findViewById(R.id.ok_button).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cancel_button:
                dismissMenu();
                callback.onResult(false);
                break;
            case R.id.ok_button:
                dismissMenu();
                callback.onResult(true);
                break;
        }
    }

    public static interface ConfirmCallback {
        void onResult(boolean result);
    }

    private void startSlideInOutAnimation(View v, boolean inOrOut, Animation.AnimationListener listener) {
        v.clearAnimation();
        Animation animation = AnimationUtils.loadAnimation(mActivity, inOrOut ? R.anim.slide_in_up : R.anim.slide_out_down);
        if (listener != null) animation.setAnimationListener(listener);
        v.startAnimation(animation);
    }

}

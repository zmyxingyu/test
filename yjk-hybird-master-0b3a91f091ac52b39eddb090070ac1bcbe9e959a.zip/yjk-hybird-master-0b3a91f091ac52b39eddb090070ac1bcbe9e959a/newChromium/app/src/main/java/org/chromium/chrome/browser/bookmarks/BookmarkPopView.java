package org.chromium.chrome.browser.bookmarks;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import org.chromium.chrome.R;
import org.chromium.chrome.browser.ChromeActivity;
import org.chromium.chrome.browser.tab.Tab;
import org.chromium.chrome.browser.widget.EmptyAlertEditText;
import org.chromium.components.bookmarks.BookmarkId;

/**
 * Created by Administrator on 2018/1/18.
 */
public class BookmarkPopView implements View.OnClickListener {
    private PopupWindow mPopWindow;
    private BookmarkActivity mActivity;
    private BookmarkActionBar actionBar;
    private EmptyAlertEditText titleText, urlText , folderText;
    BookmarkBridge.BookmarkItem parentItem;

    private View startView, bookmarkView , folderView;

    /**
     * true表示正在执行退场动画
     **/
    private boolean mIsDismissAnimating;
    private View.OnClickListener mDismissClickListener;

    public static final int MODE_START = 1;
    public static final int MODE_ADD_BOOKMARK = 2;
    public static final int MODE_ADD_FOLDER = 3;
    private int currentMode = MODE_START;

    public BookmarkPopView(BookmarkActivity activity, BookmarkActionBar actionBar, BookmarkBridge.BookmarkItem item) {
        mActivity = activity;
        this.actionBar = actionBar;
        parentItem = item;
    }
    public void setMode(int mode){
        currentMode = MODE_START;
    }

    public boolean isMenuShowing() {
        return mPopWindow != null && mPopWindow.isShowing();
    }

    public void dismissMenu() {
        if (isMenuShowing() && !mIsDismissAnimating) {
            if (mDismissClickListener != null) {
                mDismissClickListener.onClick(null);
            } else {
                mPopWindow.dismiss();
            }
        }
    }

    public void show() {
        if (mPopWindow == null) {
            mPopWindow = new PopupWindow(mActivity);
            mPopWindow.setFocusable(true);
            mPopWindow.setSoftInputMode(PopupWindow.INPUT_METHOD_NEEDED);
            mPopWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // The window layout type affects the z-index of the popup window on M+.
            mPopWindow.setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_SUB_PANEL);
        }
        mPopWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        mPopWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopWindow.setOutsideTouchable(true);

        mPopWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        final ViewGroup root = (ViewGroup) View.inflate(mActivity, R.layout.bookmark_bottom_pop_view, null);
        setupAnimation(root);
        startView = root.findViewById(R.id.content_layout1);
        bookmarkView = root.findViewById(R.id.content_layout);
        folderView = root.findViewById(R.id.content_layout2);
        changeMode(currentMode);
        titleText = (EmptyAlertEditText) root.findViewById(R.id.title_text);
        urlText = (EmptyAlertEditText) root.findViewById(R.id.url_text);

        folderText = (EmptyAlertEditText) root.findViewById(R.id.folder_text);
        mPopWindow.setContentView(root);
        mPopWindow.showAtLocation(root.findViewById(R.id.bookmark_pop_view), Gravity.BOTTOM | Gravity.LEFT, 0, 0);
        mPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                dismissMenu();
            }
        });
    }

    private void changeMode(int currentMode) {
        this.currentMode = currentMode;
        if (currentMode == MODE_START) {
            startView.setVisibility(View.VISIBLE);
            bookmarkView.setVisibility(View.GONE);
            folderView.setVisibility(View.GONE);
        } else if (currentMode == MODE_ADD_BOOKMARK) {
            startView.setVisibility(View.GONE);
            bookmarkView.setVisibility(View.VISIBLE);
            folderView.setVisibility(View.GONE);
        }else if(currentMode == MODE_ADD_FOLDER){
            startView.setVisibility(View.GONE);
            bookmarkView.setVisibility(View.GONE);
            folderView.setVisibility(View.VISIBLE);
        }
    }

    private void setupAnimation(ViewGroup root) {
        final View content = root;//root.findViewById(R.id.content_layout);
        startSlideInOutAnimation(content, true, null);

        final Animation.AnimationListener dismissAnimationListener = new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mIsDismissAnimating = true;
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mIsDismissAnimating = false;
                mDismissClickListener = null;
                mPopWindow.dismiss();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        };
        mDismissClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSlideInOutAnimation(content, false, dismissAnimationListener);
            }
        };
        root.findViewById(R.id.bookmark_add_cancel).setOnClickListener(this);
        root.findViewById(R.id.bookmark_add_ok).setOnClickListener(this);
        root.findViewById(R.id.start_add_bookmark).setOnClickListener(this);
        root.findViewById(R.id.start_add_folder).setOnClickListener(this);
        root.findViewById(R.id.start_cancel).setOnClickListener(this);
        root.findViewById(R.id.folder_add_cancel).setOnClickListener(this);
        root.findViewById(R.id.folder_add_ok).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bookmark_add_cancel:
                dismissMenu();
                break;
            case R.id.bookmark_add_ok:
                if (titleText.isEmpty() || urlText.isEmpty()) {
                    return;
                }
                saveBookMark(titleText.getTrimmedText(), urlText.getTrimmedText());
                dismissMenu();
                break;
            case R.id.start_add_bookmark:
                changeMode(MODE_ADD_BOOKMARK);
                break;
            case R.id.start_add_folder:
                changeMode(MODE_ADD_FOLDER);
                break;
            case R.id.start_cancel:
                dismissMenu();
                break;
            case R.id.folder_add_cancel:
                dismissMenu();
                break;
            case R.id.folder_add_ok:
                if (folderText.isEmpty()) {
                    return;
                }
                saveFolder(folderText.getTrimmedText());
                dismissMenu();
                break;

        }
    }

    private void saveFolder(final String folder) {
        Log.e("zmy", "saveBookmark folder : " + folder);
        final BookmarkModel model = new BookmarkModel();
        model.runAfterBookmarkModelLoaded(new Runnable() {
            @Override
            public void run() {
                BookmarkId bookmarkId = model.addFolder(actionBar.getCurrentFolderId(), 0, folder);
                Toast.makeText(mActivity,
                        bookmarkId != null ? "添加成功" : "添加失败", Toast.LENGTH_SHORT).show();
                model.destroy();
            }
        });
    }

    private void saveBookMark(final String title, final String url) {
        Log.e("zmy", "saveBookmark title : " + title + " , url : " + url);
        final BookmarkModel model = new BookmarkModel();
        model.runAfterBookmarkModelLoaded(new Runnable() {
            @Override
            public void run() {
                BookmarkId bookmarkId = BookmarkUtils.addBookmarkSilently(
                        mActivity, model, title, url);
                Toast.makeText(mActivity,
                        bookmarkId != null ? "添加书签成功" : "添加书签失败", Toast.LENGTH_SHORT).show();
                model.destroy();
            }
        });
    }

    private void startSlideInOutAnimation(View v, boolean inOrOut, Animation.AnimationListener listener) {
        v.clearAnimation();
        Animation animation = AnimationUtils.loadAnimation(mActivity, inOrOut ? R.anim.slide_in_up : R.anim.slide_out_down);
        if (listener != null) animation.setAnimationListener(listener);
        v.startAnimation(animation);
    }

}
